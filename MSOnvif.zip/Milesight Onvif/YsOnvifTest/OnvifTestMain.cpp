#include "OnvifTestMain.h"
#include "../inc/Media.h"
#include "../inc/DeviceMgr.h"
#include "../inc/PtzMgr.h"
#include "../inc/Discovery.h"
#include "stdio.h"

void main()
{
	char *sIP = "192.168.10.105";
	int nPort = 80;
	char *sUser = "admin";
	char *sPwd = "ms1234";

 	CDeviceDiscovery _DeviceDiscovery;
 	DeviceList *ppDevice = NULL;
 	int pCnt = 0;
 	_DeviceDiscovery.LoadDevice(&ppDevice, &pCnt);

	if (ppDevice) delete[] ppDevice;

 	CMedia media("http://192.168.10.230:80/onvif/Media", "admin", "ms123456");
 	Media *pMedia = new Media;
 	if(media.Init_Media() == 0){	
 		media.LoadMediaInfo(pMedia, 1);
 	}

	CPtzMgr ptzMgr;
	ptzMgr.Init_Ptz("http://192.168.10.105:80/onvif/Media", "admin", "ms1234", "Profile_1");//"http://192.168.8.221:80/onvif/PTZ"
// 	TourInfo resTourToken[4] = {0};
// 	for (int j=0; j<4; j++)
// 	{
// 		resTourToken[j].nIndex = 1;
// 		resTourToken[j].nSpeed = 30;
// 		resTourToken[j].nStayTime = 15;
// 	}
// 	resTourToken[3].nIndex = 10;
// 	ptzMgr.AddPresetTour("Tour_4", resTourToken, 4);

// 	TourInfo resTourToken[4] = {0};
// 	for (int j=0; j<4; j++)
// 	{
// 		resTourToken[j].nIndex = 1;
// 		resTourToken[j].nSpeed = 30;
// 		resTourToken[j].nStayTime = 15;
// 	}
// 	resTourToken[3].nIndex = 5;
// 	ptzMgr.ModifyPresetTour("Tour_1", resTourToken, 4);

// 	TourInfo *resTourToken = new TourInfo[48];
// 	for (int j=0; j<48; j++)
// 	{
// 		//_snprintf(resTourToken[j].sToken, sizeof(resTourToken[j].sToken)-1, "%s", "");
// 		resTourToken[j].nIndex = -1;
// 		resTourToken[j].nSpeed = -1;
// 		resTourToken[j].nStayTime = -1;
// 	}
// 	ptzMgr.GetPresetTour("Tour_2", resTourToken, 48);

	PresetTourInfo* PresetList = new PresetTourInfo[8];
	for (int j=0; j<8; j++)
	{
		_snprintf(PresetList[j].sToken, sizeof(PresetList[j].sToken)-1, "%s", "");
		PresetList[j].nIndex = -1;
		PresetList[j].bTourSet = false;
	}
	int tourList[8] = {0};
	ptzMgr.GetPresetTours(PresetList, 8);
// 	char szIndex[32] = {0};
// 	for (int i=0; i<8; i++)
// 	{
// 		itoa(tourList[i], szIndex, 10);
// 		OutputDebugString(szIndex);
// 		OutputDebugString("\n");
// 	}
	
// 	PresetInfo* PresetList = new PresetInfo[256];
// 	for (int j=0; j<256; j++)
// 	{
// 		PresetList[j].nIndex = -1;
// 		_snprintf(PresetList[j].sName, sizeof(PresetList[j].sName)-1, "%s", "");
// 	}
// 	ptzMgr.GetPtzPresets(PresetList, 256);
// 	char szIndex[32] = {0};
// 	for (int i=0; i<256; i++)
// 	{
// 		itoa(PresetList[i].nIndex, szIndex, 10);
// 		OutputDebugString(szIndex);
// 		OutputDebugString("\r");
// 		OutputDebugString(PresetList[i].sName);
// 		OutputDebugString("\n");
// 	}
// 	if (PresetList)
// 	{
// 		delete []PresetList;
// 		PresetList = NULL;
// 	}

// 	CDeviceMgr dev("http://192.168.10.105:80/onvif/device_service", sUser, sPwd);
// 	Ms_Namespace msnamespace = {0};
// 	dev.GetAllCapability(&msnamespace);
// 
// 	CDeviceMgr deviceMgrVIVO("http://192.168.9.141:80/onvif/device_service", "admin", "666666");
// 	Ms_DeviceInfo msDeviceInfo = {0};
// 	deviceMgrVIVO.GetDeviceInfo(&msDeviceInfo);

// 	DeviceInfo devInfo = {0};
// 	dev.GetDevices(&devInfo);
// 	CMedia media(sIP, sUser, sPwd);
// 	MsVideoResOptions *pVideoResOptions = NULL;
// 	int nOptionSize = 0;
// 	media.GetVideoResOptions(&pVideoResOptions, &nOptionSize);
}