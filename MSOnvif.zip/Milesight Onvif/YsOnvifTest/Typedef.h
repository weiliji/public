#ifndef __NVR_TYPEDEF_H__
#define __NVR_TYPEDEF_H__
//#include <basic/YsLog.h>
//#include <basic/YsThread.h>

#define DLL_EXPORT __declspec(dllexport) 
#define DLL_IMPORT __declspec(dllimport)

typedef enum 
{
	ONVIF_FAIL = -1,
	ONVIF_OK = 0,
	ONVIF_PWD_INVALID,

	ONVIF_END,
}OnvifErrCode;

void PrintErr(char *sFunc, struct soap *pSoap);
unsigned int GetPrefixLength(char *pszNetmask);
unsigned int GetIPFromPrefixLength(int nPrefixLength, char *pszNetmask, int nLen);

#endif