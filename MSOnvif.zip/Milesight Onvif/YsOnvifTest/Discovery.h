#ifndef __DISCOVERY_H__
#define __DISCOVERY_H__
#include "Typedef.h"

//////////////////////////////////////////////////////////////////////////
typedef struct DeviceList
{
	char szIp[64];
	int nPort;
	char szType[128];
	char szUuid[64];
}DeviceList;

//////////////////////////////////////////////////////////////////////////

//�豸�����࣬�����࣬�����ߵ��ø��������豸�����Ϣ��
class DLL_EXPORT CDeviceDiscovery
{
public:
	CDeviceDiscovery();
	CDeviceDiscovery(char *pszIp, char* pszUserName, char* pszPassword);
	~CDeviceDiscovery();
private:
	void* m_pSession;
private:
	void SetIP(char *pszIp);
	void SetUsername(char *pszUsername);
	void SetPassword(char *pszPassword);
public:
	int LoadDevice(DeviceList **ppDevice, int *pCnt);
	void DeleteData(DeviceList *pDevice);
};


#endif