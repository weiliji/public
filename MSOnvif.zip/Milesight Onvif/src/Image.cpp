#include "../inc/Image.h"
#include "OnvifClientSession.h"
//////////////////////////////////////////////////////////////////////////

CImage::CImage()
{
	m_pSession = new COnvifClientSession();
}

CImage::CImage(char *pszIp, char* pszUserName, char* pszPassword)
{
	m_pSession = new COnvifClientSession(pszIp, pszUserName, pszPassword);
}

CImage::~CImage()
{
	if(m_pSession) 
		delete (COnvifClientSession*)m_pSession;	
	m_pSession = NULL;
}

void CImage::SetIP(char *pszIp)
{
	if(!pszIp) return;
	((COnvifClientSession*)m_pSession)->SetIp(pszIp);
}

void CImage::SetUsername(char *pszUsername)
{
	if(!pszUsername)return;
	((COnvifClientSession*)m_pSession)->SetUsername(pszUsername);
}

void CImage::SetPassword(char *pszPassword)
{
	if(!pszPassword) return;
	((COnvifClientSession*)m_pSession)->SetPassword(pszPassword);
}
////////////////////////////////////////////////////////////////////////////////////
int CImage::Init_Image(char *pszIp, char* pszUserName, char* pszPassword)
{	
	if(!pszIp || !pszUserName || !pszPassword) 
		return -1;
	SetIP(pszIp);
	SetUsername(pszUserName);
	SetPassword(pszPassword);

	return 0;
}

int CImage::GetImageOption(ImagingOption *pImageOption)
{
	if(!pImageOption)
		return ONVIF_FAIL;
	
	ImageOptions imageOption = {0};
	if(((COnvifClientSession*)m_pSession)->GetImageOption(pImageOption->szToken, &imageOption) != ONVIF_OK)
		return ONVIF_FAIL;
		
	pImageOption->brightness.fmin = imageOption.fMinBrightness;
	pImageOption->brightness.fmax = imageOption.fMaxBrightness;
	pImageOption->constast.fmin = imageOption.fMinContrast;
	pImageOption->constast.fmax = imageOption.fMaxContrast;
	pImageOption->saturation.fmin = imageOption.fMinColorSaturation;
	pImageOption->saturation.fmax = imageOption.fMaxColorSaturation;
	pImageOption->sharpness.fmin = imageOption.fMinSharpness;
	pImageOption->sharpness.fmax = imageOption.fMaxSharpness;
	return ONVIF_OK;
}

int CImage::GetImageInfo(ImagingInfo *pImageinfo)
{
	if(!pImageinfo)
		return ONVIF_FAIL;

	ImageSettings imageSetting = {0};
	if(((COnvifClientSession*)m_pSession)->GetImageSettings(pImageinfo->szToken, &imageSetting) != ONVIF_OK)
		return ONVIF_FAIL;
		
	pImageinfo->fBrightness = imageSetting.fBrightness;
	pImageinfo->fContrast = imageSetting.fContrast;
	pImageinfo->fColorSaturation = imageSetting.fColorSaturation;
	pImageinfo->fSharpness = imageSetting.fSharpness;
	return ONVIF_OK;
}

int CImage::SetImageInfo(ImagingInfo *pImageInfo)
{
	if(!pImageInfo) 
		return ONVIF_FAIL;
	ImageSettings imageSetting = {0};	
	imageSetting.fBrightness = pImageInfo->fBrightness;
	imageSetting.fContrast = pImageInfo->fContrast;
	imageSetting.fColorSaturation = pImageInfo->fColorSaturation;
	imageSetting.fSharpness = pImageInfo->fSharpness;
	return ((COnvifClientSession*)m_pSession)->SetImageSettings(pImageInfo->szToken, &imageSetting);
	return ONVIF_OK;
}

int CImage::GetFocusOption(FocusOption *pFocusOption)
{
	if(!pFocusOption)
		return ONVIF_FAIL;
	
	FocusMoveOptions focusOption = {0};
	if(((COnvifClientSession*)m_pSession)->GetFocusMoveOption(pFocusOption->szToken, &focusOption) != ONVIF_OK)
		return ONVIF_FAIL;
		
	pFocusOption->speed.fmin = focusOption.fMinSpeed;
	pFocusOption->speed.fmax = focusOption.fMaxSpeed;
	return ONVIF_OK;
}

int CImage::FocusMove(FocusMoveInfo *pFocusOption)
{
	if(!pFocusOption)
		return ONVIF_FAIL;
	
	FocusMoveSettings focusSetting = {0};
	focusSetting.speed = pFocusOption->speed;
	if(((COnvifClientSession*)m_pSession)->MoveFocus(pFocusOption->szToken, &focusSetting) != ONVIF_OK)
		return ONVIF_FAIL;
	return ONVIF_OK;
}

int CImage::Stop(char *pVideoSourceToken)
{
	if(!pVideoSourceToken)
		return ONVIF_FAIL;
	
	if(((COnvifClientSession*)m_pSession)->StopFocus(pVideoSourceToken) != ONVIF_OK)
		return ONVIF_FAIL;
	return ONVIF_OK;
}
