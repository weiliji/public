#ifndef __ONVIF_CLIENT_SESSION_H___
#define __ONVIF_CLIENT_SESSION_H___
#include "../inc/Typedef.h"
#include "../onvif/soapH.h"
#include "../inc/PtzMgr.h"
//#include "../onvif/soapRemoteDiscoveryBindingProxy.h"

#define PROFILE_NUM 3
//////////////////////////////////////////////////////////////////////////
typedef struct YsFTP
{

}YsFTP;
typedef struct YsSMTP
{

}YsSMTP;
typedef struct YsNetwork
{
	char szIp[64];
	char szNetmask[64];
	char szGateway[64];
	char szPDNS[64];
	int nHttpPort;

	YsFTP  ftp;
	YsSMTP smtp;
}YsNetwork;

typedef struct VideoEncoder
{
	char szToken[64];	
	int nCodecType;	
};

typedef struct YsProfile
{
	char szToken[64];
	int nCodecType;//2:h.264;1:mpeg;0:mjpeg
	int nWidth;
	int nHeight;
	int nMaxBitrate;
	int nFrameRate;
	VideoEncoder videoEncoder;
}YsProfile;

typedef struct  
{
	char sMedia[256];
	char sImaging[256];
	char sPtz[256];
	char sEvent[256];
	char sAnaly[256];
	char sDevice[256];
	char sExtern[256];
}MsNameSpace;

typedef struct  
{
	char sModel[128];
	char sManufacturer[128];
	char sFirmVersion[128];
	char sHardwareId[128];	
}MsDeviceInfo;
typedef struct DeviceInfo
{
	char szServiceUri[128*10];//Discovery��ʱ��ӷ�������ȡ���÷ֺŸ���
	char szUuid[64*10];

	int nProfileNum;//������������˫������
	YsProfile profile[PROFILE_NUM];//���֧��3����
	YsNetwork network;//��������
	MsNameSpace nameSpace;
	MsDeviceInfo deviceInfomation;
}DeviceInfo;

typedef struct ImageSettings
{
	float fBrightness;
	float fColorSaturation;
	float fContrast;	
	float fSharpness;
}ImageSettings;

typedef struct ImageOptions
{
	float fMinBrightness;
	float fMaxBrightness;
	float fMinColorSaturation;
	float fMaxColorSaturation;
	float fMinContrast;
	float fMaxContrast;
	float fMinSharpness;	
	float fMaxSharpness;
}ImageOptions;

typedef struct FocusMoveOptions
{
	float fMinSpeed;
	float fMaxSpeed;
}FocusMoveOptions;

typedef struct FocusMoveSettings
{
	float speed;
}FocusMoveSettings;

typedef struct ResolutionAvail
{
	int nWidth;
	int nHeight;
};

typedef struct VideoEncoderOptions
{
	int nCodecType;
	int nResolutionSize;
	ResolutionAvail *resolutionAvail;
	int nFrameRate;
	int nBitrate;
};

enum PTZ_Dir_Type
{
	PTZ_DIR_TOP,
	PTZ_DIR_BOTTOM,
	PTZ_DIR_LEFT,
	PTZ_DIR_RIGHT,
	PTZ_DIR_TOPLEFT,
	PTZ_DIR_TOPRIGHT,
	PTZ_DIR_BOTTOMLEFT,
	PTZ_DIR_BOTTOMRIGHT,

	PTZ_ZOOM_IN,
	PTZ_ZOOM_OUT,
};

enum PTZ_Cmd_Type
{
	PTZ_FOCUS_IN,
	PTZ_FOCUS_OUT,
	PTZ_IRIS_IN,
	PTZ_IRIS_OUT,

	PTZ_AUTO_SCAN,
	PTZ_LIGHT_OFF,
	PTZ_LIGHT_ON,
	PTZ_BRUSH_OFF,
	PTZ_BRUSH_ON,
	PTZ_SET_BRIGHTNESS,
	PTZ_SET_CONTRAST,
	PTZ_SET_SUTIRATION,
	PTZ_AUTO_FOCUS,
	PTZ_FOCUS_REST,
};

enum PTZ_Move_Type
{
	PTZ_ABSOLUTION_MOVE,
	PTZ_RELATIVE_MOVE,
	PTZ_CONTINUOUS_MOVE,	
};
////////////////////////////////////////////////////////////////////////
//�ڲ�ʹ�õģ���������onvif����ˣ�NVT�����ࡣ
class COnvifClientSession
{
public:
	COnvifClientSession();
	COnvifClientSession(char* pszIP, char *pszUsername, char *pszPassword);
	~COnvifClientSession();
private:
	struct soap *m_pSoap;
	char m_szIP[256];
	char m_szUsername[128];
	char m_szPassword[64];
	char m_szProfileToken[128];
private:
	int Auth(struct soap *pSoap);//��Ȩ
public:
	void SetIp(char *pszIp);
	void SetUsername(char *pszUsername);
	void SetPassword(char *pszPassword);
	void SetProfileToken(char *pszProfileToken);
public://Discovery
	int DeviceDiscovery(DeviceInfo *deviceInfo);
public://Media
	//void MsTest();
	int GetProfiles(DeviceInfo *deviceInfo);
	int GetStreamUri(DeviceInfo *deviceInfo, int nProfileIndex, char *pszUri, int nLen);
	int GetStreamUri(char* pszProfileToken, char *pszUri, int nLen);
	int GetVideoEncoderConfigOptions(VideoEncoderOptions **pVideoOptions, int *pnSize);
	int SetVideoEncoderConfig(DeviceInfo *deviceInfo);
	int GetVideoEncoderConfig(DeviceInfo *deviceInfo);
public://Device
	int GetCapabilities(DeviceInfo *deviceInfo);
	int GetDeviceInfomation(DeviceInfo *deviceInfo);
	
	//network
	int GetNetwork(DeviceInfo *deviceInfo);
	int SetNetwork(DeviceInfo *deviceInfo);
public://PTZ
	int MovePtz(int nDirect, float fValue, int nMoveType = 0);
	int StopPtz();
	int GetPtzPresets(PresetInfo* PresetList, int nCount);
	int SetPtzPreset(int nIndex);
	int RenamePtzPreset(int nIndex, char *sName);
	int RemovePtzPreset(int nIndex);
	int GotoPtzPreset(int nIndex);
	int AuxiliaryPtzCmd(int nType, float fValue);
	
	int GetPtzPresetTours(PresetTourInfo *tourList, int nCount);
	int CreatePresetTour(int nIndex);
	int RemovePresetTour(char *sPresetTourToken);
	int PlayPtzPresetTour(int nIndex);
	int StopPtzPresetTour(int nIndex);
	int GetPtzPresetTour(char *sPresetTourToken, TourInfo *resTourToken, int nCount);
	int ModifyPtzPresetTour(char *sPresetTourToken, TourInfo *resTourToken, int nCount);
	int AddPtzPresetTour(char *sPresetTourToken, TourInfo *resTourToken, int nCount);
public://Image
	int SetImageSettings(char *pszToken, ImageSettings *pImageSettings);
	int GetImageSettings(char *pszToken, ImageSettings *pImageSettings);
	int GetImageOption(char *pszToken, ImageOptions *option);
	// focus
	int MoveFocus(char *pszToken, FocusMoveSettings *pFocusMoveSettings);
	int StopFocus(char *pVideoSourceToken);
	int GetFocusMoveOption(char *pszToken, FocusMoveOptions *pFocusMoveOptions);
};




#endif