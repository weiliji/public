#include "../inc/Typedef.h"
#include <string.h>
#include <stdio.h>
#include "../onvif/soapH.h"

//////////////////////////////////////////////////////////////////////////
static unsigned int GetBitNumOfOne(unsigned int nValue)
{
	nValue = ((0xaaaaaaaa & nValue)>>1) + (0x55555555 & nValue);
	nValue = ((0xcccccccc & nValue)>>2) + (0x33333333 & nValue);
	nValue = ((0xf0f0f0f0 & nValue)>>4) + (0x0f0f0f0f & nValue);
	nValue = ((0xff00ff00 & nValue)>>8) + (0x00ff00ff & nValue);
	nValue = ((0xffff0000 & nValue)>>16) + (0x0000ffff & nValue);
	
	return nValue;
}

//////////////////////////////////////////////////////////////////////////

unsigned int GetPrefixLength(char *pszNetmask)
{
	if(!pszNetmask) return 0;
	
	int nResult = 0;
	char seps[]   = ".";
	char *token;
	
	token = strtok(pszNetmask, seps);
   	while( token != NULL )
   	{
		nResult += GetBitNumOfOne(atoi(token));
		token = strtok(NULL, seps );
   	}
	return nResult;
}

unsigned int GetIPFromPrefixLength(int nPrefixLength, char *pszNetmask, int nLen)
{
	if(!pszNetmask)return 0;
	int i = 0;char szValue[32]={0};
	int nCurLen = 0;
	if(nPrefixLength/8 > 0)
		_snprintf(pszNetmask, nLen, "255.");
	else{
		_snprintf(pszNetmask, nLen, "0.0.0.0");
		return 1;
	}
	
	if(nPrefixLength/16 > 0){
		nCurLen = strlen(pszNetmask);
		_snprintf(pszNetmask+nCurLen, nLen-nCurLen, "255.");
	}else{
		int nNum = nPrefixLength - 8;//nNum 1
		int nValue = 0;
		for(i = 0; i < nNum; i++){
			nValue += (int)pow((float)2, (float)(7-i));
		}
		
		nCurLen = strlen(pszNetmask);
		_snprintf(pszNetmask+nCurLen, nLen-nCurLen, "%d.", nValue);
	}
	
	if(nPrefixLength/24 > 0){
		nCurLen = strlen(pszNetmask);
		_snprintf(pszNetmask+nCurLen, nLen-nCurLen, "255.");
	}else{
		int nNum = nPrefixLength - 16;//nNum 1
		int nValue = 0;
		for(i = 0; i < nNum; i++){
			nValue += (int)pow((float)2, (float)(7-i));
		}
		nCurLen = strlen(pszNetmask);
		_snprintf(pszNetmask+nCurLen, nLen-nCurLen, "%d.", nValue);
	}
	
	if(nPrefixLength/32 > 0){
		nCurLen = strlen(pszNetmask);
		_snprintf(pszNetmask+nCurLen, nLen-nCurLen, "255");
		return 1;
	}else{
		int nNum = nPrefixLength - 24;//nNum 1
		int nValue = 0;
		for(i = 0; i < nNum; i++){
			nValue += (int)pow((float)2, (float)(7-i));
		}
		nCurLen = strlen(pszNetmask);
		_snprintf(pszNetmask+nCurLen, nLen-nCurLen, "%d", nValue);
	}	
	
	return 0;	
}

void PrintErr(char *sFunc, struct soap *pSoap)
{
	fflush(stdout);
	fprintf(stdout,"error:%d faultstring:%s faultcode:%s faultsubcode:%s faultdetail:%s\r\n", pSoap->error,
		*soap_faultstring(pSoap),*soap_faultcode(pSoap), *soap_faultsubcode(pSoap),*soap_faultdetail(pSoap));
	char szMsg[512] = {0};
	_snprintf(szMsg, sizeof(szMsg)-1, "%s error:%d faultstring:%s faultcode:%s faultsubcode:%s faultdetail:%s\r\n", sFunc, pSoap->error,
		*soap_faultstring(pSoap),*soap_faultcode(pSoap), *soap_faultsubcode(pSoap),*soap_faultdetail(pSoap));
	OutputDebugString(szMsg);
}
