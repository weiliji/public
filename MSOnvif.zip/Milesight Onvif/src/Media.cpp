#include "../inc/Media.h"
#include "OnvifClientSession.h"
//////////////////////////////////////////////////////////////////////////

CMedia::CMedia()
{
	m_pSession = new COnvifClientSession();
	m_pDeviceInfo = new DeviceInfo;
	memset(m_pDeviceInfo, 0, sizeof(DeviceInfo));
}

CMedia::CMedia(char *pszIp, char* pszUserName, char* pszPassword)
{
	m_pSession = new COnvifClientSession(pszIp, pszUserName, pszPassword);
	m_pDeviceInfo = new DeviceInfo;
	memset(m_pDeviceInfo, 0, sizeof(DeviceInfo));
}
CMedia::~CMedia()
{
	if(m_pSession) 
		delete (COnvifClientSession*)m_pSession;	
	if(m_pDeviceInfo) 
		delete (DeviceInfo*)m_pDeviceInfo;
	m_pSession = NULL;
	m_pDeviceInfo = NULL;
}

void CMedia::SetIP(char *pszIp)
{
	if(!pszIp) return;
	((COnvifClientSession*)m_pSession)->SetIp(pszIp);
}

void CMedia::SetUsername(char *pszUsername)
{
	if(!pszUsername)return;
	((COnvifClientSession*)m_pSession)->SetUsername(pszUsername);
}

void CMedia::SetPassword(char *pszPassword)
{
	if(!pszPassword) return;
	((COnvifClientSession*)m_pSession)->SetPassword(pszPassword);
}
////////////////////////////////////////////////////////////////////////////////////
int CMedia::Init_Media()
{
	if(ONVIF_OK != ((COnvifClientSession*)m_pSession)->GetProfiles((DeviceInfo*)m_pDeviceInfo))
		return ONVIF_FAIL;
	switch(((DeviceInfo*)m_pDeviceInfo)->nProfileNum){
	case 1:
		m_streamType = STREAM_TYPE_SINGLE;
		break;
	case 2:
		m_streamType = STREAM_TYPE_DUAL;
		break;
	case 3:
		m_streamType = STREAM_TYPE_TRI;
		break;
	default:
		m_streamType = STREAM_TYPE_DUAL;
		break;
	}
	return ONVIF_OK;
}

int CMedia::LoadMediaInfo(Media *pMedia, int nMediaNum)
{
	if(!pMedia) return ONVIF_FAIL;
	for(int i = 0; i < nMediaNum; i++)
	{
		_snprintf(pMedia[i].szToken, sizeof(pMedia[i].szToken)-1, "%s", ((DeviceInfo*)m_pDeviceInfo)->profile[i].szToken);
		pMedia[i].codecType = (CodecType)((DeviceInfo*)m_pDeviceInfo)->profile[i].nCodecType;
		pMedia[i].nResulotionX = ((DeviceInfo*)m_pDeviceInfo)->profile[i].nWidth;
		pMedia[i].nResulotionY = ((DeviceInfo*)m_pDeviceInfo)->profile[i].nHeight;
		pMedia[i].nMaxBitrate = ((DeviceInfo*)m_pDeviceInfo)->profile[i].nMaxBitrate;
		pMedia[i].nFrameRate = ((DeviceInfo*)m_pDeviceInfo)->profile[i].nFrameRate;
		_snprintf(pMedia[i].szVideoToken, sizeof(pMedia[i].szVideoToken)-1, "%s", ((DeviceInfo*)m_pDeviceInfo)->profile[i].videoEncoder.szToken);
	}
	return ONVIF_OK;
}

int CMedia::GetStreamUri(char *pszToken, char *pszUri, int nLen)
{
	if(!pszUri || !pszToken) return ONVIF_FAIL;

	return ((COnvifClientSession*)m_pSession)->GetStreamUri(pszToken, pszUri, nLen);
}

int CMedia::GetStreamUri(Media *pMedia, char *pszUri, int nLen)
{
	if(!pszUri || !pMedia)return ONVIF_FAIL;

	return GetStreamUri(pMedia->szToken, pszUri, nLen);
}

int CMedia::GetVideoEncoder()
{
	DeviceInfo deviceInfo = {0};
	return ((COnvifClientSession*)m_pSession)->GetVideoEncoderConfig(&deviceInfo);
}

int CMedia::SetVideoEncoder(Media *pMedia)
{
	if(!pMedia)
		return ONVIF_FAIL;
	DeviceInfo deviceInfo = {0};
	_snprintf(deviceInfo.profile[0].szToken, sizeof(deviceInfo.profile[0].szToken)-1, "%s", pMedia->szVideoToken);
	deviceInfo.profile[0].nWidth = pMedia->nResulotionX;
	deviceInfo.profile[0].nHeight = pMedia->nResulotionY;
	deviceInfo.profile[0].nCodecType = pMedia->codecType;
	deviceInfo.profile[0].nMaxBitrate = pMedia->nMaxBitrate;
	deviceInfo.profile[0].nFrameRate = pMedia->nFrameRate;
	return ((COnvifClientSession*)m_pSession)->SetVideoEncoderConfig(&deviceInfo);
}

int CMedia::DeleteVideoResOptions(MsVideoResOptions *pVideoResOptions)
{
	delete pVideoResOptions;
	pVideoResOptions = NULL;
	return ONVIF_OK;
}

int CMedia::GetVideoResOptions(MsVideoResOptions **pVideoResOptions, int *pnOptionSize)
{
	//if(!pVideoResOptions || !pnOptionSize)
	//	return ONVIF_FAIL;

	VideoEncoderOptions *pVideoEncoderOptions = NULL;
	int nSize = 0;
	if(((COnvifClientSession*)m_pSession)->GetVideoEncoderConfigOptions(&pVideoEncoderOptions, &nSize) != SOAP_OK || nSize == 0)
		return ONVIF_FAIL;
	*pnOptionSize = nSize;
	*pVideoResOptions = new MsVideoResOptions[nSize];//(MsVideoResOptions*)malloc(sizeof(MsVideoResOptions)*nSize);
	for (int i = 0; i < nSize; i++)
	{
		(*pVideoResOptions)[i].codecType = (CodecType)pVideoEncoderOptions[i].nCodecType;
		(*pVideoResOptions)[i].nResolutionSize = pVideoEncoderOptions[i].nResolutionSize;
		(*pVideoResOptions)[i].pResolution = new MsResolution[(*pVideoResOptions)[i].nResolutionSize];
		for(int j = 0; j < (*pVideoResOptions)[i].nResolutionSize; j++){
			(*pVideoResOptions)[i].pResolution[j].nWidth = pVideoEncoderOptions[i].resolutionAvail[j].nWidth;	
			(*pVideoResOptions)[i].pResolution[j].nHeight = pVideoEncoderOptions[i].resolutionAvail[j].nHeight;
		}
	}
	delete[] pVideoEncoderOptions;
	return ONVIF_OK;
}