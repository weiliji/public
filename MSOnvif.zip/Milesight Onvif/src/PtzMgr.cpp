// MsPtz.cpp: implementation of the CMsPtz class.
//
//////////////////////////////////////////////////////////////////////

#include "../inc/PtzMgr.h"
#include "OnvifClientSession.h"
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPtzMgr::CPtzMgr()
{
	m_pSession = new COnvifClientSession();
}

CPtzMgr::CPtzMgr(char *pszIp, char* pszUserName, char* pszPassword)
{
	m_pSession = new COnvifClientSession(pszIp, pszUserName, pszPassword);
}

CPtzMgr::~CPtzMgr()
{
	if(m_pSession) 
		delete (COnvifClientSession*)m_pSession;	
	m_pSession = NULL;
}

void CPtzMgr::SetIP(char *pszIp)
{
	if(!pszIp) return;
	((COnvifClientSession*)m_pSession)->SetIp(pszIp);
}

void CPtzMgr::SetUsername(char *pszUsername)
{
	if(!pszUsername)return;
	((COnvifClientSession*)m_pSession)->SetUsername(pszUsername);
}

void CPtzMgr::SetPassword(char *pszPassword)
{
	if(!pszPassword) return;
	((COnvifClientSession*)m_pSession)->SetPassword(pszPassword);
}

void CPtzMgr::SetProfileToken(char *pszProfileToken)
{
	if(!pszProfileToken) return;
	((COnvifClientSession*)m_pSession)->SetProfileToken(pszProfileToken);
}

int CPtzMgr::Init_Ptz(char *pszIp, char* pszUserName, char* pszPassword, char *pszProfileToken)
{	
	if(!pszIp || !pszUserName || !pszPassword || !pszProfileToken) 
		return -1;
	SetIP(pszIp);
	SetUsername(pszUserName);
	SetPassword(pszPassword);
	SetProfileToken(pszProfileToken);

	return 0;
}
//////////////////////////////////////////////////////////////////////////
int CPtzMgr::MoveMsPtz(int nDirect, int nSpeed)
{
	float fValue = (float)nSpeed*1000000/10000000;
	if(((COnvifClientSession*)m_pSession)->MovePtz(nDirect, fValue, PTZ_CONTINUOUS_MOVE) != ONVIF_OK)
		return ((COnvifClientSession*)m_pSession)->MovePtz(nDirect, fValue, PTZ_RELATIVE_MOVE);
	return ONVIF_OK;
}

int CPtzMgr::StopMsPtz()
{
	return ((COnvifClientSession*)m_pSession)->StopPtz(); 
}

int CPtzMgr::SendPtzCmd(int nCmdType, int nSpeed)
{
	float fValue = (float)nSpeed;
	return ((COnvifClientSession*)m_pSession)->AuxiliaryPtzCmd(nCmdType, fValue);
}

int CPtzMgr::GetPtzPresets(PresetInfo* PresetList, int nCount)
{
	if (!PresetList)
	{
		return -1;
	}
	return ((COnvifClientSession*)m_pSession)->GetPtzPresets(PresetList, nCount);
}

int CPtzMgr::SetPreset(int nPresetIndex)
{
	return ((COnvifClientSession*)m_pSession)->SetPtzPreset(nPresetIndex);
}

int CPtzMgr::RenamePreset(int nPresetIndex, char *sName)
{
	return ((COnvifClientSession*)m_pSession)->RenamePtzPreset(nPresetIndex, sName);
}

int CPtzMgr::RemovePreset(int nPresetIndex)
{
	return ((COnvifClientSession*)m_pSession)->RemovePtzPreset(nPresetIndex);
}

int CPtzMgr::GotoPreset(int nPresetIndex)
{
	return ((COnvifClientSession*)m_pSession)->GotoPtzPreset(nPresetIndex);
}

int CPtzMgr::GetPresetTours(PresetTourInfo *tourList, int nCount)
{
	if (!tourList)
	{
		return -1;
	}
	return ((COnvifClientSession*)m_pSession)->GetPtzPresetTours(tourList, nCount);
}

int CPtzMgr::GetPresetTour(char *sPresetTourToken, TourInfo *resTourToken, int nCount)
{
	if (!resTourToken || !sPresetTourToken)
	{
		return -1;
	}
	return ((COnvifClientSession*)m_pSession)->GetPtzPresetTour(sPresetTourToken, resTourToken, nCount);
}

int CPtzMgr::PlayPresetTour(int nPatrolIndex)
{
	return ((COnvifClientSession*)m_pSession)->PlayPtzPresetTour(nPatrolIndex);
}

int CPtzMgr::StopPresetTour(int nPatrolIndex)
{
	return ((COnvifClientSession*)m_pSession)->StopPtzPresetTour(nPatrolIndex);
}

int CPtzMgr::RemovePresetTour(char *sPresetTourToken)
{
	if (!sPresetTourToken)
	{
		return -1;
	}
	return ((COnvifClientSession*)m_pSession)->RemovePresetTour(sPresetTourToken);
}

int CPtzMgr::ModifyPresetTour(char *sPresetTourToken, TourInfo *resTourToken, int nCount)
{
	if (!resTourToken || !sPresetTourToken)
	{
		return -1;
	}
	return ((COnvifClientSession*)m_pSession)->ModifyPtzPresetTour(sPresetTourToken, resTourToken, nCount);
}

int CPtzMgr::AddPresetTour(char *sPresetTourToken, TourInfo *resTourToken, int nCount)
{
	if (!resTourToken)
	{
		return -1;
	}
	return ((COnvifClientSession*)m_pSession)->AddPtzPresetTour(sPresetTourToken, resTourToken, nCount);
}