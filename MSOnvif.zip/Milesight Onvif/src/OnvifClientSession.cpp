#include <iostream>
#include "../inc/Typedef.h"
#include "OnvifClientSession.h"

//#include "../onvif/soapRemoteDiscoveryBindingProxy.h"
//#include "../onvif/soapDiscoveryLookupBindingProxy.h"
#include "../onvif/soapDeviceBindingProxy.h"
#include "../onvif/soapMediaBindingProxy.h"
#include "../onvif/wsseapi.h"
#include "../onvif/soapPTZBindingProxy.h"
#include "../onvif/soapImagingBindingProxy.h"

#define TIME "Time"
#define TIME_VALUE 10

COnvifClientSession::COnvifClientSession()
{
	m_pSoap = soap_new();
	memset(m_szIP, 0, sizeof(m_szIP));
	memset(m_szUsername, 0, sizeof(m_szUsername));
	memset(m_szPassword, 0, sizeof(m_szPassword));
	memset(m_szProfileToken, 0, sizeof(m_szProfileToken));
}

COnvifClientSession::COnvifClientSession(char* pszIP, char *pszUsername, char *pszPassword)
{
	if(!pszPassword || !pszUsername) return;
	_snprintf(m_szIP, sizeof(m_szIP)-1, "%s", pszIP);
	_snprintf(m_szUsername, sizeof(m_szUsername)-1, "%s", pszUsername);
	_snprintf(m_szPassword, sizeof(m_szPassword)-1, "%s", pszPassword);
	memset(m_szProfileToken, 0, sizeof(m_szProfileToken));

	m_pSoap = soap_new();	
}
COnvifClientSession::~COnvifClientSession()
{
	if(m_pSoap){
		soap_destroy(m_pSoap);
		soap_end(m_pSoap);
		soap_free(m_pSoap);//bruce.milesight add 2010.08.14
	}
}

void COnvifClientSession::SetIp(char *pszIp)
{
	if(!pszIp) return;
	_snprintf(m_szIP, sizeof(m_szIP)-1, "%s", pszIp);
}

void COnvifClientSession::SetUsername(char *pszUsername)
{
	if(!pszUsername) return;
	_snprintf(m_szUsername, sizeof(m_szUsername)-1, "%s", pszUsername);
}

void COnvifClientSession::SetPassword(char *pszPassword)
{
	if(!pszPassword) return;
	_snprintf(m_szPassword, sizeof(m_szPassword)-1, "%s", pszPassword);
}

void COnvifClientSession::SetProfileToken(char *pszProfileToken)
{
	if(!pszProfileToken) return;
	_snprintf(m_szProfileToken, sizeof(m_szProfileToken)-1, "%s", pszProfileToken);
}

int COnvifClientSession::Auth(struct soap *pSoap)
{//return 1;
#if 0
	return 0;
#else
	if(m_szUsername[0] == '\0' || m_szPassword[0] == '\0') return 0;
	soap_register_plugin(pSoap, soap_wsse);
	if(SOAP_OK != soap_wsse_add_UsernameTokenDigest(pSoap, NULL, m_szUsername, m_szPassword))return 0;	
	if(SOAP_OK != soap_wsse_add_Timestamp(pSoap, TIME, TIME_VALUE))return 0;
	return 1;
#endif
}
//////////////////////////////////////////////////////////////////////////
//Discovery
int COnvifClientSession::DeviceDiscovery(DeviceInfo *deviceInfo)
{
#if 1
	if(deviceInfo == NULL) return ONVIF_FAIL;
	DeviceBindingProxy deviceProxy;
	struct SOAP_ENV__Header header;
	memset(&header, 0, sizeof(header));
	deviceProxy.soap->header = &header;

	//add discovery recv port by lixiaoqiang 2019/8/15
	//deviceProxy.soap->client_port = 3702;

	soap_default_SOAP_ENV__Header(deviceProxy.soap, &header);
	header.wsa5__MessageID = "uuid:cff0d69d-5934-4723-888e-4a969ff06ed3";
	header.wsa5__To = "urn:schemas-xmlsoap-org:ws:2005:04:discovery";
	header.wsa5__Action = "http://schemas.xmllocal_soap.org/ws/2005/04/discovery/Probe";

	_tds__GetServices *Services = soap_new__tds__GetServices(m_pSoap, -1);
	_tds__GetServicesResponse *ServicesResponse = soap_new__tds__GetServicesResponse(m_pSoap, -1);
	int nDiscovery = deviceProxy.GetServices("soap.udp://239.255.255.250:3702", NULL, Services, *ServicesResponse);
	if(nDiscovery != SOAP_OK) 
		return ONVIF_FAIL;
	else
		return SOAP_OK;

#else
	if(deviceInfo == NULL) return ONVIF_FAIL;
	DiscoveryLookupBinding proxyDiscovery;
	//proxyDiscovery.soap->namespaces = NULL;
	struct SOAP_ENV__Header header = {0};
	proxyDiscovery.endpoint = "soap.udp://239.255.255.250:3702";///datagram
	proxyDiscovery.soap->header = &header;

	soap_default_SOAP_ENV__Header(proxyDiscovery.soap, &header);
	header.wsa5__MessageID = "uuid:cff0d69d-5934-4723-888e-4a969ff06ed3";
	header.wsa5__To = "urn:schemas-xmlsoap-org:ws:2005:04:discovery";
	header.wsa5__Action = "http://schemas.xmllocal_soap.org/ws/2005/04/discovery/Probe";

	d__ProbeType d__Probe;
	std::string sTypes = "";//"dn:NetworkVideoTransmitter";
	d__Probe.Types = &sTypes;

	d__ScopesType Scopes;
	Scopes.__item = "";//http://schemas.xmlsoap.org/ws/2005/04/discovery
	d__Probe.Scopes = &Scopes;

	proxyDiscovery.soap->recv_timeout = 2;
	int nResult = ONVIF_FAIL;
	int nCurLen = 0;
	int nCurLenUuid = 0;

	d__ProbeMatchesType d__ProbeMatches;
	//proxyDiscovery.__dndl__Probe(&d__Probe, &d__ProbeMatches);

	int nTryCount = 0;
	int nDiscovery = proxyDiscovery.__dndl_Probe_Start(&d__Probe, &d__ProbeMatches);
	if(nDiscovery != SOAP_OK) return ONVIF_FAIL;
	while (nDiscovery == SOAP_OK && nTryCount < 5)//����ʧ��3��
	{
		nDiscovery = proxyDiscovery.__dndl_Probe_Receive(&d__Probe, &d__ProbeMatches);
		if(nDiscovery == SOAP_OK){
			nResult = ONVIF_OK;
			for( std::vector<class d__ProbeMatchType * >::iterator probeMatch = d__ProbeMatches.ProbeMatch.begin(); probeMatch != d__ProbeMatches.ProbeMatch.end(); probeMatch++)
			{
				OutputDebugString((*probeMatch)->XAddrs->c_str());
				OutputDebugString("\n");

				printf("XAddrs:%s\r\n", (*probeMatch)->XAddrs->c_str());
				printf("Types:%s\r\n", (*probeMatch)->Types->c_str());
				printf("uuid:%s\r\n", (*probeMatch)->wsa5__EndpointReference.Address);
				printf("version:%d\r\n", (*probeMatch)->MetadataVersion);
				printf("scope item:%s\r\n", (*probeMatch)->Scopes->__item.c_str());

				nCurLen = strlen(deviceInfo->szServiceUri);
				_snprintf(deviceInfo->szServiceUri + nCurLen, sizeof(deviceInfo->szServiceUri)-1-nCurLen, "%s;", (*probeMatch)->XAddrs->c_str());

				nCurLenUuid = strlen(deviceInfo->szUuid);
				_snprintf(deviceInfo->szUuid + nCurLenUuid, sizeof(deviceInfo->szUuid)-1-nCurLenUuid, "%s;", (*probeMatch)->wsa5__EndpointReference.Address);
			}
		}else{
			//PrintErr(proxyDiscovery.soap);
			//return ONVIF_FAIL;
			nDiscovery = SOAP_OK;
			nTryCount++;
		}
	}

	return nResult;
#endif
}

//////////////////////////////////////////////////////////////////////////
//Device
int COnvifClientSession::GetDeviceInfomation(DeviceInfo *deviceInfo)
{
#if 1
	if(deviceInfo == NULL) return ONVIF_FAIL;
	DeviceBindingProxy proxyDevice;

	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyDevice.soap->connect_timeout = 5;// -500000;��������Camera
	proxyDevice.soap->recv_timeout = 5;//-500000;

	_tds__GetDeviceInformation *tds__GetDeviceInformation = soap_new__tds__GetDeviceInformation(m_pSoap, -1);
	_tds__GetDeviceInformationResponse *tds__GetDeviceInformationResp = soap_new__tds__GetDeviceInformationResponse(m_pSoap, -1);
	int nResult = ONVIF_FAIL;
	if(SOAP_OK == proxyDevice.GetDeviceInformation(m_szIP,NULL,tds__GetDeviceInformation, *tds__GetDeviceInformationResp)){
		nResult = ONVIF_OK;
		if(tds__GetDeviceInformationResp->Model.empty() == false){
			_snprintf(deviceInfo->deviceInfomation.sModel, sizeof(deviceInfo->deviceInfomation.sModel)-1, "%s", tds__GetDeviceInformationResp->Model.c_str());
		}
		if(tds__GetDeviceInformationResp->Manufacturer.empty() == false){
			_snprintf(deviceInfo->deviceInfomation.sManufacturer, sizeof(deviceInfo->deviceInfomation.sManufacturer)-1, "%s", tds__GetDeviceInformationResp->Manufacturer.c_str());
		}
		if(tds__GetDeviceInformationResp->HardwareId.empty() == false){
			_snprintf(deviceInfo->deviceInfomation.sHardwareId, sizeof(deviceInfo->deviceInfomation.sHardwareId)-1, "%s", tds__GetDeviceInformationResp->HardwareId.c_str());
		}
		if(tds__GetDeviceInformationResp->FirmwareVersion.empty() == false){
			_snprintf(deviceInfo->deviceInfomation.sFirmVersion, sizeof(deviceInfo->deviceInfomation.sFirmVersion)-1, "%s", tds__GetDeviceInformationResp->FirmwareVersion.c_str());
		}
	}else{
		PrintErr("GetDeviceInfomation", proxyDevice.soap);	
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}

	return nResult;
	
#else
	if(!deviceInfo) return ONVIF_FAIL;	

	DeviceBindingProxy proxyDevice;
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyDevice.soap->connect_timeout = 2;// -500000;��������Camera
	proxyDevice.soap->recv_timeout = 2;//-500000;
	proxyDevice.endpoint = _strdup(m_szIP);

	_tds__GetDeviceInformation *tds__GetDeviceInformation = soap_new__tds__GetDeviceInformation(m_pSoap, -1);
	_tds__GetDeviceInformationResponse *tds__GetDeviceInformationResp = soap_new__tds__GetDeviceInformationResponse(m_pSoap, -1);
	int nResult = ONVIF_FAIL;
	if(SOAP_OK == proxyDevice.__tds__GetDeviceInformation(tds__GetDeviceInformation,tds__GetDeviceInformationResp)){
		nResult = ONVIF_OK;
		if(tds__GetDeviceInformationResp->Model.empty() == false){
			_snprintf(deviceInfo->deviceInfomation.sModel, sizeof(deviceInfo->deviceInfomation.sModel)-1, "%s", tds__GetDeviceInformationResp->Model.c_str());
		}
		if(tds__GetDeviceInformationResp->Manufacturer.empty() == false){
			_snprintf(deviceInfo->deviceInfomation.sManufacturer, sizeof(deviceInfo->deviceInfomation.sManufacturer)-1, "%s", tds__GetDeviceInformationResp->Manufacturer.c_str());
		}
		if(tds__GetDeviceInformationResp->HardwareId.empty() == false){
			_snprintf(deviceInfo->deviceInfomation.sHardwareId, sizeof(deviceInfo->deviceInfomation.sHardwareId)-1, "%s", tds__GetDeviceInformationResp->HardwareId.c_str());
		}
		if(tds__GetDeviceInformationResp->FirmwareVersion.empty() == false){
			_snprintf(deviceInfo->deviceInfomation.sFirmVersion, sizeof(deviceInfo->deviceInfomation.sFirmVersion)-1, "%s", tds__GetDeviceInformationResp->FirmwareVersion.c_str());
		}
	}else{
		//PrintErr(proxyDevice.soap);	
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}

	free((void*)proxyDevice.endpoint);//free
	return nResult;
#endif
}

// #include "../onvif/DeviceBinding.nsmap"
SOAP_NMAC struct Namespace namespaces2[] =
{
// 	{"SOAP-ENV", "http://www.w3.org/2003/05/soap-envelope", "http://www.w3.org/*/soap-envelope", NULL},
	{"SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "http://www.w3.org/*/soap-envelope", NULL},
	{"SOAP-ENC", "http://schemas.xmlsoap.org/soap/encoding/", "http://www.w3.org/*/soap-encoding", NULL},
	{"xsi", "http://www.w3.org/2001/XMLSchema-instance", "http://www.w3.org/*/XMLSchema-instance", NULL},
	{"xsd", "http://www.w3.org/2001/XMLSchema", "http://www.w3.org/*/XMLSchema", NULL},
	{"c14n", "http://www.w3.org/2001/10/xml-exc-c14n#", NULL, NULL},
	{"wsu", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd", NULL, NULL},
	{"xenc", "http://www.w3.org/2001/04/xmlenc#", NULL, NULL},
	{"ds", "http://www.w3.org/2000/09/xmldsig#", NULL, NULL},
	{"wsse", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd", "http://docs.oasis-open.org/wss/oasis-wss-wssecurity-secext-1.1.xsd", NULL},
	{"xmime", "http://tempuri.org/xmime.xsd", NULL, NULL},
	{"xop", "http://www.w3.org/2004/08/xop/include", NULL, NULL},
	{"tt", "http://www.onvif.org/ver10/schema", NULL, NULL},
	{"ns1", "http://docs.oasis-open.org/wsrf/bf-2", NULL, NULL},
	{"wsa5", "http://www.w3.org/2005/08/addressing", "http://schemas.xmlsoap.org/ws/2004/08/addressing", NULL},
	{"wstop", "http://docs.oasis-open.org/wsn/t-1", NULL, NULL},
	{"ns3", "http://docs.oasis-open.org/wsrf/r-2", NULL, NULL},
	{"dndl", "http://www.onvif.org/ver10/network/wsdl/DiscoveryLookupBinding", NULL, NULL},
	{"dnrd", "http://www.onvif.org/ver10/network/wsdl/RemoteDiscoveryBinding", NULL, NULL},
	{"d", "http://schemas.xmlsoap.org/ws/2005/04/discovery", NULL, NULL},
	{"dn", "http://www.onvif.org/ver10/network/wsdl", NULL, NULL},
	{"ns10", "http://www.onvif.org/ver10/analyticsdevice/wsdl", NULL, NULL},
	{"ns11", "http://www.onvif.org/ver10/events/wsdl/PullPointSubscriptionBinding", NULL, NULL},
	{"ns12", "http://www.onvif.org/ver10/events/wsdl/EventBinding", NULL, NULL},
	{"tev", "http://www.onvif.org/ver10/events/wsdl", NULL, NULL},
	{"ns13", "http://www.onvif.org/ver10/events/wsdl/SubscriptionManagerBinding", NULL, NULL},
	{"ns14", "http://www.onvif.org/ver10/events/wsdl/NotificationProducerBinding", NULL, NULL},
	{"ns15", "http://www.onvif.org/ver10/events/wsdl/NotificationConsumerBinding", NULL, NULL},
	{"ns16", "http://www.onvif.org/ver10/events/wsdl/PullPointBinding", NULL, NULL},
	{"ns17", "http://www.onvif.org/ver10/events/wsdl/CreatePullPointBinding", NULL, NULL},
	{"ns18", "http://www.onvif.org/ver10/events/wsdl/PausableSubscriptionManagerBinding", NULL, NULL},
	{"wsnt", "http://docs.oasis-open.org/wsn/b-2", NULL, NULL},
	{"ns19", "http://www.onvif.org/ver20/analytics/wsdl/RuleEngineBinding", NULL, NULL},
	{"ns20", "http://www.onvif.org/ver20/analytics/wsdl/AnalyticsEngineBinding", NULL, NULL},
	{"tan", "http://www.onvif.org/ver20/analytics/wsdl", NULL, NULL},
	{"ns4", "http://www.onvif.org/ver10/display/wsdl", NULL, NULL},
	{"ns5", "http://www.onvif.org/ver10/deviceIO/wsdl", NULL, NULL},
	{"ns6", "http://www.onvif.org/ver10/receiver/wsdl", NULL, NULL},
	{"ns7", "http://www.onvif.org/ver10/recording/wsdl", NULL, NULL},
	{"ns8", "http://www.onvif.org/ver10/search/wsdl", NULL, NULL},
	{"ns9", "http://www.onvif.org/ver10/replay/wsdl", NULL, NULL},
	{"tds", "http://www.onvif.org/ver10/device/wsdl", NULL, NULL},
	{"timg", "http://www.onvif.org/ver20/imaging/wsdl", NULL, NULL},
	{"tptz", "http://www.onvif.org/ver20/ptz/wsdl", NULL, NULL},
	{"trt", "http://www.onvif.org/ver10/media/wsdl", NULL, NULL},
	{NULL, NULL, NULL, NULL}
};

int COnvifClientSession::GetCapabilities(DeviceInfo *deviceInfo)
{
#if 1
	if(!deviceInfo) return ONVIF_FAIL;	
	
	DeviceBindingProxy proxyDevice;
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyDevice.soap->connect_timeout = 5;// -500000;��������Camera
	proxyDevice.soap->recv_timeout = 10;//-500000;
	_tds__GetCapabilities *tds__GetCapabilities = soap_new__tds__GetCapabilities(m_pSoap,-1);
	tds__GetCapabilities->Category.push_back(tt__CapabilityCategory__All);	
	_tds__GetCapabilitiesResponse *tds__GetCapabilitiesResponse = soap_new__tds__GetCapabilitiesResponse(m_pSoap,-1);
	
	int nResult = ONVIF_FAIL;
	int nGetRes = proxyDevice.GetCapabilities(m_szIP, NULL, tds__GetCapabilities,*tds__GetCapabilitiesResponse);

	if(SOAP_OK == nGetRes){
		nResult = ONVIF_OK;
		if (tds__GetCapabilitiesResponse->Capabilities->Media != NULL){
			//if(tds__GetCapabilitiesResponse->Capabilities->Media->XAddr)
				_snprintf(deviceInfo->nameSpace.sMedia, sizeof(deviceInfo->nameSpace.sMedia)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Media->XAddr.c_str());
		}
		if (tds__GetCapabilitiesResponse->Capabilities->Imaging != NULL){
			//if(tds__GetCapabilitiesResponse->Capabilities->Imaging->XAddr)
				_snprintf(deviceInfo->nameSpace.sImaging, sizeof(deviceInfo->nameSpace.sImaging)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Imaging->XAddr.c_str());
		}
		if (tds__GetCapabilitiesResponse->Capabilities->PTZ != NULL){
			//if(tds__GetCapabilitiesResponse->Capabilities->PTZ->XAddr)
				_snprintf(deviceInfo->nameSpace.sPtz, sizeof(deviceInfo->nameSpace.sPtz)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->PTZ->XAddr.c_str());
		}
		if (tds__GetCapabilitiesResponse->Capabilities->Events != NULL){
			//if(tds__GetCapabilitiesResponse->Capabilities->Events->XAddr)
				_snprintf(deviceInfo->nameSpace.sEvent, sizeof(deviceInfo->nameSpace.sEvent)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Events->XAddr.c_str());
		}
		if (tds__GetCapabilitiesResponse->Capabilities->Device != NULL){
			//if(tds__GetCapabilitiesResponse->Capabilities->Device->XAddr)
				_snprintf(deviceInfo->nameSpace.sDevice, sizeof(deviceInfo->nameSpace.sDevice)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Device->XAddr.c_str());
		}
	}else if(SOAP_VERSIONMISMATCH == nGetRes)
	{
		proxyDevice.soap->namespaces = namespaces2;
		if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;//��Ҫ�ٴ���֤
		nGetRes = proxyDevice.GetCapabilities(m_szIP, NULL, tds__GetCapabilities,*tds__GetCapabilitiesResponse);
		if(SOAP_OK == nGetRes)
		{
			nResult = ONVIF_OK;
			if (tds__GetCapabilitiesResponse->Capabilities->Media != NULL){
				//if(tds__GetCapabilitiesResponse->Capabilities->Media->XAddr)
					_snprintf(deviceInfo->nameSpace.sMedia, sizeof(deviceInfo->nameSpace.sMedia)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Media->XAddr.c_str());
			}
			if (tds__GetCapabilitiesResponse->Capabilities->Imaging != NULL){
				//if(tds__GetCapabilitiesResponse->Capabilities->Imaging->XAddr)
					_snprintf(deviceInfo->nameSpace.sImaging, sizeof(deviceInfo->nameSpace.sImaging)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Imaging->XAddr.c_str());
			}
			if (tds__GetCapabilitiesResponse->Capabilities->PTZ != NULL){
				//if(tds__GetCapabilitiesResponse->Capabilities->PTZ->XAddr)
					_snprintf(deviceInfo->nameSpace.sPtz, sizeof(deviceInfo->nameSpace.sPtz)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->PTZ->XAddr.c_str());
			}
			if (tds__GetCapabilitiesResponse->Capabilities->Events != NULL){
				//if(tds__GetCapabilitiesResponse->Capabilities->Events->XAddr)
					_snprintf(deviceInfo->nameSpace.sEvent, sizeof(deviceInfo->nameSpace.sEvent)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Events->XAddr.c_str());
			}
			if (tds__GetCapabilitiesResponse->Capabilities->Device != NULL){
				//if(tds__GetCapabilitiesResponse->Capabilities->Device->XAddr)
					_snprintf(deviceInfo->nameSpace.sDevice, sizeof(deviceInfo->nameSpace.sDevice)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Device->XAddr.c_str());
			}
		}
	}
	else{
		PrintErr("GetCapabilities", proxyDevice.soap);	
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}

	return nResult;
#else
	if(!deviceInfo) return ONVIF_FAIL;	
	
	DeviceBinding proxyDevice;
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyDevice.soap->connect_timeout = 2;// -500000;��������Camera
	proxyDevice.soap->recv_timeout = 3;//-500000;
//	proxyDevice.soap->status = SOAP_POST;
	proxyDevice.endpoint = _strdup(m_szIP);
	_tds__GetCapabilities *tds__GetCapabilities = soap_new__tds__GetCapabilities(m_pSoap,-1);
	tds__GetCapabilities->Category.push_back(tt__CapabilityCategory__All);	
	_tds__GetCapabilitiesResponse *tds__GetCapabilitiesResponse = soap_new__tds__GetCapabilitiesResponse(m_pSoap,-1);

	/*char sOutMsg[256] = {0};
	_snprintf(sOutMsg, sizeof(sOutMsg)-1, "==GetCapabilities===url:%s user:%s pwd:%s====\n", m_szIP, m_szUsername, m_szPassword);
	OutputDebugString(sOutMsg);*/
	
	int nResult = ONVIF_FAIL;
	int nGetRes = proxyDevice.__tds__GetCapabilities(tds__GetCapabilities,tds__GetCapabilitiesResponse);

	if(SOAP_OK == nGetRes){
		//return ONVIF_OK;
		nResult = ONVIF_OK;
		if (tds__GetCapabilitiesResponse->Capabilities->Media != NULL){
			if(tds__GetCapabilitiesResponse->Capabilities->Media->XAddr)
				_snprintf(deviceInfo->nameSpace.sMedia, sizeof(deviceInfo->nameSpace.sMedia)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Media->XAddr);
		}
		if (tds__GetCapabilitiesResponse->Capabilities->Imaging != NULL){
			if(tds__GetCapabilitiesResponse->Capabilities->Imaging->XAddr)
				_snprintf(deviceInfo->nameSpace.sImaging, sizeof(deviceInfo->nameSpace.sImaging)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Imaging->XAddr);
		}
		if (tds__GetCapabilitiesResponse->Capabilities->PTZ != NULL){
			if(tds__GetCapabilitiesResponse->Capabilities->PTZ->XAddr)
				_snprintf(deviceInfo->nameSpace.sPtz, sizeof(deviceInfo->nameSpace.sPtz)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->PTZ->XAddr);
		}
		if (tds__GetCapabilitiesResponse->Capabilities->Events != NULL){
			if(tds__GetCapabilitiesResponse->Capabilities->Events->XAddr)
				_snprintf(deviceInfo->nameSpace.sEvent, sizeof(deviceInfo->nameSpace.sEvent)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Events->XAddr);
		}
		if (tds__GetCapabilitiesResponse->Capabilities->Device != NULL){
			if(tds__GetCapabilitiesResponse->Capabilities->Device->XAddr)
				_snprintf(deviceInfo->nameSpace.sDevice, sizeof(deviceInfo->nameSpace.sDevice)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Device->XAddr);
			/*fprintf(stdout,"\r\n-------------------Device-------------------\r\n");
			fprintf(stdout,"XAddr:%s\r\n",tds__GetCapabilitiesResponse->Capabilities->Device->XAddr);
			
			fprintf(stdout,"\r\n-------------------Network-------------------\r\n");
			fprintf(stdout,"IPFilter:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Network->IPFilter)?"Y":"N");
			fprintf(stdout,"ZeroConfiguration:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Network->ZeroConfiguration)?"Y":"N");
			fprintf(stdout,"IPVersion6:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Network->IPVersion6)?"Y":"N");
			fprintf(stdout,"DynDNS:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Network->DynDNS)?"Y":"N");
			
			fprintf(stdout,"\r\n-------------------System-------------------\r\n");
			fprintf(stdout,"DiscoveryResolve:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->System->DiscoveryResolve)?"Y":"N");
			fprintf(stdout,"DiscoveryBye:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->System->DiscoveryBye)?"Y":"N");
			fprintf(stdout,"RemoteDiscovery:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->System->RemoteDiscovery)?"Y":"N");
			
			int iSize = tds__GetCapabilitiesResponse->Capabilities->Device->System->SupportedVersions.size();
			
			if(iSize > 0)
			{
				fprintf(stdout,"SupportedVersions:");
				
				for(int i = 0;i < iSize; i++)
				{
					fprintf(stdout,"%d.%d ",tds__GetCapabilitiesResponse->Capabilities->Device->System->SupportedVersions[i]->Major,tds__GetCapabilitiesResponse->Capabilities->Device->System->SupportedVersions[i]->Minor);
				}
				
				fprintf(stdout,"\r\n");
			}
			
			fprintf(stdout,"SystemBackup:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->System->SystemBackup)?"Y":"N");
			fprintf(stdout,"FirmwareUpgrade:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->System->FirmwareUpgrade)?"Y":"N");
			fprintf(stdout,"SystemLogging:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->System->SystemLogging)?"Y":"N");
			
			fprintf(stdout,"\r\n-------------------IO-------------------\r\n");
			fprintf(stdout,"InputConnectors:%d\r\n",tds__GetCapabilitiesResponse->Capabilities->Device->IO->InputConnectors);
			fprintf(stdout,"RelayOutputs:%d\r\n",tds__GetCapabilitiesResponse->Capabilities->Device->IO->RelayOutputs);
			
			fprintf(stdout,"\r\n-------------------Security-------------------\r\n");
			fprintf(stdout,"TLS1.1:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Security->TLS1_x002e1)?"Y":"N");
			fprintf(stdout,"TLS1.2:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Security->TLS1_x002e2)?"Y":"N");
			fprintf(stdout,"OnboardKeyGeneration:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Security->OnboardKeyGeneration)?"Y":"N");
			fprintf(stdout,"AccessPolicyConfig:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Security->AccessPolicyConfig)?"Y":"N");
			fprintf(stdout,"X.509Token:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Security->X_x002e509Token)?"Y":"N");
			fprintf(stdout,"SAMLToken:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Security->SAMLToken)?"Y":"N");
			fprintf(stdout,"KerberosToken:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Security->KerberosToken)?"Y":"N");
			fprintf(stdout,"RELToken:%s\r\n",(tds__GetCapabilitiesResponse->Capabilities->Device->Security->RELToken)?"Y":"N");
			*/
		}
	}else if(SOAP_VERSIONMISMATCH == nGetRes)
	{
		proxyDevice.soap->namespaces = namespaces2;
		nGetRes = proxyDevice.__tds__GetCapabilities(tds__GetCapabilities,tds__GetCapabilitiesResponse);
		if(SOAP_OK == nGetRes)
		{
			nResult = ONVIF_OK;
			if (tds__GetCapabilitiesResponse->Capabilities->Media != NULL){
				if(tds__GetCapabilitiesResponse->Capabilities->Media->XAddr)
					_snprintf(deviceInfo->nameSpace.sMedia, sizeof(deviceInfo->nameSpace.sMedia)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Media->XAddr);
			}
			if (tds__GetCapabilitiesResponse->Capabilities->Imaging != NULL){
				if(tds__GetCapabilitiesResponse->Capabilities->Imaging->XAddr)
					_snprintf(deviceInfo->nameSpace.sImaging, sizeof(deviceInfo->nameSpace.sImaging)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Imaging->XAddr);
			}
			if (tds__GetCapabilitiesResponse->Capabilities->PTZ != NULL){
				if(tds__GetCapabilitiesResponse->Capabilities->PTZ->XAddr)
					_snprintf(deviceInfo->nameSpace.sPtz, sizeof(deviceInfo->nameSpace.sPtz)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->PTZ->XAddr);
			}
			if (tds__GetCapabilitiesResponse->Capabilities->Events != NULL){
				if(tds__GetCapabilitiesResponse->Capabilities->Events->XAddr)
					_snprintf(deviceInfo->nameSpace.sEvent, sizeof(deviceInfo->nameSpace.sEvent)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Events->XAddr);
			}
			if (tds__GetCapabilitiesResponse->Capabilities->Device != NULL){
				if(tds__GetCapabilitiesResponse->Capabilities->Device->XAddr)
					_snprintf(deviceInfo->nameSpace.sDevice, sizeof(deviceInfo->nameSpace.sDevice)-1, "%s", tds__GetCapabilitiesResponse->Capabilities->Device->XAddr);
			}
		}
	}
	else{
		//PrintErr(proxyDevice.soap);	
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}

	free((void*)proxyDevice.endpoint);//free
	return nResult;
#endif
}
int COnvifClientSession::GetNetwork(DeviceInfo *deviceInfo)
{
#if 1
	if(!deviceInfo) return ONVIF_FAIL;	

	char szIp[64] = {0};
	int Ip1, Ip2, Ip3, Ip4;
	int nPrefixLen;
	DeviceBindingProxy proxyDevice;
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyDevice.soap->connect_timeout = 5;//2 seconds
	proxyDevice.soap->recv_timeout = 10;

	//////////////////////////////////////////////////////////////////////////
	//get default gateway
	_tds__GetNetworkDefaultGateway *tds__GetGateway = soap_new__tds__GetNetworkDefaultGateway(m_pSoap, -1);
	_tds__GetNetworkDefaultGatewayResponse *tds__GetGatewayResp = soap_new__tds__GetNetworkDefaultGatewayResponse(m_pSoap, -1);
	if (SOAP_OK == proxyDevice.GetNetworkDefaultGateway(m_szIP, NULL, tds__GetGateway, *tds__GetGatewayResp))
	{
		if(tds__GetGatewayResp->NetworkGateway && tds__GetGatewayResp->NetworkGateway->IPv4Address.empty() == false){
			printf("Default Gateway:%s\n", tds__GetGatewayResp->NetworkGateway->IPv4Address[0].c_str());
			sscanf(tds__GetGatewayResp->NetworkGateway->IPv4Address[0].c_str(), "%d.%d.%d.%d", &Ip1, &Ip2, &Ip3, &Ip4);//ȥ��0
			_snprintf(deviceInfo->network.szGateway, sizeof(deviceInfo->network.szGateway)-1, "%d.%d.%d.%d", Ip1, Ip2, Ip3, Ip4);
		}
	}
	else
	{
		PrintErr("GetNetwork GetNetworkDefaultGateway", proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	//////////////////////////////////////////////////////////////////////////
	//get DDNS
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tds__GetDNS *tds__GetDNS = soap_new__tds__GetDNS(m_pSoap, -1);
	_tds__GetDNSResponse *tds__GetDNSResponse = soap_new__tds__GetDNSResponse(m_pSoap, -1);
	if(SOAP_OK == proxyDevice.GetDNS(m_szIP, NULL, tds__GetDNS, *tds__GetDNSResponse))
	{
		if(tds__GetDNSResponse->DNSInformation && tds__GetDNSResponse->DNSInformation->FromDHCP == false){
			if(tds__GetDNSResponse->DNSInformation && tds__GetDNSResponse->DNSInformation->DNSManual.empty() == false &&
				tds__GetDNSResponse->DNSInformation->DNSManual[0]->IPv4Address)
				_snprintf(szIp, sizeof(szIp)-1, "%s", tds__GetDNSResponse->DNSInformation->DNSManual[0]->IPv4Address->c_str());
		}else{
			if(tds__GetDNSResponse->DNSInformation && tds__GetDNSResponse->DNSInformation->DNSFromDHCP.empty() == false &&
				tds__GetDNSResponse->DNSInformation->DNSFromDHCP[0]->IPv4Address)
				_snprintf(szIp, sizeof(szIp)-1, "%s", tds__GetDNSResponse->DNSInformation->DNSFromDHCP[0]->IPv4Address->c_str());
		}
		sscanf(szIp, "%d.%d.%d.%d", &Ip1, &Ip2, &Ip3, &Ip4);//ȥ��0
		_snprintf(deviceInfo->network.szPDNS, sizeof(deviceInfo->network.szPDNS)-1, "%d.%d.%d.%d", Ip1, Ip2, Ip3, Ip4);

	}else{
		PrintErr("GetNetwork GetDNS", proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}
	//////////////////////////////////////////////////////////////////////////
	//Get ip and netmask
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tds__GetNetworkInterfaces *tds__GetNetworkInterfaces = soap_new__tds__GetNetworkInterfaces(m_pSoap, -1);
	_tds__GetNetworkInterfacesResponse *tds__GetNetworkInterfacesResponse = soap_new__tds__GetNetworkInterfacesResponse(m_pSoap, -1);

	if(SOAP_OK == proxyDevice.GetNetworkInterfaces(m_szIP, NULL, tds__GetNetworkInterfaces, *tds__GetNetworkInterfacesResponse))
	{
		if(tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->Enabled == true && 
			tds__GetNetworkInterfacesResponse->NetworkInterfaces.empty() == false &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4 &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->Manual.empty() == false){
				//Enabled
				sscanf(tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->Manual[0]->Address.c_str(), "%d.%d.%d.%d",
					&Ip1, &Ip2, &Ip3, &Ip4);
				nPrefixLen = tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->Manual[0]->PrefixLength;
				//DHCP
		}else if(tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->Enabled == true &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces.empty() == false &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4 &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->DHCP == true &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->FromDHCP){
				sscanf(tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->FromDHCP->Address.c_str(), "%d.%d.%d.%d",
					&Ip1, &Ip2, &Ip3, &Ip4);
				nPrefixLen = tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->FromDHCP->PrefixLength;
		}
	}else{
		PrintErr("GetNetwork GetNetworkInterfaces", proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}
	_snprintf(deviceInfo->network.szIp, sizeof(deviceInfo->network.szIp)-1, "%d.%d.%d.%d", Ip1, Ip2, Ip3, Ip4);
	GetIPFromPrefixLength(nPrefixLen, deviceInfo->network.szNetmask, sizeof(deviceInfo->network.szNetmask));

	//////////////////////////////////////////////////////////////////////////
	//Get network protocol
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tds__GetNetworkProtocols *tds__GetNetworkProtocols = soap_new__tds__GetNetworkProtocols(m_pSoap, -1);
	_tds__GetNetworkProtocolsResponse *tds__GetNetworkProtocolsResponse = soap_new__tds__GetNetworkProtocolsResponse(m_pSoap, -1);
	if(SOAP_OK == proxyDevice.GetNetworkProtocols(m_szIP, NULL, tds__GetNetworkProtocols, *tds__GetNetworkProtocolsResponse)){
		for(int i = 0; i < tds__GetNetworkProtocolsResponse->NetworkProtocols.size(); i++){
			if(tds__GetNetworkProtocolsResponse->NetworkProtocols[i]->Name == tt__NetworkProtocolType__HTTP)
				if(!tds__GetNetworkProtocolsResponse->NetworkProtocols[i]->Port.empty()){
					deviceInfo->network.nHttpPort = tds__GetNetworkProtocolsResponse->NetworkProtocols[i]->Port[0];
				}
				else
				{
					deviceInfo->network.nHttpPort = 80;
				}
		}
	}else{
		PrintErr("GetNetwork GetNetworkProtocols", proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	return ONVIF_OK;
#else
	if(!deviceInfo) return ONVIF_FAIL;	

	char szIp[64] = {0};
	int Ip1, Ip2, Ip3, Ip4;
	int nPrefixLen;
	DeviceBinding proxyDevice;
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyDevice.soap->connect_timeout = 2;//2 seconds
	proxyDevice.soap->recv_timeout = 1;
	proxyDevice.endpoint = _strdup(m_szIP);

	//////////////////////////////////////////////////////////////////////////
	//get default gateway
	_tds__GetNetworkDefaultGateway *tds__GetGateway = soap_new__tds__GetNetworkDefaultGateway(m_pSoap, -1);
	_tds__GetNetworkDefaultGatewayResponse *tds__GetGatewayResp = soap_new__tds__GetNetworkDefaultGatewayResponse(m_pSoap, -1);
	if (SOAP_OK == proxyDevice.__tds__GetNetworkDefaultGateway(tds__GetGateway, tds__GetGatewayResp))
	{
		if(tds__GetGatewayResp->NetworkGateway && tds__GetGatewayResp->NetworkGateway->IPv4Address.empty() == false){
			printf("Default Gateway:%s\n", tds__GetGatewayResp->NetworkGateway->IPv4Address[0].c_str());
			sscanf(tds__GetGatewayResp->NetworkGateway->IPv4Address[0].c_str(), "%d.%d.%d.%d", &Ip1, &Ip2, &Ip3, &Ip4);//ȥ��0
			_snprintf(deviceInfo->network.szGateway, sizeof(deviceInfo->network.szGateway)-1, "%d.%d.%d.%d", Ip1, Ip2, Ip3, Ip4);
		}
	}
	else
	{
		//PrintErr(proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	//////////////////////////////////////////////////////////////////////////
	//get DDNS
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tds__GetDNS *tds__GetDNS = soap_new__tds__GetDNS(m_pSoap, -1);
	_tds__GetDNSResponse *tds__GetDNSResponse = soap_new__tds__GetDNSResponse(m_pSoap, -1);
	if(SOAP_OK == proxyDevice.__tds__GetDNS(tds__GetDNS, tds__GetDNSResponse))
	{
		if(tds__GetDNSResponse->DNSInformation && tds__GetDNSResponse->DNSInformation->FromDHCP == _false){
			//if(tds__GetDNSResponse->DNSInformation->DNSManual[0]->Type == tt__IPType__IPv4)
			//printf("GetDns:%s\n", tds__GetDNSResponse->DNSInformation->DNSManual[0]->IPv4Address->c_str());
			if(tds__GetDNSResponse->DNSInformation && tds__GetDNSResponse->DNSInformation->DNSManual.empty() == false &&
				tds__GetDNSResponse->DNSInformation->DNSManual[0]->IPv4Address)
				_snprintf(szIp, sizeof(szIp)-1, "%s", tds__GetDNSResponse->DNSInformation->DNSManual[0]->IPv4Address->c_str());
		}else{
			//if(tds__GetDNSResponse->DNSInformation->DNSFromDHCP[0]->Type == tt__IPType__IPv4)
			//printf("GetDns:%s\n", tds__GetDNSResponse->DNSInformation->DNSFromDHCP[0]->IPv4Address->c_str());
			if(tds__GetDNSResponse->DNSInformation && tds__GetDNSResponse->DNSInformation->DNSFromDHCP.empty() == false &&
				tds__GetDNSResponse->DNSInformation->DNSFromDHCP[0]->IPv4Address)
				_snprintf(szIp, sizeof(szIp)-1, "%s", tds__GetDNSResponse->DNSInformation->DNSFromDHCP[0]->IPv4Address->c_str());
		}
		sscanf(szIp, "%d.%d.%d.%d", &Ip1, &Ip2, &Ip3, &Ip4);//ȥ��0
		_snprintf(deviceInfo->network.szPDNS, sizeof(deviceInfo->network.szPDNS)-1, "%d.%d.%d.%d", Ip1, Ip2, Ip3, Ip4);

	}else{
		//PrintErr(proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}
	//////////////////////////////////////////////////////////////////////////
	//Get ip and netmask
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tds__GetNetworkInterfaces *tds__GetNetworkInterfaces = soap_new__tds__GetNetworkInterfaces(m_pSoap, -1);
	_tds__GetNetworkInterfacesResponse *tds__GetNetworkInterfacesResponse = soap_new__tds__GetNetworkInterfacesResponse(m_pSoap, -1);

	if(SOAP_OK == proxyDevice.__tds__GetNetworkInterfaces(tds__GetNetworkInterfaces, tds__GetNetworkInterfacesResponse))
	{
		if(tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->Enabled == _true && 
			tds__GetNetworkInterfacesResponse->NetworkInterfaces.empty() == false &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4 &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->Manual.empty() == false){
				//Enabled
				sscanf(tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->Manual[0]->Address.c_str(), "%d.%d.%d.%d",
					&Ip1, &Ip2, &Ip3, &Ip4);
				nPrefixLen = tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->Manual[0]->PrefixLength;
				//DHCP
		}else if(tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->Enabled == _true &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces.empty() == false &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4 &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->DHCP == _true &&
			tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->FromDHCP){
				sscanf(tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->FromDHCP->Address.c_str(), "%d.%d.%d.%d",
					&Ip1, &Ip2, &Ip3, &Ip4);
				nPrefixLen = tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->IPv4->Config->FromDHCP->PrefixLength;
		}
	}else{
		//PrintErr(proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}
	_snprintf(deviceInfo->network.szIp, sizeof(deviceInfo->network.szIp)-1, "%d.%d.%d.%d", Ip1, Ip2, Ip3, Ip4);
	GetIPFromPrefixLength(nPrefixLen, 
		deviceInfo->network.szNetmask, sizeof(deviceInfo->network.szNetmask));

	//////////////////////////////////////////////////////////////////////////
	//Get network protocol
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tds__GetNetworkProtocols *tds__GetNetworkProtocols = soap_new__tds__GetNetworkProtocols(m_pSoap, -1);
	_tds__GetNetworkProtocolsResponse *tds__GetNetworkProtocolsResponse = soap_new__tds__GetNetworkProtocolsResponse(m_pSoap, -1);
	if(SOAP_OK == proxyDevice.__tds__GetNetworkProtocols(tds__GetNetworkProtocols, tds__GetNetworkProtocolsResponse)){
		for(int i = 0; i < tds__GetNetworkProtocolsResponse->NetworkProtocols.size(); i++){
			//OutputDebugString(tds__GetNetworkProtocolsResponse->NetworkProtocols[i]->Name);
			if(tds__GetNetworkProtocolsResponse->NetworkProtocols[i]->Name == tt__NetworkProtocolType__HTTP)
				if(!tds__GetNetworkProtocolsResponse->NetworkProtocols[i]->Port.empty()){
					deviceInfo->network.nHttpPort = tds__GetNetworkProtocolsResponse->NetworkProtocols[i]->Port[0];
				}
				else
				{
					deviceInfo->network.nHttpPort = 80;
				}
		}
	}else{
		//PrintErr(proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	return ONVIF_OK;
#endif
}

int COnvifClientSession::SetNetwork(DeviceInfo *deviceInfo)
{
#if 1
	if(!deviceInfo) return ONVIF_FAIL;	

	DeviceBindingProxy proxyDevice;
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyDevice.soap->recv_timeout = 5;

	//////////////////////////////////////////////////////////////////////////
	//Default gateway
	_tds__SetNetworkDefaultGateway *tds__SetNetworkDefaultGateway = soap_new__tds__SetNetworkDefaultGateway(m_pSoap, -1);
	_tds__SetNetworkDefaultGatewayResponse 	*tds__SetNetworkDefaultGatewayResponse = soap_new__tds__SetNetworkDefaultGatewayResponse(m_pSoap, -1);

	std::string IPv4Address(deviceInfo->network.szGateway);
	tds__SetNetworkDefaultGateway->IPv4Address.push_back(IPv4Address);
	if(SOAP_OK == proxyDevice.SetNetworkDefaultGateway(m_szIP, NULL, tds__SetNetworkDefaultGateway, *tds__SetNetworkDefaultGatewayResponse))
	{

	}
	else
	{
		PrintErr("SetNetwork SetNetworkDefaultGateway", proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}
	//////////////////////////////////////////////////////////////////////////
	//DNS
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tds__SetDNS *tds__SetDNS = soap_new__tds__SetDNS(m_pSoap, -1);
	_tds__SetDNSResponse *tds__SetDNSResponse = soap_new__tds__SetDNSResponse(m_pSoap, -1);
	tds__SetDNS->FromDHCP = false;
	tt__IPAddress DNSManual;
	tds__SetDNS->DNSManual.push_back(&DNSManual);
	std::string dnsIp(deviceInfo->network.szPDNS);
	tds__SetDNS->DNSManual[0]->IPv4Address = &dnsIp;
	if(SOAP_OK == proxyDevice.SetDNS(m_szIP, NULL, tds__SetDNS, *tds__SetDNSResponse))
	{

	}
	else{
		PrintErr("SetNetwork SetDNS", proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	//////////////////////////////////////////////////////////////////////////
	//Set IP
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tds__SetNetworkInterfaces *tds__SetNetworkInterfaces = soap_new__tds__SetNetworkInterfaces(m_pSoap, -1);
	_tds__SetNetworkInterfacesResponse *tds__SetNetworkInterfacesResponse = soap_new__tds__SetNetworkInterfacesResponse(m_pSoap, -1);

	_tds__GetNetworkInterfaces *tds__GetNetworkInterfaces = soap_new__tds__GetNetworkInterfaces(m_pSoap, -1);
	_tds__GetNetworkInterfacesResponse *tds__GetNetworkInterfacesResponse = soap_new__tds__GetNetworkInterfacesResponse(m_pSoap, -1);
	if(SOAP_OK != proxyDevice.GetNetworkInterfaces(m_szIP, NULL, tds__GetNetworkInterfaces, *tds__GetNetworkInterfacesResponse))
		return ONVIF_FAIL;

	if(tds__GetNetworkInterfacesResponse->NetworkInterfaces.empty() == false)
		tds__SetNetworkInterfaces->InterfaceToken = tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->token;//Get Network token;
	else
		tds__SetNetworkInterfaces->InterfaceToken = "";
	tds__SetNetworkInterfaces->NetworkInterface = soap_new_tt__NetworkInterfaceSetConfiguration(m_pSoap, -1);
	tds__SetNetworkInterfaces->NetworkInterface->IPv4 = soap_new_tt__IPv4NetworkInterfaceSetConfiguration(m_pSoap, -1);

	tt__PrefixedIPv4Address Manual;
	tds__SetNetworkInterfaces->NetworkInterface->IPv4->Manual.push_back(&Manual);
	tds__SetNetworkInterfaces->NetworkInterface->IPv4->Manual[0]->Address.assign(deviceInfo->network.szIp);
	tds__SetNetworkInterfaces->NetworkInterface->IPv4->Manual[0]->PrefixLength = GetPrefixLength(deviceInfo->network.szNetmask);
	bool _Enabled = true;bool _DHCP = false;
	tds__SetNetworkInterfaces->NetworkInterface->IPv4->Enabled = &_Enabled;
	tds__SetNetworkInterfaces->NetworkInterface->IPv4->DHCP = &_DHCP;

	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	if (SOAP_OK != proxyDevice.SetNetworkInterfaces(m_szIP, NULL, tds__SetNetworkInterfaces, *tds__SetNetworkInterfacesResponse))
	{//�޸�IP��ض����ش���
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		//������������������������������
	}
	return ONVIF_OK;
#else
	if(!deviceInfo) return ONVIF_FAIL;	

	DeviceBinding proxyDevice;
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyDevice.soap->recv_timeout = 5;
	proxyDevice.endpoint = _strdup(m_szIP);

	//////////////////////////////////////////////////////////////////////////
	//Default gateway
	_tds__SetNetworkDefaultGateway *tds__SetNetworkDefaultGateway = soap_new__tds__SetNetworkDefaultGateway(m_pSoap, -1);
	_tds__SetNetworkDefaultGatewayResponse 	*tds__SetNetworkDefaultGatewayResponse = soap_new__tds__SetNetworkDefaultGatewayResponse(m_pSoap, -1);

	std::string IPv4Address(deviceInfo->network.szGateway);
	tds__SetNetworkDefaultGateway->IPv4Address.push_back(IPv4Address);
	if(SOAP_OK == proxyDevice.__tds__SetNetworkDefaultGateway(tds__SetNetworkDefaultGateway, tds__SetNetworkDefaultGatewayResponse))
	{

	}else
	{
		//PrintErr(proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}
	//////////////////////////////////////////////////////////////////////////
	//DNS
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tds__SetDNS *tds__SetDNS = soap_new__tds__SetDNS(m_pSoap, -1);
	_tds__SetDNSResponse *tds__SetDNSResponse = soap_new__tds__SetDNSResponse(m_pSoap, -1);
	tds__SetDNS->FromDHCP = _false;
	tt__IPAddress DNSManual;
	tds__SetDNS->DNSManual.push_back(&DNSManual);
	std::string dnsIp(deviceInfo->network.szPDNS);
	tds__SetDNS->DNSManual[0]->IPv4Address = &dnsIp;
	if(SOAP_OK == proxyDevice.__tds__SetDNS(tds__SetDNS, tds__SetDNSResponse))
	{

	}
	else{
		//PrintErr(proxyDevice.soap);
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	//////////////////////////////////////////////////////////////////////////
	//Set IP
	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tds__SetNetworkInterfaces *tds__SetNetworkInterfaces = soap_new__tds__SetNetworkInterfaces(m_pSoap, -1);
	_tds__SetNetworkInterfacesResponse *tds__SetNetworkInterfacesResponse = soap_new__tds__SetNetworkInterfacesResponse(m_pSoap, -1);

	_tds__GetNetworkInterfaces *tds__GetNetworkInterfaces = soap_new__tds__GetNetworkInterfaces(m_pSoap, -1);
	_tds__GetNetworkInterfacesResponse *tds__GetNetworkInterfacesResponse = soap_new__tds__GetNetworkInterfacesResponse(m_pSoap, -1);
	if(SOAP_OK != proxyDevice.__tds__GetNetworkInterfaces(tds__GetNetworkInterfaces, tds__GetNetworkInterfacesResponse))
		return ONVIF_FAIL;

	if(tds__GetNetworkInterfacesResponse->NetworkInterfaces.empty() == false)
		tds__SetNetworkInterfaces->InterfaceToken = tds__GetNetworkInterfacesResponse->NetworkInterfaces[0]->token;//Get Network token;
	else
		tds__SetNetworkInterfaces->InterfaceToken = "";
	tds__SetNetworkInterfaces->NetworkInterface = soap_new_tt__NetworkInterfaceSetConfiguration(m_pSoap, -1);
	tds__SetNetworkInterfaces->NetworkInterface->IPv4 = soap_new_tt__IPv4NetworkInterfaceSetConfiguration(m_pSoap, -1);

	tt__PrefixedIPv4Address Manual;
	tds__SetNetworkInterfaces->NetworkInterface->IPv4->Manual.push_back(&Manual);
	tds__SetNetworkInterfaces->NetworkInterface->IPv4->Manual[0]->Address.assign(deviceInfo->network.szIp);
	tds__SetNetworkInterfaces->NetworkInterface->IPv4->Manual[0]->PrefixLength = GetPrefixLength(deviceInfo->network.szNetmask);
	enum xsd__boolean_ Enabled = _true;enum xsd__boolean_ DHCP = _false;
	tds__SetNetworkInterfaces->NetworkInterface->IPv4->Enabled = &Enabled;
	tds__SetNetworkInterfaces->NetworkInterface->IPv4->DHCP = &DHCP;

	if(!Auth(proxyDevice.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	if (SOAP_OK != proxyDevice.__tds__SetNetworkInterfaces(tds__SetNetworkInterfaces, tds__SetNetworkInterfacesResponse))
	{//�޸�IP��ض����ش���
		char *pszError = (char*)*soap_faultstring(proxyDevice.soap);
		if(pszError && strstr(pszError, "Password")) return ONVIF_PWD_INVALID;
		//������������������������������
	}
	return ONVIF_OK;
#endif
}
//////////////////////////////////////////////////////////////////////////
// Media
/*#include "../onvif/soapEventBindingProxy.h"
void COnvifClientSession::MsTest()
{return;
	MediaBinding proxyMedia;
	proxyMedia.soap->connect_timeout = 2;//5 seconds
	proxyMedia.soap->recv_timeout = 10;//bruce.milesight add
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') 
		return;
	proxyMedia.endpoint = _strdup(m_szIP);
	
	_trt__GetMetadataConfigurationOptions *trt_metadataconfigoptions = soap_new__trt__GetMetadataConfigurationOptions(m_pSoap, -1);
	_trt__GetMetadataConfigurationOptionsResponse *trt_resp = soap_new__trt__GetMetadataConfigurationOptionsResponse(m_pSoap, -1);
	proxyMedia.__trt__GetMetadataConfigurationOptions(trt_metadataconfigoptions, trt_resp);

	EventBinding proxyEvent;
	Auth(proxyEvent.soap);
	proxyEvent.endpoint = _strdup(m_szIP);
	_tev__GetEventProperties *tev_event = soap_new__tev__GetEventProperties(m_pSoap, -1);
	_tev__GetEventPropertiesResponse *tev_evetresp = soap_new__tev__GetEventPropertiesResponse(m_pSoap, -1);
	proxyEvent.__ns12__GetEventProperties(tev_event, tev_evetresp);
	
	free((void*)proxyMedia.endpoint);
	free((void*)proxyEvent.endpoint);
}*/
int COnvifClientSession::GetProfiles(DeviceInfo *deviceInfo)
{
#if 1
	if(!deviceInfo) 
		return ONVIF_FAIL;

	MediaBindingProxy proxyMedia;
	proxyMedia.soap->connect_timeout = 5;//5 seconds
	proxyMedia.soap->recv_timeout = 10;//bruce.milesight add
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') 
		return ONVIF_FAIL;

	_trt__GetProfiles *trt__GetProfiles = soap_new__trt__GetProfiles(m_pSoap,-1);
	_trt__GetProfilesResponse *trt__GetProfilesResponse = soap_new__trt__GetProfilesResponse(m_pSoap, -1);
	int nResult = ONVIF_FAIL;
	deviceInfo->nProfileNum = 0;
	if (SOAP_OK == proxyMedia.GetProfiles(m_szIP, NULL, trt__GetProfiles, *trt__GetProfilesResponse))
	{
		nResult = ONVIF_OK;
		for (int i = 0; i < trt__GetProfilesResponse->Profiles.size(); i++)
		{
			deviceInfo->nProfileNum++;
			_snprintf(deviceInfo->profile[i].szToken, sizeof(deviceInfo->profile[i].szToken)-1, "%s", trt__GetProfilesResponse->Profiles[i]->token.c_str());
			if(trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration){
				deviceInfo->profile[i].nCodecType = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->Encoding;
				if(trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->Resolution){
					deviceInfo->profile[i].nWidth = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->Resolution->Width;
					deviceInfo->profile[i].nHeight = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->Resolution->Height;
				}
				if(trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->RateControl){
					deviceInfo->profile[i].nMaxBitrate = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->RateControl->BitrateLimit;
					deviceInfo->profile[i].nFrameRate = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->RateControl->FrameRateLimit;
				}
				_snprintf(deviceInfo->profile[i].videoEncoder.szToken, sizeof(deviceInfo->profile[i].videoEncoder.szToken)-1, "%s", 
					trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->token.c_str());
				deviceInfo->profile[i].videoEncoder.nCodecType = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->Encoding;
			}
		}
	}
	else
	{
		PrintErr("GetProfiles", proxyMedia.soap);	
		char *pszError = (char*)*soap_faultstring(proxyMedia.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	
	return nResult;
#else
	if(!deviceInfo) 
		return ONVIF_FAIL;

	MediaBinding proxyMedia;
	proxyMedia.soap->connect_timeout = 2;//5 seconds
	proxyMedia.soap->recv_timeout = 10;//bruce.milesight add
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') 
		return ONVIF_FAIL;
	proxyMedia.endpoint = _strdup(m_szIP);
	//if(strstr(m_szIP, "4.112"))
	//	proxyMedia.endpoint = _strdup("http://192.168.4.112:80/onvif/Media");

	_trt__GetProfiles *trt__GetProfiles = soap_new__trt__GetProfiles(m_pSoap,-1);
	_trt__GetProfilesResponse *trt__GetProfilesResponse = soap_new__trt__GetProfilesResponse(m_pSoap, -1);
	int nResult = ONVIF_FAIL;
	deviceInfo->nProfileNum = 0;
	if (SOAP_OK == proxyMedia.__trt__GetProfiles(trt__GetProfiles,trt__GetProfilesResponse))
	{
		//OutputDebugString("00000000000000000000000\n");
		nResult = ONVIF_OK;
		//fprintf(stdout,"\r\n-------------------MediaProfiles-------------------\r\n");
		for (int i = 0; i < trt__GetProfilesResponse->Profiles.size(); i++)
		{	//OutputDebugString("1111111111111111111111\n");
			//OutputDebugString(trt__GetProfilesResponse->Profiles[i]->token.c_str());
			//OutputDebugString("\n");
			deviceInfo->nProfileNum++;
			_snprintf(deviceInfo->profile[i].szToken, sizeof(deviceInfo->profile[i].szToken)-1, "%s", trt__GetProfilesResponse->Profiles[i]->token.c_str());
			if(trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration){
				deviceInfo->profile[i].nCodecType = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->Encoding;
				if(trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->Resolution){
					deviceInfo->profile[i].nWidth = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->Resolution->Width;
					deviceInfo->profile[i].nHeight = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->Resolution->Height;
				}
				if(trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->RateControl){
					deviceInfo->profile[i].nMaxBitrate = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->RateControl->BitrateLimit;
					deviceInfo->profile[i].nFrameRate = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->RateControl->FrameRateLimit;
				}
				_snprintf(deviceInfo->profile[i].videoEncoder.szToken, sizeof(deviceInfo->profile[i].videoEncoder.szToken)-1, "%s", 
					trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->token.c_str());
				deviceInfo->profile[i].videoEncoder.nCodecType = trt__GetProfilesResponse->Profiles[i]->VideoEncoderConfiguration->Encoding;
			}
		}
	}
	else
	{
		//PrintErr(proxyMedia.soap);	
		char *pszError = (char*)*soap_faultstring(proxyMedia.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	free((void*)proxyMedia.endpoint);
	return nResult;
#endif
}

int COnvifClientSession::GetStreamUri(DeviceInfo *deviceInfo, int nProfileIndex, char *pszUri, int nLen)
{
	if(!deviceInfo) return ONVIF_FAIL;	
	if(nProfileIndex < 0) nProfileIndex = 0;
	else if(nProfileIndex >= PROFILE_NUM) nProfileIndex = PROFILE_NUM-1;

	return GetStreamUri(deviceInfo->profile[nProfileIndex].szToken, pszUri, nLen);
}

int COnvifClientSession::GetStreamUri(char* pszProfileToken, char *pszUri, int nLen)
{
#if 1
	if(!pszProfileToken || !pszUri) return ONVIF_FAIL;	

	MediaBindingProxy proxyMedia;
	proxyMedia.soap->connect_timeout = 10;
	proxyMedia.soap->recv_timeout = 10;
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_trt__GetStreamUri *trt__GetStreamUri = soap_new__trt__GetStreamUri(m_pSoap, -1);
	trt__GetStreamUri->StreamSetup = soap_new_tt__StreamSetup(m_pSoap, -1);
	trt__GetStreamUri->StreamSetup->Stream = tt__StreamType__RTP_Unicast;
	trt__GetStreamUri->StreamSetup->Transport = soap_new_tt__Transport(m_pSoap, -1);
	trt__GetStreamUri->StreamSetup->Transport->Protocol = tt__TransportProtocol__RTSP;	
	trt__GetStreamUri->ProfileToken.assign(pszProfileToken);

	_trt__GetStreamUriResponse *trt__GetStreamUriResponse = soap_new__trt__GetStreamUriResponse(m_pSoap, -1);
	int nResult = ONVIF_FAIL;
	if (SOAP_OK == proxyMedia.GetStreamUri(m_szIP, NULL, trt__GetStreamUri, *trt__GetStreamUriResponse))
	{
		nResult = ONVIF_OK;
		fprintf(stdout,"RTSP URI:%s\r\n", trt__GetStreamUriResponse->MediaUri->Uri.c_str());	
		_snprintf(pszUri, nLen-1, "%s", trt__GetStreamUriResponse->MediaUri->Uri.c_str());
	}
	else
	{
		PrintErr("GetStreamUri", proxyMedia.soap);	
		char *pszError = (char*)*soap_faultstring(proxyMedia.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}

	return nResult;

#else
	if(!pszProfileToken || !pszUri) return ONVIF_FAIL;	

	MediaBinding proxyMedia;
	proxyMedia.soap->connect_timeout = 10;
	proxyMedia.soap->recv_timeout = 10;
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyMedia.endpoint = _strdup(m_szIP);//malloc

	_trt__GetStreamUri *trt__GetStreamUri = soap_new__trt__GetStreamUri(m_pSoap, -1);
	trt__GetStreamUri->StreamSetup = soap_new_tt__StreamSetup(m_pSoap, -1);
	trt__GetStreamUri->StreamSetup->Stream = tt__StreamType__RTP_Unicast;
	trt__GetStreamUri->StreamSetup->Transport = soap_new_tt__Transport(m_pSoap, -1);
	trt__GetStreamUri->StreamSetup->Transport->Protocol = tt__TransportProtocol__RTSP;	
	trt__GetStreamUri->ProfileToken.assign(pszProfileToken);

	_trt__GetStreamUriResponse *trt__GetStreamUriResponse = soap_new__trt__GetStreamUriResponse(m_pSoap, -1);
	int nResult = ONVIF_FAIL;
	if (SOAP_OK == proxyMedia.__trt__GetStreamUri(trt__GetStreamUri,trt__GetStreamUriResponse))
	{
		nResult = ONVIF_OK;
		fprintf(stdout,"RTSP URI:%s\r\n", trt__GetStreamUriResponse->MediaUri->Uri);	
		_snprintf(pszUri, nLen-1, "%s", trt__GetStreamUriResponse->MediaUri->Uri);
	}
	else
	{
		//PrintErr(proxyMedia.soap);	
		char *pszError = (char*)*soap_faultstring(proxyMedia.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}

	free((void*)proxyMedia.endpoint);
	return nResult;
#endif
}

int COnvifClientSession::GetVideoEncoderConfigOptions(VideoEncoderOptions **pVideoOptions, int *pnSize)
{
#if 1
	MediaBindingProxy proxyMedia;
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	int nCodecNum = 0;
	_trt__GetVideoEncoderConfigurationOptions *pVideoEncoderOptions = soap_new__trt__GetVideoEncoderConfigurationOptions(m_pSoap, -1);
	_trt__GetVideoEncoderConfigurationOptionsResponse *pVideoEncoderOptionsResp = soap_new__trt__GetVideoEncoderConfigurationOptionsResponse(m_pSoap, -1);
	int nResult = ONVIF_FAIL;
	if(SOAP_OK == proxyMedia.GetVideoEncoderConfigurationOptions(m_szIP, NULL, pVideoEncoderOptions, *pVideoEncoderOptionsResp))
	{
		nResult = ONVIF_OK;
		if(!pVideoEncoderOptionsResp->Options)
			return ONVIF_OK;
		if(pVideoEncoderOptionsResp->Options->JPEG)
			nCodecNum += 1;
		if(pVideoEncoderOptionsResp->Options->MPEG4)
			nCodecNum += 1;
		if(pVideoEncoderOptionsResp->Options->H264)
			nCodecNum += 1;
		*pnSize = nCodecNum;
		*pVideoOptions = new VideoEncoderOptions[nCodecNum];
		int i = 0;
		if(pVideoEncoderOptionsResp->Options->JPEG){
			(*pVideoOptions)[i].nCodecType = 0;
			(*pVideoOptions)[i].nResolutionSize = pVideoEncoderOptionsResp->Options->JPEG->ResolutionsAvailable.size();
			(*pVideoOptions)[i].resolutionAvail = new ResolutionAvail[(*pVideoOptions)[i].nResolutionSize];
			for(int j = 0; j < pVideoEncoderOptionsResp->Options->JPEG->ResolutionsAvailable.size(); j++){
				(*pVideoOptions)[i].resolutionAvail[j].nWidth = pVideoEncoderOptionsResp->Options->JPEG->ResolutionsAvailable[j]->Width;
				(*pVideoOptions)[i].resolutionAvail[j].nHeight = pVideoEncoderOptionsResp->Options->JPEG->ResolutionsAvailable[j]->Height;
			}			
		}
		i++;
		if(pVideoEncoderOptionsResp->Options->MPEG4){
			(*pVideoOptions)[i].nCodecType = 1;
			(*pVideoOptions)[i].nResolutionSize = pVideoEncoderOptionsResp->Options->MPEG4->ResolutionsAvailable.size();
			(*pVideoOptions)[i].resolutionAvail = new ResolutionAvail[(*pVideoOptions)[i].nResolutionSize];
			for(int j = 0; j < pVideoEncoderOptionsResp->Options->MPEG4->ResolutionsAvailable.size(); j++){
				(*pVideoOptions)[i].resolutionAvail[j].nWidth = pVideoEncoderOptionsResp->Options->MPEG4->ResolutionsAvailable[j]->Width;
				(*pVideoOptions)[i].resolutionAvail[j].nHeight = pVideoEncoderOptionsResp->Options->MPEG4->ResolutionsAvailable[j]->Height;
			}			
		}
		i++;
		if(pVideoEncoderOptionsResp->Options->H264){
			(*pVideoOptions)[i].nCodecType = 2;
			(*pVideoOptions)[i].nResolutionSize = pVideoEncoderOptionsResp->Options->H264->ResolutionsAvailable.size();
			(*pVideoOptions)[i].resolutionAvail = new ResolutionAvail[(*pVideoOptions)[i].nResolutionSize];
			for(int j = 0; j < pVideoEncoderOptionsResp->Options->H264->ResolutionsAvailable.size(); j++){
				(*pVideoOptions)[i].resolutionAvail[j].nWidth = pVideoEncoderOptionsResp->Options->H264->ResolutionsAvailable[j]->Width;
				(*pVideoOptions)[i].resolutionAvail[j].nHeight = pVideoEncoderOptionsResp->Options->H264->ResolutionsAvailable[j]->Height;
			}			
		}
	}else
	{
		PrintErr("GetVideoEncoderConfigOptions GetVideoEncoderConfigurationOptions", proxyMedia.soap);	
		char *pszError = (char*)*soap_faultstring(proxyMedia.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	
	return nResult;

#else
	//if(!pVideoOptions)
	//	return ONVIF_FAIL;
	MediaBinding proxyMedia;
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyMedia.endpoint = _strdup(m_szIP);//malloc

	int nCodecNum = 0;
	_trt__GetVideoEncoderConfigurationOptions *pVideoEncoderOptions = soap_new__trt__GetVideoEncoderConfigurationOptions(m_pSoap, -1);
	_trt__GetVideoEncoderConfigurationOptionsResponse *pVideoEncoderOptionsResp = soap_new__trt__GetVideoEncoderConfigurationOptionsResponse(m_pSoap, -1);
	int nResult = ONVIF_FAIL;
	if(SOAP_OK == proxyMedia.__trt__GetVideoEncoderConfigurationOptions(pVideoEncoderOptions, pVideoEncoderOptionsResp))
	{
		nResult = ONVIF_OK;
		if(!pVideoEncoderOptionsResp->Options)
			return ONVIF_OK;
		if(pVideoEncoderOptionsResp->Options->JPEG)
			nCodecNum += 1;
		if(pVideoEncoderOptionsResp->Options->MPEG4)
			nCodecNum += 1;
		if(pVideoEncoderOptionsResp->Options->H264)
			nCodecNum += 1;
		*pnSize = nCodecNum;
		*pVideoOptions = new VideoEncoderOptions[nCodecNum];//(VideoEncoderOptions*)malloc(sizeof(VideoEncoderOptions)*nCodecNum);
		int i = 0;
		if(pVideoEncoderOptionsResp->Options->JPEG){
			(*pVideoOptions)[i].nCodecType = 0;
			(*pVideoOptions)[i].nResolutionSize = pVideoEncoderOptionsResp->Options->JPEG->ResolutionsAvailable.size();
			(*pVideoOptions)[i].resolutionAvail = new ResolutionAvail[(*pVideoOptions)[i].nResolutionSize];//(ResolutionAvail*)malloc(sizeof(ResolutionAvail)*pVideoOptions[i].nResolutionSize);
			for(int j = 0; j < pVideoEncoderOptionsResp->Options->JPEG->ResolutionsAvailable.size(); j++){
				(*pVideoOptions)[i].resolutionAvail[j].nWidth = pVideoEncoderOptionsResp->Options->JPEG->ResolutionsAvailable[j]->Width;
				(*pVideoOptions)[i].resolutionAvail[j].nHeight = pVideoEncoderOptionsResp->Options->JPEG->ResolutionsAvailable[j]->Height;
			}			
		}
		i++;
		if(pVideoEncoderOptionsResp->Options->MPEG4){
			(*pVideoOptions)[i].nCodecType = 1;
			(*pVideoOptions)[i].nResolutionSize = pVideoEncoderOptionsResp->Options->MPEG4->ResolutionsAvailable.size();
			(*pVideoOptions)[i].resolutionAvail = new ResolutionAvail[(*pVideoOptions)[i].nResolutionSize];
			for(int j = 0; j < pVideoEncoderOptionsResp->Options->MPEG4->ResolutionsAvailable.size(); j++){
				(*pVideoOptions)[i].resolutionAvail[j].nWidth = pVideoEncoderOptionsResp->Options->MPEG4->ResolutionsAvailable[j]->Width;
				(*pVideoOptions)[i].resolutionAvail[j].nHeight = pVideoEncoderOptionsResp->Options->MPEG4->ResolutionsAvailable[j]->Height;
			}			
		}
		i++;
		if(pVideoEncoderOptionsResp->Options->H264){
			(*pVideoOptions)[i].nCodecType = 2;
			(*pVideoOptions)[i].nResolutionSize = pVideoEncoderOptionsResp->Options->H264->ResolutionsAvailable.size();
			(*pVideoOptions)[i].resolutionAvail = new ResolutionAvail[(*pVideoOptions)[i].nResolutionSize];
			for(int j = 0; j < pVideoEncoderOptionsResp->Options->H264->ResolutionsAvailable.size(); j++){
				(*pVideoOptions)[i].resolutionAvail[j].nWidth = pVideoEncoderOptionsResp->Options->H264->ResolutionsAvailable[j]->Width;
				(*pVideoOptions)[i].resolutionAvail[j].nHeight = pVideoEncoderOptionsResp->Options->H264->ResolutionsAvailable[j]->Height;
			}			
		}
	}else
	{
		//PrintErr(proxyMedia.soap);	
		char *pszError = (char*)*soap_faultstring(proxyMedia.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	free((void*)proxyMedia.endpoint);
	return nResult;
#endif
}

int COnvifClientSession::GetVideoEncoderConfig(DeviceInfo *deviceInfo)
{
#if 1
	if(!deviceInfo)
		return ONVIF_FAIL;
	int nResult = ONVIF_FAIL;
	MediaBindingProxy proxyMedia;
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_trt__GetVideoEncoderConfiguration *pSetVideoEncoderConfig = soap_new__trt__GetVideoEncoderConfiguration(m_pSoap, -1);
	pSetVideoEncoderConfig->ConfigurationToken = "VideoEncoder_2";

	_trt__GetVideoEncoderConfigurationResponse *pResp = soap_new__trt__GetVideoEncoderConfigurationResponse(m_pSoap, -1);
	if(SOAP_OK == proxyMedia.GetVideoEncoderConfiguration(m_szIP, NULL, pSetVideoEncoderConfig, *pResp)){
		nResult = ONVIF_OK;
	}
	else
	{
		PrintErr("GetVideoEncoderConfig GetVideoEncoderConfiguration", proxyMedia.soap);	
		char *pszError = (char*)*soap_faultstring(proxyMedia.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
#else
	if(!deviceInfo)
		return ONVIF_FAIL;
	int nResult = ONVIF_FAIL;
	MediaBinding proxyMedia;
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyMedia.endpoint = _strdup(m_szIP);//malloc

	_trt__GetVideoEncoderConfiguration *pSetVideoEncoderConfig = soap_new__trt__GetVideoEncoderConfiguration(m_pSoap, -1);
	pSetVideoEncoderConfig->ConfigurationToken = "VideoEncoder_2";

	_trt__GetVideoEncoderConfigurationResponse *pResp = soap_new__trt__GetVideoEncoderConfigurationResponse(m_pSoap, -1);
	if(SOAP_OK == proxyMedia.__trt__GetVideoEncoderConfiguration(pSetVideoEncoderConfig, pResp)){
		nResult = ONVIF_OK;
	}else
	{
		//PrintErr(proxyMedia.soap);	
		char *pszError = (char*)*soap_faultstring(proxyMedia.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
#endif
}

int COnvifClientSession::SetVideoEncoderConfig(DeviceInfo *deviceInfo)
{
#if 1
	if(!deviceInfo)
		return ONVIF_FAIL;
	int nResult = ONVIF_FAIL;
	MediaBindingProxy proxyMedia;
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_trt__SetVideoEncoderConfiguration *pSetVideoEncoderConfig = soap_new__trt__SetVideoEncoderConfiguration(m_pSoap, -1);
	pSetVideoEncoderConfig->Configuration = soap_new_tt__VideoEncoderConfiguration(m_pSoap, -1);
	if(deviceInfo->profile[0].nCodecType == 0)
		pSetVideoEncoderConfig->Configuration->Encoding = tt__VideoEncoding__JPEG;
	else if(deviceInfo->profile[0].nCodecType == 1)
		pSetVideoEncoderConfig->Configuration->Encoding = tt__VideoEncoding__MPEG4;
	else 
		pSetVideoEncoderConfig->Configuration->Encoding = tt__VideoEncoding__H264;
	pSetVideoEncoderConfig->Configuration->token = deviceInfo->profile[0].szToken;
	pSetVideoEncoderConfig->Configuration->Resolution = soap_new_tt__VideoResolution(m_pSoap, -1);
	pSetVideoEncoderConfig->Configuration->Resolution->Width = deviceInfo->profile[0].nWidth;
	pSetVideoEncoderConfig->Configuration->Resolution->Height = deviceInfo->profile[0].nHeight;
	pSetVideoEncoderConfig->Configuration->RateControl = soap_new_tt__VideoRateControl(m_pSoap, -1);
	pSetVideoEncoderConfig->Configuration->RateControl->FrameRateLimit = deviceInfo->profile[0].nFrameRate;
	pSetVideoEncoderConfig->Configuration->RateControl->BitrateLimit = deviceInfo->profile[0].nMaxBitrate;
	pSetVideoEncoderConfig->Configuration->MPEG4 = 0;
	pSetVideoEncoderConfig->Configuration->H264 = 0;
	pSetVideoEncoderConfig->Configuration->SessionTimeout = 20;
	pSetVideoEncoderConfig->Configuration->Multicast = 0;
	//pSetVideoEncoderConfig->Configuration->__anyAttribute = 0;�����ᵼ��VMS Server�ҵ�
	_trt__SetVideoEncoderConfigurationResponse *pResp = soap_new__trt__SetVideoEncoderConfigurationResponse(m_pSoap, -1);
	if(SOAP_OK == proxyMedia.SetVideoEncoderConfiguration(m_szIP, NULL, pSetVideoEncoderConfig, *pResp)){
		nResult = ONVIF_OK;
	}
	else
	{
		PrintErr("SetVideoEncoderConfig SetVideoEncoderConfiguration", proxyMedia.soap);	
		char *pszError = (char*)*soap_faultstring(proxyMedia.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
#else
	if(!deviceInfo)
		return ONVIF_FAIL;
	int nResult = ONVIF_FAIL;
	MediaBinding proxyMedia;
	if(!Auth(proxyMedia.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyMedia.endpoint = _strdup(m_szIP);//malloc

	_trt__SetVideoEncoderConfiguration *pSetVideoEncoderConfig = soap_new__trt__SetVideoEncoderConfiguration(m_pSoap, -1);
	pSetVideoEncoderConfig->Configuration = soap_new_tt__VideoEncoderConfiguration(m_pSoap, -1);
	if(deviceInfo->profile[0].nCodecType == 0)
		pSetVideoEncoderConfig->Configuration->Encoding = tt__VideoEncoding__JPEG;
	else if(deviceInfo->profile[0].nCodecType == 1)
		pSetVideoEncoderConfig->Configuration->Encoding = tt__VideoEncoding__MPEG4;
	else 
		pSetVideoEncoderConfig->Configuration->Encoding = tt__VideoEncoding__H264;
	pSetVideoEncoderConfig->Configuration->token = deviceInfo->profile[0].szToken;
	pSetVideoEncoderConfig->Configuration->Resolution = soap_new_tt__VideoResolution(m_pSoap, -1);
	pSetVideoEncoderConfig->Configuration->Resolution->Width = deviceInfo->profile[0].nWidth;
	pSetVideoEncoderConfig->Configuration->Resolution->Height = deviceInfo->profile[0].nHeight;
	pSetVideoEncoderConfig->Configuration->RateControl = soap_new_tt__VideoRateControl(m_pSoap, -1);
	pSetVideoEncoderConfig->Configuration->RateControl->FrameRateLimit = deviceInfo->profile[0].nFrameRate;
	pSetVideoEncoderConfig->Configuration->RateControl->BitrateLimit = deviceInfo->profile[0].nMaxBitrate;
	pSetVideoEncoderConfig->Configuration->MPEG4 = 0;
	pSetVideoEncoderConfig->Configuration->H264 = 0;
	pSetVideoEncoderConfig->Configuration->SessionTimeout = "PT10S";
	pSetVideoEncoderConfig->Configuration->Multicast = 0;
	//	pSetVideoEncoderConfig->Configuration->__any = NULL;
	pSetVideoEncoderConfig->Configuration->__anyAttribute = 0;
	_trt__SetVideoEncoderConfigurationResponse *pResp = soap_new__trt__SetVideoEncoderConfigurationResponse(m_pSoap, -1);
	if(SOAP_OK == proxyMedia.__trt__SetVideoEncoderConfiguration(pSetVideoEncoderConfig, pResp)){
		nResult = ONVIF_OK;
	}else
	{
		//PrintErr(proxyMedia.soap);	
		char *pszError = (char*)*soap_faultstring(proxyMedia.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
#endif
}
//////////////////////////////////////////////////////////////////////////
//PTZ
float GetPanTiltX(int nDirect, float fValue)
{
	switch(nDirect)
	{
	case PTZ_DIR_TOP:
	case PTZ_DIR_BOTTOM:
		return 0.000000;
	case PTZ_DIR_LEFT:
	case PTZ_DIR_TOPLEFT:
	case PTZ_DIR_BOTTOMLEFT:
		return -fValue;
	case PTZ_DIR_RIGHT:
	case PTZ_DIR_TOPRIGHT:
	case PTZ_DIR_BOTTOMRIGHT:
		return fValue;
	default:
	    break;
	}
	return 0.000000;
}
float GetPanTiltY(int nDirect, float fValue)
{
	switch(nDirect)
	{
	case PTZ_DIR_LEFT:
	case PTZ_DIR_RIGHT:
		return 0.000000;
	case PTZ_DIR_TOP:
	case PTZ_DIR_TOPLEFT:
	case PTZ_DIR_TOPRIGHT:
		return fValue;
	case PTZ_DIR_BOTTOM:
	case PTZ_DIR_BOTTOMLEFT:
	case PTZ_DIR_BOTTOMRIGHT:
		return -fValue;
	default:
	    break;
	}
	return 0.000000;
}
//fValue:Speed for pantilt, value for zoom
#define PTZ_CONN_TIMEOUT (-300000)
#define	PTZ_RECV_TIMEOUT (-300000)
int COnvifClientSession::MovePtz(int nDirect, float fValue, int nMoveType /* = 0 */)
{
#if 1
// 	OutputDebugString(m_szProfileToken);
// 	OutputDebugString("MovePtz\n");
	int nResult = ONVIF_FAIL;
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	switch(nMoveType){	
	case PTZ_RELATIVE_MOVE:
		{
			_tptz__RelativeMove *tptz__RelativeMove = soap_new__tptz__RelativeMove(m_pSoap, -1);
			_tptz__RelativeMoveResponse *tptz__RelativeMoveResp = soap_new__tptz__RelativeMoveResponse(m_pSoap, -1);
			tptz__RelativeMove->ProfileToken.assign(m_szProfileToken);
			std::string zoom_space = "http://www.onvif.org/ver10/tptz/ZoomSpaces/TranslationGenericSpace";
			std::string pantilt_space = "http://www.onvif.org/ver10/tptz/PanTiltSpaces/TranslationGenericSpace";
			tptz__RelativeMove->Translation = soap_new_tt__PTZVector(m_pSoap, -1);
			if(nDirect == PTZ_ZOOM_OUT || nDirect == PTZ_ZOOM_IN){
				tptz__RelativeMove->Translation->Zoom = soap_new_tt__Vector1D(m_pSoap, -1);
				if(nDirect == PTZ_ZOOM_OUT)
					tptz__RelativeMove->Translation->Zoom->x = -fValue;
				else if(nDirect == PTZ_ZOOM_IN)
					tptz__RelativeMove->Translation->Zoom->x = fValue;
				tptz__RelativeMove->Translation->Zoom->space = &zoom_space;
			}else{
				tptz__RelativeMove->Translation->PanTilt = soap_new_tt__Vector2D(m_pSoap, -1);
				tptz__RelativeMove->Translation->PanTilt->x = GetPanTiltX(nDirect, fValue);
				tptz__RelativeMove->Translation->PanTilt->y = GetPanTiltY(nDirect, fValue);
				tptz__RelativeMove->Translation->PanTilt->space = &pantilt_space;
			}

			if(SOAP_OK == proxyPtz.RelativeMove(m_szIP, NULL, tptz__RelativeMove, *tptz__RelativeMoveResp))
				nResult = SOAP_OK;
			else{
				nResult = SOAP_OK;
			}
		}
		break;
	case PTZ_ABSOLUTION_MOVE:
	case PTZ_CONTINUOUS_MOVE:
		{
			_tptz__ContinuousMove *tptz__ContinuousMove = soap_new__tptz__ContinuousMove(m_pSoap, -1);
			LONG64 _timeout = 60;
			tptz__ContinuousMove->Timeout = &_timeout;
			tptz__ContinuousMove->ProfileToken.assign(m_szProfileToken);
			tptz__ContinuousMove->Velocity = soap_new_tt__PTZSpeed(m_pSoap, -1);
			std::string pantilt_space = "http://www.onvif.org/ver10/tptz/PanTiltSpaces/VelocityGenericSpace";
			if(nDirect == PTZ_ZOOM_OUT || nDirect == PTZ_ZOOM_IN){
				tptz__ContinuousMove->Velocity->Zoom = soap_new_tt__Vector1D(m_pSoap, -1);
				if(nDirect == PTZ_ZOOM_OUT)
					tptz__ContinuousMove->Velocity->Zoom->x = -fValue;
				else if(nDirect == PTZ_ZOOM_IN)
					tptz__ContinuousMove->Velocity->Zoom->x = fValue;
			}else{
				tptz__ContinuousMove->Velocity->PanTilt = soap_new_tt__Vector2D(m_pSoap, -1);
				tptz__ContinuousMove->Velocity->PanTilt->x = GetPanTiltX(nDirect, fValue);
				tptz__ContinuousMove->Velocity->PanTilt->y = GetPanTiltY(nDirect, fValue);
				tptz__ContinuousMove->Velocity->PanTilt->space = &pantilt_space;
			}

			_tptz__ContinuousMoveResponse *tptz__ContinuousMoveResponse = soap_new__tptz__ContinuousMoveResponse(m_pSoap, -1);
			if(SOAP_OK == proxyPtz.ContinuousMove(m_szIP, NULL, tptz__ContinuousMove, *tptz__ContinuousMoveResponse)){
				nResult = SOAP_OK;
			}else{
				PrintErr("MovePtz ContinuousMove", proxyPtz.soap);	
				char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
				if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
				else nResult = ONVIF_FAIL;
			}
		}
		break;
	default:
		break;
	}

	return nResult;

#else
	OutputDebugString(m_szProfileToken);
	OutputDebugString("MovePtz\n");
	int nResult = ONVIF_FAIL;
	PTZBinding proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyPtz.endpoint = _strdup(m_szIP);
	//nMoveType = PTZ_RELATIVE_MOVE;//test
	switch(nMoveType){	
	case PTZ_RELATIVE_MOVE:
		{
			_tptz__RelativeMove *tptz__RelativeMove = soap_new__tptz__RelativeMove(m_pSoap, -1);
			_tptz__RelativeMoveResponse *tptz__RelativeMoveResp = soap_new__tptz__RelativeMoveResponse(m_pSoap, -1);
			tptz__RelativeMove->ProfileToken.assign(m_szProfileToken);
			tptz__RelativeMove->Translation = soap_new_tt__PTZVector(m_pSoap, -1);
			if(nDirect == PTZ_ZOOM_OUT || nDirect == PTZ_ZOOM_IN){
				tptz__RelativeMove->Translation->Zoom = soap_new_tt__Vector1D(m_pSoap, -1);
				if(nDirect == PTZ_ZOOM_OUT)
					tptz__RelativeMove->Translation->Zoom->x = -fValue;
				else if(nDirect == PTZ_ZOOM_IN)
					tptz__RelativeMove->Translation->Zoom->x = fValue;
				tptz__RelativeMove->Translation->Zoom->space = "http://www.onvif.org/ver10/tptz/ZoomSpaces/TranslationGenericSpace";
			}else{
// 				tptz__RelativeMove->Translation->Zoom = soap_new_tt__Vector1D(m_pSoap, -1);
// 				tptz__RelativeMove->Translation->Zoom->x = 1;
// 				tptz__RelativeMove->Translation->Zoom->space = "http://www.onvif.org/ver10/tptz/ZoomSpaces/TranslationGenericSpace";
				tptz__RelativeMove->Translation->PanTilt = soap_new_tt__Vector2D(m_pSoap, -1);
				tptz__RelativeMove->Translation->PanTilt->x = GetPanTiltX(nDirect, fValue);
				tptz__RelativeMove->Translation->PanTilt->y = GetPanTiltY(nDirect, fValue);
				tptz__RelativeMove->Translation->PanTilt->space = "http://www.onvif.org/ver10/tptz/PanTiltSpaces/TranslationGenericSpace";
			}

			if(SOAP_OK == proxyPtz.__tptz__RelativeMove(tptz__RelativeMove, tptz__RelativeMoveResp))
				nResult = SOAP_OK;
			else{
				nResult = SOAP_OK;
				/*PrintErr(proxyPtz.soap);	
				char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
				if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
				else nResult = ONVIF_FAIL;*/
			}
		}
		break;
	case PTZ_ABSOLUTION_MOVE:
	case PTZ_CONTINUOUS_MOVE:
		{
			_tptz__ContinuousMove *tptz__ContinuousMove = soap_new__tptz__ContinuousMove(m_pSoap, -1);
			tptz__ContinuousMove->Timeout = "PT60S";
			tptz__ContinuousMove->ProfileToken.assign(m_szProfileToken);
			tptz__ContinuousMove->Velocity = soap_new_tt__PTZSpeed(m_pSoap, -1);
			if(nDirect == PTZ_ZOOM_OUT || nDirect == PTZ_ZOOM_IN){
				tptz__ContinuousMove->Velocity->Zoom = soap_new_tt__Vector1D(m_pSoap, -1);
				if(nDirect == PTZ_ZOOM_OUT)
					tptz__ContinuousMove->Velocity->Zoom->x = -fValue;
				else if(nDirect == PTZ_ZOOM_IN)
					tptz__ContinuousMove->Velocity->Zoom->x = fValue;
			}else{
				tptz__ContinuousMove->Velocity->PanTilt = soap_new_tt__Vector2D(m_pSoap, -1);
				tptz__ContinuousMove->Velocity->PanTilt->x = GetPanTiltX(nDirect, fValue);
				tptz__ContinuousMove->Velocity->PanTilt->y = GetPanTiltY(nDirect, fValue);
				tptz__ContinuousMove->Velocity->PanTilt->space = "http://www.onvif.org/ver10/tptz/PanTiltSpaces/VelocityGenericSpace";
			}

			_tptz__ContinuousMoveResponse *tptz__ContinuousMoveResponse = soap_new__tptz__ContinuousMoveResponse(m_pSoap, -1);
			if(SOAP_OK == proxyPtz.__tptz__ContinuousMove(tptz__ContinuousMove, tptz__ContinuousMoveResponse)){
				nResult = SOAP_OK;
			}else{
				//PrintErr(proxyPtz.soap);	
				char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
				if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
				else nResult = ONVIF_FAIL;
			}
		}
		break;
	default:
		break;
	}

	free((void*)proxyPtz.endpoint);
	return nResult;
#endif
}

int COnvifClientSession::StopPtz()
{
#if 1
// 	OutputDebugString(m_szProfileToken);
// 	OutputDebugString("\n");	
	int nResult = ONVIF_FAIL;
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__Stop *tptz_Stop = soap_new__tptz__Stop(m_pSoap, -1);
	tptz_Stop->ProfileToken.assign(m_szProfileToken);
	bool _PanTilt = true;
	bool _Zoom = true;
	tptz_Stop->PanTilt = &_PanTilt;
	tptz_Stop->Zoom =  &_Zoom;

	_tptz__StopResponse *tptz_StopResp = soap_new__tptz__StopResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.Stop(m_szIP, NULL, tptz_Stop, *tptz_StopResp)){
		nResult = ONVIF_OK;
	}else{
		PrintErr("StopPtz Stop", proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}

	return nResult;
#else
	OutputDebugString(m_szProfileToken);
	OutputDebugString("\n");	
	int nResult = ONVIF_FAIL;
	PTZBinding proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyPtz.endpoint = _strdup(m_szIP);

	_tptz__Stop *tptz_Stop = soap_new__tptz__Stop(m_pSoap, -1);
	tptz_Stop->ProfileToken.assign(m_szProfileToken);
	enum xsd__boolean_ PanTilt = _true;
	enum xsd__boolean_ Zoom = _true;
	tptz_Stop->PanTilt = &PanTilt;
	tptz_Stop->Zoom =  &Zoom;

	_tptz__StopResponse *tptz_StopResp = soap_new__tptz__StopResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.__tptz__Stop(tptz_Stop, tptz_StopResp)){
		nResult = ONVIF_OK;
	}else{
		//PrintErr(proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}

	free((void*)proxyPtz.endpoint);
	return nResult;
#endif
}

int COnvifClientSession::GetPtzPresets(PresetInfo* PresetList, int nCount)
{
	if(!PresetList) return ONVIF_FAIL;
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	soap_set_mode(proxyPtz.soap, SOAP_C_UTFSTRING);
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__GetPresets *tptz__GetPresets = soap_new__tptz__GetPresets(m_pSoap, -1);
	_tptz__GetPresetsResponse *tptz__GetPresetsResponse = soap_new__tptz__GetPresetsResponse(m_pSoap, -1);
	tptz__GetPresets->ProfileToken.assign(m_szProfileToken);

	if(SOAP_OK == proxyPtz.GetPresets(m_szIP, NULL, tptz__GetPresets, *tptz__GetPresetsResponse)){
		nResult = ONVIF_OK;
		int nSize = tptz__GetPresetsResponse->Preset.size();
		char sIndex[32] = {0};
		int totalCnt = min(nSize, nCount);
		for (int i=0; i<totalCnt; i++)
		{
			_snprintf(sIndex, sizeof(sIndex)-1, "%s", tptz__GetPresetsResponse->Preset[i]->token->c_str());
			PresetList[i].nIndex = atoi(sIndex);
			if (PresetList[i].nIndex > 0)
			{
				_snprintf(PresetList[i].sName, sizeof(PresetList[i].sName)-1, "%s", tptz__GetPresetsResponse->Preset[i]->Name->c_str());
			} 
		}
	}
	else{
		PrintErr("GetPtzPresets GetPresets", proxyPtz.soap);
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
}

int COnvifClientSession::SetPtzPreset(int nIndex)
{
#if 1
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__SetPreset *tptz__SetPreset = soap_new__tptz__SetPreset(m_pSoap, -1);
	itoa(nIndex, szIndex, 10);
	std::string PresetToken = szIndex;
	tptz__SetPreset->PresetToken = &PresetToken;
	tptz__SetPreset->ProfileToken.assign(m_szProfileToken);
	_tptz__SetPresetResponse *tptz__SetPresetResponse = soap_new__tptz__SetPresetResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.SetPreset(m_szIP, NULL, tptz__SetPreset, *tptz__SetPresetResponse)){
		nResult = ONVIF_OK;
	}else{
		PrintErr("SetPtzPreset SetPreset", proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
#else
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBinding proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyPtz.endpoint = _strdup(m_szIP);

	_tptz__SetPreset *tptz__SetPreset = soap_new__tptz__SetPreset(m_pSoap, -1);
	itoa(nIndex, szIndex, 10);
	std::string PresetToken = szIndex;
	tptz__SetPreset->PresetToken = &PresetToken;
	tptz__SetPreset->ProfileToken.assign(m_szProfileToken);
	_tptz__SetPresetResponse *tptz__SetPresetResponse = soap_new__tptz__SetPresetResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.__tptz__SetPreset(tptz__SetPreset, tptz__SetPresetResponse)){
		nResult = ONVIF_OK;
	}else{
		//PrintErr(proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
#endif
}

int COnvifClientSession::RenamePtzPreset(int nIndex, char *sName)
{
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__SetPreset *tptz__SetPreset = soap_new__tptz__SetPreset(m_pSoap, -1);
	itoa(nIndex, szIndex, 10);
	std::string PresetToken = szIndex;
	tptz__SetPreset->PresetToken = &PresetToken;
	std::string PresetName = sName;
	tptz__SetPreset->PresetName = &PresetName;
	tptz__SetPreset->ProfileToken.assign(m_szProfileToken);
	_tptz__SetPresetResponse *tptz__SetPresetResponse = soap_new__tptz__SetPresetResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.SetPreset(m_szIP, NULL, tptz__SetPreset, *tptz__SetPresetResponse)){
		nResult = ONVIF_OK;
	}else{
		PrintErr("RenamePtzPreset SetPreset", proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
}

int COnvifClientSession::RemovePtzPreset(int nIndex)
{
#if 1
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__RemovePreset *tptz__RemovePreset = soap_new__tptz__RemovePreset(m_pSoap, -1);
	itoa(nIndex, szIndex, 10);
	std::string PresetToken = szIndex;
	tptz__RemovePreset->PresetToken = PresetToken;
	tptz__RemovePreset->ProfileToken.assign(m_szProfileToken);
	_tptz__RemovePresetResponse *tptz__RemovePresetResponse = soap_new__tptz__RemovePresetResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.RemovePreset(m_szIP, NULL, tptz__RemovePreset, *tptz__RemovePresetResponse)){
		nResult = ONVIF_OK;
	}else{
		PrintErr("RemovePtzPreset RemovePreset", proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
#else
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBinding proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyPtz.endpoint = _strdup(m_szIP);

	_tptz__RemovePreset *tptz__RemovePreset = soap_new__tptz__RemovePreset(m_pSoap, -1);
	itoa(nIndex, szIndex, 10);
	std::string PresetToken = szIndex;
	tptz__RemovePreset->PresetToken = PresetToken;
	tptz__RemovePreset->ProfileToken.assign(m_szProfileToken);
	_tptz__RemovePresetResponse *tptz__RemovePresetResponse = soap_new__tptz__RemovePresetResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.__tptz__RemovePreset(tptz__RemovePreset, tptz__RemovePresetResponse)){
		nResult = ONVIF_OK;
	}else{
		//PrintErr(proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
#endif
}

int COnvifClientSession::GotoPtzPreset(int nIndex)
{
#if 1
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__GotoPreset *tptz__GotoPreset = soap_new__tptz__GotoPreset(m_pSoap, -1);
	itoa(nIndex, szIndex, 10);
	std::string PresetToken = szIndex;
	tptz__GotoPreset->ProfileToken.assign(m_szProfileToken);
	tptz__GotoPreset->PresetToken = PresetToken;
	_tptz__GotoPresetResponse *tptz__GotoPresetResponse = soap_new__tptz__GotoPresetResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.GotoPreset(m_szIP, NULL, tptz__GotoPreset, *tptz__GotoPresetResponse)){
		nResult = ONVIF_OK;
	}else{
		PrintErr("GotoPtzPreset GotoPreset", proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
#else
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBinding proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyPtz.endpoint = _strdup(m_szIP);

	_tptz__GotoPreset *tptz__GotoPreset = soap_new__tptz__GotoPreset(m_pSoap, -1);
	itoa(nIndex, szIndex, 10);
	std::string PresetToken = szIndex;
	tptz__GotoPreset->ProfileToken.assign(m_szProfileToken);
	tptz__GotoPreset->PresetToken = PresetToken;
	_tptz__GotoPresetResponse *tptz__GotoPresetResponse = soap_new__tptz__GotoPresetResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.__tptz__GotoPreset(tptz__GotoPreset, tptz__GotoPresetResponse)){
		nResult = ONVIF_OK;
	}else{
		//PrintErr(proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
#endif
}

int COnvifClientSession::GetPtzPresetTours(PresetTourInfo *tourList, int nCount)
{
	if(!tourList) return ONVIF_FAIL;
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__GetPresetTours *tptz__GetPresetTours = soap_new__tptz__GetPresetTours(m_pSoap, -1);
	_tptz__GetPresetToursResponse *tptz__GetPresetToursResponse = soap_new__tptz__GetPresetToursResponse(m_pSoap, -1);
	tptz__GetPresetTours->ProfileToken.assign(m_szProfileToken);

	if(SOAP_OK == proxyPtz.GetPresetTours(m_szIP, NULL, tptz__GetPresetTours, *tptz__GetPresetToursResponse)){
		nResult = ONVIF_OK;
		int nSize = tptz__GetPresetToursResponse->PresetTour.size();
		int totalCnt = min(nSize, nCount);
		char sTour[64] = {0};
		for (int i=0; i<totalCnt; i++)
		{
			_snprintf(tourList[i].sToken, sizeof(tourList[i].sToken)-1, "%s", tptz__GetPresetToursResponse->PresetTour[i]->token->c_str());
			sscanf(tptz__GetPresetToursResponse->PresetTour[i]->token->c_str(), "%[^0-9]%d", sTour, &tourList[i].nIndex);
			tourList[i].bTourSet = !tptz__GetPresetToursResponse->PresetTour[i]->TourSpot.empty();
			if (tptz__GetPresetToursResponse->PresetTour[i]->Status->State == tt__PTZPresetTourState__Touring)
			{
				tourList[i].bTouring = true;
			}
			else
			{
				tourList[i].bTouring = false;
			}
//			OutputDebugString(tptz__GetPresetToursResponse->PresetTour[i]->token->c_str());
//			tourList[i].nIndex = atoi(tourList[i].sIndex);
// 			if (tourList[i].nIndex > 0)
// 			{
//				_snprintf(tourList[i].sName, sizeof(tourList[i].sName)-1, "%s", tptz__GetPresetToursResponse->PresetTour[i]->Name->c_str());
//			} 
		}
	}
	else{
		PrintErr("GetPtzPresetTours GetPresetTours", proxyPtz.soap);
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
}

int COnvifClientSession::GetPtzPresetTour(char *sPresetTourToken, TourInfo *resTourToken, int nCount)
{
	if(!sPresetTourToken) return ONVIF_FAIL;
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__GetPresetTour *tptz__GetPresetTour = soap_new__tptz__GetPresetTour(m_pSoap, -1);
	_tptz__GetPresetTourResponse *tptz__GetPresetTourResponse = soap_new__tptz__GetPresetTourResponse(m_pSoap, -1);
	tptz__GetPresetTour->ProfileToken.assign(m_szProfileToken);
	tptz__GetPresetTour->PresetTourToken = sPresetTourToken;

	if(SOAP_OK == proxyPtz.GetPresetTour(m_szIP, NULL, tptz__GetPresetTour, *tptz__GetPresetTourResponse)){
		nResult = ONVIF_OK;
		int nSize = tptz__GetPresetTourResponse->PresetTour->TourSpot.size();
		char sName[32] = {0};
		int totalCnt = min(nSize, nCount);
		for (int i=0; i<totalCnt; i++)
		{
			resTourToken[i].nStayTime = (*(tptz__GetPresetTourResponse->PresetTour->TourSpot[i]->StayTime))/1000;
			resTourToken[i].nIndex = atoi(tptz__GetPresetTourResponse->PresetTour->TourSpot[i]->PresetDetail->union_PTZPresetTourPresetDetail.PresetToken->c_str());
			resTourToken[i].nSpeed = (int)(((tptz__GetPresetTourResponse->PresetTour->TourSpot[i]->Speed->PanTilt->x) * 4) * ANTI_RATIO);
		}
	}
	else{
		PrintErr("GetPtzPresetTour GetPresetTour", proxyPtz.soap);
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
}

int COnvifClientSession::ModifyPtzPresetTour(char *sPresetTourToken, TourInfo *resTourToken, int nCount)
{
	if(!resTourToken || !sPresetTourToken) return ONVIF_FAIL;	

	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__ModifyPresetTour *tptz__ModifyPresetTour = soap_new__tptz__ModifyPresetTour(m_pSoap, -1);
	_tptz__ModifyPresetTourResponse *tptz__ModifyPresetTourResponse = soap_new__tptz__ModifyPresetTourResponse(m_pSoap, -1);
	tt__PresetTour *_PresetTour = NULL;

	//////////////////////////////////////////////////////////////////////////
	_tptz__GetPresetTours *tptz__GetPresetTours = soap_new__tptz__GetPresetTours(m_pSoap, -1);
	_tptz__GetPresetToursResponse *tptz__GetPresetToursResponse = soap_new__tptz__GetPresetToursResponse(m_pSoap, -1);
	tptz__GetPresetTours->ProfileToken.assign(m_szProfileToken);
	if(SOAP_OK == proxyPtz.GetPresetTours(m_szIP, NULL, tptz__GetPresetTours, *tptz__GetPresetToursResponse))
	{
		int nSize = tptz__GetPresetToursResponse->PresetTour.size();
		for (int i=0; i<nSize; i++)
		{
			if (strcmp(sPresetTourToken, tptz__GetPresetToursResponse->PresetTour[i]->token->c_str()) == 0)
			{
				_PresetTour = tptz__GetPresetToursResponse->PresetTour[i];
				break;
			}
		}
	}
	else
	{
		return ONVIF_FAIL;
	}
	
	if (_PresetTour == NULL)
	{
		return ONVIF_FAIL;
	}
	_PresetTour->TourSpot.clear();
	LONG64 *tmpStayTime = new LONG64[nCount];
	std::vector<std::string> tmpToken;
	char sToken[64] = {0};
	for (int j=0; j<nCount; j++)
	{
		tt__PTZPresetTourSpot *_TourSpot = soap_new_tt__PTZPresetTourSpot(m_pSoap, -1);
		//_TourSpot->soap_default(proxyPtz.soap);
		tt__Vector2D *_PanTilt = soap_new_tt__Vector2D(m_pSoap, -1);
		//_PanTilt->soap_default(proxyPtz.soap);
		_PanTilt->x = ((float)(resTourToken[j].nSpeed))/ANTI_RATIO/4;
		_PanTilt->y = ((float)(resTourToken[j].nSpeed))/ANTI_RATIO/4;
		tt__Vector1D *_Zoom = soap_new_tt__Vector1D(m_pSoap, -1);
		//_Zoom->soap_default(proxyPtz.soap);
		_Zoom->x = ((float)(resTourToken[j].nSpeed))/ANTI_RATIO/4;
		tt__PTZSpeed *_Speed = soap_new_tt__PTZSpeed(m_pSoap, -1);
		//_Speed->soap_default(proxyPtz.soap);
		_Speed->PanTilt = _PanTilt;
		_Speed->Zoom = _Zoom;
		_TourSpot->Speed = _Speed;

		tmpStayTime[j] = resTourToken[j].nStayTime * 1000;
		_TourSpot->StayTime = &tmpStayTime[j];
		LONG64 tmpTime = *_TourSpot->StayTime;

		tt__PTZPresetTourPresetDetail *_PresetDetail = soap_new_tt__PTZPresetTourPresetDetail(m_pSoap, -1);
		//_PresetDetail->soap_default(proxyPtz.soap);
		_PresetDetail->__union_PTZPresetTourPresetDetail = 1;
		itoa(resTourToken[j].nIndex, sToken, 10);
		_PresetDetail->union_PTZPresetTourPresetDetail.PresetToken = new std::string(sToken);
		char sTmpToken[64] = {0};
		_snprintf(sTmpToken, 63, "%s", _PresetDetail->union_PTZPresetTourPresetDetail.PresetToken->c_str());
		_TourSpot->PresetDetail = _PresetDetail;

		_PresetTour->TourSpot.push_back(_TourSpot);
	}
	//////////////////////////////////////////////////////////////////////////

	tptz__ModifyPresetTour->ProfileToken.assign(m_szProfileToken);
	tptz__ModifyPresetTour->PresetTour = _PresetTour;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;//��Ҫ�ٴ���֤
	if(SOAP_OK == proxyPtz.ModifyPresetTour(m_szIP, NULL, tptz__ModifyPresetTour, *tptz__ModifyPresetTourResponse)){
		if (tmpStayTime)
		{
			delete []tmpStayTime;
			tmpStayTime = NULL;
		}
		return ONVIF_OK;
	}else{
		if (tmpStayTime)
		{
			delete []tmpStayTime;
			tmpStayTime = NULL;
		}
		PrintErr("ModifyPtzPresetTour ModifyPresetTour", proxyPtz.soap);
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;

	}
	return ONVIF_FAIL;
}

int COnvifClientSession::AddPtzPresetTour(char *sPresetTourToken, TourInfo *resTourToken, int nCount)
{
	if(!sPresetTourToken || !resTourToken) return ONVIF_FAIL;

	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	bool bCreateTour = true, bFoundTour = false;
	tt__PresetTour *_PresetTour = NULL;

	while (bCreateTour)
	{
		if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
		_tptz__GetPresetTours *tptz__GetPresetTours = soap_new__tptz__GetPresetTours(m_pSoap, -1);
		_tptz__GetPresetToursResponse *tptz__GetPresetToursResponse = soap_new__tptz__GetPresetToursResponse(m_pSoap, -1);
		tptz__GetPresetTours->ProfileToken.assign(m_szProfileToken);
		if(SOAP_OK == proxyPtz.GetPresetTours(m_szIP, NULL, tptz__GetPresetTours, *tptz__GetPresetToursResponse))
		{
			int nSize = tptz__GetPresetToursResponse->PresetTour.size();
			if (!bFoundTour)
			{
				for (int i=0; i<nSize; i++)
				{
					if (strcmp(sPresetTourToken, tptz__GetPresetToursResponse->PresetTour[i]->token->c_str()) == 0)
					{
						_PresetTour = tptz__GetPresetToursResponse->PresetTour[i];
						bFoundTour = true;
						break;
					}
				}
			}
			if (nSize >= 8)
			{
				bCreateTour = false;
				break;
			}
		}

		if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
		_tptz__CreatePresetTour *tptz__CreatePresetTour = soap_new__tptz__CreatePresetTour(m_pSoap, -1);
		tptz__CreatePresetTour->ProfileToken.assign(m_szProfileToken);
		_tptz__CreatePresetTourResponse *tptz__CreatePresetTourResponse = soap_new__tptz__CreatePresetTourResponse(m_pSoap, -1);
		if(SOAP_OK != proxyPtz.CreatePresetTour(m_szIP, NULL, tptz__CreatePresetTour, *tptz__CreatePresetTourResponse)){
			PrintErr("AddPtzPresetTour CreatePresetTour", proxyPtz.soap);
			char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
// 			if(pszError && strstr(pszError, "Password")) 
// 				return ONVIF_PWD_INVALID;
// 			return ONVIF_FAIL;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	if (_PresetTour == NULL)
	{
		return ONVIF_FAIL;
	}
	_PresetTour->TourSpot.clear();
	LONG64 *tmpStayTime = new LONG64[nCount];
	std::vector<std::string> tmpToken;
	char sToken[64] = {0};
	for (int j=0; j<nCount; j++)
	{
		tt__PTZPresetTourSpot *_TourSpot = soap_new_tt__PTZPresetTourSpot(m_pSoap, -1);
		//_TourSpot->soap_default(proxyPtz.soap);
		tt__Vector2D *_PanTilt = soap_new_tt__Vector2D(m_pSoap, -1);
		//_PanTilt->soap_default(proxyPtz.soap);
		_PanTilt->x = ((float)(resTourToken[j].nSpeed))/ANTI_RATIO/4;
		_PanTilt->y = ((float)(resTourToken[j].nSpeed))/ANTI_RATIO/4;
		tt__Vector1D *_Zoom = soap_new_tt__Vector1D(m_pSoap, -1);
		//_Zoom->soap_default(proxyPtz.soap);
		_Zoom->x = ((float)(resTourToken[j].nSpeed))/ANTI_RATIO/4;
		tt__PTZSpeed *_Speed = soap_new_tt__PTZSpeed(m_pSoap, -1);
		//_Speed->soap_default(proxyPtz.soap);
		_Speed->PanTilt = _PanTilt;
		_Speed->Zoom = _Zoom;
		_TourSpot->Speed = _Speed;

		tmpStayTime[j] = resTourToken[j].nStayTime * 1000;
		_TourSpot->StayTime = &tmpStayTime[j];
		LONG64 tmpTime = *_TourSpot->StayTime;

		tt__PTZPresetTourPresetDetail *_PresetDetail = soap_new_tt__PTZPresetTourPresetDetail(m_pSoap, -1);
		//_PresetDetail->soap_default(proxyPtz.soap);
		_PresetDetail->__union_PTZPresetTourPresetDetail = 1;
		itoa(resTourToken[j].nIndex, sToken, 10);
		_PresetDetail->union_PTZPresetTourPresetDetail.PresetToken = new std::string(sToken);
		char sTmpToken[64] = {0};
		_snprintf(sTmpToken, 63, "%s", _PresetDetail->union_PTZPresetTourPresetDetail.PresetToken->c_str());
		_TourSpot->PresetDetail = _PresetDetail;

		_PresetTour->TourSpot.push_back(_TourSpot);
	}
	//////////////////////////////////////////////////////////////////////////

	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	_tptz__ModifyPresetTour *tptz__ModifyPresetTour = soap_new__tptz__ModifyPresetTour(m_pSoap, -1);
	_tptz__ModifyPresetTourResponse *tptz__ModifyPresetTourResponse = soap_new__tptz__ModifyPresetTourResponse(m_pSoap, -1);
	tptz__ModifyPresetTour->ProfileToken.assign(m_szProfileToken);
	tptz__ModifyPresetTour->PresetTour = _PresetTour;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;//��Ҫ�ٴ���֤
	if(SOAP_OK == proxyPtz.ModifyPresetTour(m_szIP, NULL, tptz__ModifyPresetTour, *tptz__ModifyPresetTourResponse)){
		if (tmpStayTime)
		{
			delete []tmpStayTime;
			tmpStayTime = NULL;
		}
		return ONVIF_OK;
	}else{
		if (tmpStayTime)
		{
			delete []tmpStayTime;
			tmpStayTime = NULL;
		}
		PrintErr("AddPtzPresetTour ModifyPresetTour", proxyPtz.soap);
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;

	}
	return ONVIF_FAIL;
}

int COnvifClientSession::CreatePresetTour(int nIndex)
{
	return 0;
}

int COnvifClientSession::RemovePresetTour(char *sPresetTourToken)
{
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__RemovePresetTour *tptz__RemovePresetTour = soap_new__tptz__RemovePresetTour(m_pSoap, -1);
// 	_snprintf(szIndex, sizeof(szIndex)-1, "Tour_%d", nIndex);
// 	std::string PresetTourToken = szIndex;
	tptz__RemovePresetTour->PresetTourToken = sPresetTourToken;
	tptz__RemovePresetTour->ProfileToken.assign(m_szProfileToken);
	_tptz__RemovePresetTourResponse *tptz__RemovePresetTourResponse = soap_new__tptz__RemovePresetTourResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.RemovePresetTour(m_szIP, NULL, tptz__RemovePresetTour, *tptz__RemovePresetTourResponse)){
		nResult = ONVIF_OK;
	}else{
		PrintErr("RemovePresetTour", proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
}

int COnvifClientSession::PlayPtzPresetTour(int nIndex)
{
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__OperatePresetTour *tptz__OperatePresetTour = soap_new__tptz__OperatePresetTour(m_pSoap, -1);
	itoa(nIndex, szIndex, 10);
	std::string PresetToken = szIndex;
	tptz__OperatePresetTour->ProfileToken.assign(m_szProfileToken);
	tptz__OperatePresetTour->PresetTourToken = PresetToken;
	tptz__OperatePresetTour->Operation = tt__PTZPresetTourOperation::tt__PTZPresetTourOperation__Start;
	_tptz__OperatePresetTourResponse *tptz__OperatePresetTourResponse = soap_new__tptz__OperatePresetTourResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.OperatePresetTour(m_szIP, NULL, tptz__OperatePresetTour, *tptz__OperatePresetTourResponse)){
		nResult = ONVIF_OK;
	}else{
		PrintErr("PlayPtzPresetTour OperatePresetTour", proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
}

int COnvifClientSession::StopPtzPresetTour(int nIndex)
{
	int nResult = ONVIF_FAIL;
	char szIndex[32] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	_tptz__OperatePresetTour *tptz__OperatePresetTour = soap_new__tptz__OperatePresetTour(m_pSoap, -1);
	itoa(nIndex, szIndex, 10);
	std::string PresetToken = szIndex;
	tptz__OperatePresetTour->ProfileToken.assign(m_szProfileToken);
	tptz__OperatePresetTour->PresetTourToken = PresetToken;
	tptz__OperatePresetTour->Operation = tt__PTZPresetTourOperation::tt__PTZPresetTourOperation__Stop;
	_tptz__OperatePresetTourResponse *tptz__OperatePresetTourResponse = soap_new__tptz__OperatePresetTourResponse(m_pSoap, -1);

	if(SOAP_OK == proxyPtz.OperatePresetTour(m_szIP, NULL, tptz__OperatePresetTour, *tptz__OperatePresetTourResponse)){
		nResult = ONVIF_OK;
	}else{
		PrintErr("StopPtzPresetTour OperatePresetTour", proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}
	return nResult;
}

int COnvifClientSession::AuxiliaryPtzCmd(int nType, float fValue)
{
#if 1
//	OutputDebugString("AuxiliaryPtzCmd\n");
	int nResult = ONVIF_FAIL;
	char szData[256] = {0};
	PTZBindingProxy proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;

	if(nType == PTZ_FOCUS_OUT){
		_snprintf(szData, sizeof(szData)-1, "focusout");
	}else if(nType == PTZ_FOCUS_IN){
		_snprintf(szData, sizeof(szData)-1, "focusin");
	}else if(nType == PTZ_AUTO_FOCUS){
		_snprintf(szData, sizeof(szData)-1, "autofocus");
	}else if(nType == PTZ_FOCUS_REST){
		_snprintf(szData, sizeof(szData)-1, "resetfocus");
	}else if(nType == PTZ_IRIS_OUT){
		_snprintf(szData, sizeof(szData)-1, "irisout");
	}else if(nType == PTZ_IRIS_IN){
		_snprintf(szData, sizeof(szData)-1, "irisin");
	}else if(nType == PTZ_AUTO_SCAN){
		_snprintf(szData, sizeof(szData)-1, "auto");
	}else if(nType == PTZ_LIGHT_OFF){
		_snprintf(szData, sizeof(szData)-1, "lightoff");
	}else if(nType == PTZ_LIGHT_ON){
		_snprintf(szData, sizeof(szData)-1, "lighton");
	}else if(nType == PTZ_BRUSH_OFF){
		_snprintf(szData, sizeof(szData)-1, "brushoff");
	}else if(nType == PTZ_BRUSH_ON){
		_snprintf(szData, sizeof(szData)-1, "brushon");
	}else if(nType == PTZ_SET_BRIGHTNESS){
		_snprintf(szData, sizeof(szData)-1, "brightness&%f", fValue);
	}else if(nType == PTZ_SET_CONTRAST){
		_snprintf(szData, sizeof(szData)-1, "constrast&%f", fValue);
	}else if(nType == PTZ_SET_SUTIRATION){
		_snprintf(szData, sizeof(szData)-1, "sutiration&%f", fValue);
	}
	_tptz__SendAuxiliaryCommand *SendAuxiliaryCmd = soap_new__tptz__SendAuxiliaryCommand(m_pSoap, -1);
	SendAuxiliaryCmd->AuxiliaryData = szData;
	SendAuxiliaryCmd->ProfileToken.assign(m_szProfileToken);
	_tptz__SendAuxiliaryCommandResponse *SendAuxiliaryCmdResp = soap_new__tptz__SendAuxiliaryCommandResponse(m_pSoap, -1);
	if(SOAP_OK == proxyPtz.SendAuxiliaryCommand(m_szIP, NULL, SendAuxiliaryCmd, *SendAuxiliaryCmdResp)){
		nResult = ONVIF_OK;
	}else{
		PrintErr("AuxiliaryPtzCmd SendAuxiliaryCommand", proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}

	return nResult;
#else
	OutputDebugString("AuxiliaryPtzCmd\n");
	int nResult = ONVIF_FAIL;
	char szData[256] = {0};
	PTZBinding proxyPtz;
	proxyPtz.soap->connect_timeout = PTZ_CONN_TIMEOUT;
	proxyPtz.soap->recv_timeout = PTZ_RECV_TIMEOUT;
	if(!Auth(proxyPtz.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyPtz.endpoint = _strdup(m_szIP);

	if(nType == PTZ_FOCUS_OUT){
		_snprintf(szData, sizeof(szData)-1, "focusout");
	}else if(nType == PTZ_FOCUS_IN){
		_snprintf(szData, sizeof(szData)-1, "focusin");
	}else if(nType == PTZ_AUTO_FOCUS){
		_snprintf(szData, sizeof(szData)-1, "autofocus");
	}else if(nType == PTZ_FOCUS_REST){
		_snprintf(szData, sizeof(szData)-1, "resetfocus");
	}else if(nType == PTZ_IRIS_OUT){
		_snprintf(szData, sizeof(szData)-1, "irisout");
	}else if(nType == PTZ_IRIS_IN){
		_snprintf(szData, sizeof(szData)-1, "irisin");
	}else if(nType == PTZ_AUTO_SCAN){
		_snprintf(szData, sizeof(szData)-1, "auto");
	}else if(nType == PTZ_LIGHT_OFF){
		_snprintf(szData, sizeof(szData)-1, "lightoff");
	}else if(nType == PTZ_LIGHT_ON){
		_snprintf(szData, sizeof(szData)-1, "lighton");
	}else if(nType == PTZ_BRUSH_OFF){
		_snprintf(szData, sizeof(szData)-1, "brushoff");
	}else if(nType == PTZ_BRUSH_ON){
		_snprintf(szData, sizeof(szData)-1, "brushon");
	}else if(nType == PTZ_SET_BRIGHTNESS){
		_snprintf(szData, sizeof(szData)-1, "brightness&%f", fValue);
	}else if(nType == PTZ_SET_CONTRAST){
		_snprintf(szData, sizeof(szData)-1, "constrast&%f", fValue);
	}else if(nType == PTZ_SET_SUTIRATION){
		_snprintf(szData, sizeof(szData)-1, "sutiration&%f", fValue);
	}
	_tptz__SendAuxiliaryCommand *SendAuxiliaryCmd = soap_new__tptz__SendAuxiliaryCommand(m_pSoap, -1);
	SendAuxiliaryCmd->AuxiliaryData = szData;
	SendAuxiliaryCmd->ProfileToken.assign(m_szProfileToken);
	_tptz__SendAuxiliaryCommandResponse *SendAuxiliaryCmdResp = soap_new__tptz__SendAuxiliaryCommandResponse(m_pSoap, -1);
	if(SOAP_OK == proxyPtz.__tptz__SendAuxiliaryCommand(SendAuxiliaryCmd, SendAuxiliaryCmdResp)){
		nResult = ONVIF_OK;
	}else{
		//PrintErr(proxyPtz.soap);	
		char *pszError = (char*)*soap_faultstring(proxyPtz.soap);
		if(pszError && strstr(pszError, "Password")) nResult = ONVIF_PWD_INVALID;
		else nResult = ONVIF_FAIL;
	}

	free((void*)proxyPtz.endpoint);
	return nResult;
#endif
}

//////////////////////////////////////////////////////////////////////////
//Image 
int COnvifClientSession::GetImageOption(char *pszToken, ImageOptions *pImageSettings)
{
#if 1
	ImagingBindingProxy proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -200000;
	proxyImage.soap->recv_timeout = -300000;

	_timg__GetOptions *timg__GetImagingSettings = soap_new__timg__GetOptions(m_pSoap, -1);
	_timg__GetOptionsResponse *timg__GetImagingSettingsResponse	= soap_new__timg__GetOptionsResponse(m_pSoap, -1);

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBindingProxy proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -200000;
	proxyMedia.soap->recv_timeout = -300000;
	if(SOAP_OK == proxyMedia.GetVideoSources(m_szIP, NULL, trt__GetVideoSources, *trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__GetImagingSettings->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__GetImagingSettings->VideoSourceToken = pszToken;
	}
	//////////////////////////////////////////////////////////////////////////
	if (SOAP_OK == proxyImage.GetOptions(m_szIP, NULL, timg__GetImagingSettings, *timg__GetImagingSettingsResponse))
	{
		if(!timg__GetImagingSettingsResponse->ImagingOptions)
			return ONVIF_FAIL;
		if(timg__GetImagingSettingsResponse->ImagingOptions->Brightness){	
			pImageSettings->fMinBrightness = (timg__GetImagingSettingsResponse->ImagingOptions->Brightness->Min);
			pImageSettings->fMaxBrightness = (timg__GetImagingSettingsResponse->ImagingOptions->Brightness->Max);
		}if(timg__GetImagingSettingsResponse->ImagingOptions->ColorSaturation){
			pImageSettings->fMinColorSaturation = (timg__GetImagingSettingsResponse->ImagingOptions->ColorSaturation->Min);
			pImageSettings->fMaxColorSaturation = (timg__GetImagingSettingsResponse->ImagingOptions->ColorSaturation->Max);
		}if(timg__GetImagingSettingsResponse->ImagingOptions->Contrast){
			pImageSettings->fMinContrast = (timg__GetImagingSettingsResponse->ImagingOptions->Contrast->Min);
			pImageSettings->fMaxContrast = (timg__GetImagingSettingsResponse->ImagingOptions->Contrast->Max);
		}if(timg__GetImagingSettingsResponse->ImagingOptions->Sharpness){
			pImageSettings->fMinSharpness = (timg__GetImagingSettingsResponse->ImagingOptions->Sharpness->Min);
			pImageSettings->fMaxSharpness = (timg__GetImagingSettingsResponse->ImagingOptions->Sharpness->Max);
		}
		return ONVIF_OK;
	}
	else
	{
		PrintErr("GetImageOption GetOptions", proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	return ONVIF_FAIL;
#else
	ImagingBinding proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -200000;
	proxyImage.soap->recv_timeout = -300000;
	proxyImage.endpoint = _strdup(m_szIP);

	_timg__GetOptions *timg__GetImagingSettings = soap_new__timg__GetOptions(m_pSoap, -1);
	_timg__GetOptionsResponse *timg__GetImagingSettingsResponse	= soap_new__timg__GetOptionsResponse(m_pSoap, -1);

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBinding proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -200000;
	proxyMedia.soap->recv_timeout = -300000;
	proxyMedia.endpoint = _strdup(m_szIP);
	if(SOAP_OK == proxyMedia.__trt__GetVideoSources(trt__GetVideoSources, trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__GetImagingSettings->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__GetImagingSettings->VideoSourceToken = pszToken;
	}
	//////////////////////////////////////////////////////////////////////////
	if (SOAP_OK == proxyImage.__timg__GetOptions(timg__GetImagingSettings, timg__GetImagingSettingsResponse))
	{
		if(!timg__GetImagingSettingsResponse->ImagingOptions)
			return ONVIF_FAIL;
		if(timg__GetImagingSettingsResponse->ImagingOptions->Brightness){	
			pImageSettings->fMinBrightness = (timg__GetImagingSettingsResponse->ImagingOptions->Brightness->Min);
			pImageSettings->fMaxBrightness = (timg__GetImagingSettingsResponse->ImagingOptions->Brightness->Max);
		}if(timg__GetImagingSettingsResponse->ImagingOptions->ColorSaturation){
			pImageSettings->fMinColorSaturation = (timg__GetImagingSettingsResponse->ImagingOptions->ColorSaturation->Min);
			pImageSettings->fMaxColorSaturation = (timg__GetImagingSettingsResponse->ImagingOptions->ColorSaturation->Max);
		}if(timg__GetImagingSettingsResponse->ImagingOptions->Contrast){
			pImageSettings->fMinContrast = (timg__GetImagingSettingsResponse->ImagingOptions->Contrast->Min);
			pImageSettings->fMaxContrast = (timg__GetImagingSettingsResponse->ImagingOptions->Contrast->Max);
		}if(timg__GetImagingSettingsResponse->ImagingOptions->Sharpness){
			pImageSettings->fMinSharpness = (timg__GetImagingSettingsResponse->ImagingOptions->Sharpness->Min);
			pImageSettings->fMaxSharpness = (timg__GetImagingSettingsResponse->ImagingOptions->Sharpness->Max);
		}
		return ONVIF_OK;
	}
	else
	{
		//PrintErr(proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	return ONVIF_FAIL;
#endif
}

int COnvifClientSession::GetImageSettings(char *pszToken, ImageSettings *pImageSettings)
{
#if 1
	if(!pImageSettings) return ONVIF_FAIL;	

	ImagingBindingProxy proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -200000;
	proxyImage.soap->recv_timeout = -300000;

	//////////////////////////////////////////////////////////////////////////
	_timg__GetImagingSettings *timg__GetImagingSettings = soap_new__timg__GetImagingSettings(m_pSoap, -1);
	_timg__GetImagingSettingsResponse *timg__GetImagingSettingsResponse	= soap_new__timg__GetImagingSettingsResponse(m_pSoap, -1);

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBindingProxy proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -200000;
	proxyMedia.soap->recv_timeout = -300000;
	if(SOAP_OK == proxyMedia.GetVideoSources(m_szIP, NULL, trt__GetVideoSources, *trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__GetImagingSettings->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__GetImagingSettings->VideoSourceToken = pszToken;
	}
	//////////////////////////////////////////////////////////////////////////

	if (SOAP_OK == proxyImage.GetImagingSettings(m_szIP, NULL, timg__GetImagingSettings, *timg__GetImagingSettingsResponse))
	{
		if(!timg__GetImagingSettingsResponse->ImagingSettings)
			return ONVIF_FAIL;
		if(timg__GetImagingSettingsResponse->ImagingSettings->Brightness)
			pImageSettings->fBrightness = *(timg__GetImagingSettingsResponse->ImagingSettings->Brightness);
		if(timg__GetImagingSettingsResponse->ImagingSettings->ColorSaturation)
			pImageSettings->fColorSaturation = *(timg__GetImagingSettingsResponse->ImagingSettings->ColorSaturation);
		if(timg__GetImagingSettingsResponse->ImagingSettings->Contrast)
			pImageSettings->fContrast = *(timg__GetImagingSettingsResponse->ImagingSettings->Contrast);
		if(timg__GetImagingSettingsResponse->ImagingSettings->Sharpness)
			pImageSettings->fSharpness = *(timg__GetImagingSettingsResponse->ImagingSettings->Sharpness);
		return ONVIF_OK;
	}
	else
	{
		PrintErr("GetImageSettings GetImagingSettings", proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	return ONVIF_FAIL;
#else
	if(!pImageSettings) return ONVIF_FAIL;	

	ImagingBinding proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -200000;
	proxyImage.soap->recv_timeout = -300000;
	proxyImage.endpoint = _strdup(m_szIP);

	//////////////////////////////////////////////////////////////////////////
	_timg__GetImagingSettings *timg__GetImagingSettings = soap_new__timg__GetImagingSettings(m_pSoap, -1);
	_timg__GetImagingSettingsResponse *timg__GetImagingSettingsResponse	= soap_new__timg__GetImagingSettingsResponse(m_pSoap, -1);
	
	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBinding proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -200000;
	proxyMedia.soap->recv_timeout = -300000;
	proxyMedia.endpoint = _strdup(m_szIP);
	if(SOAP_OK == proxyMedia.__trt__GetVideoSources(trt__GetVideoSources, trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__GetImagingSettings->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__GetImagingSettings->VideoSourceToken = pszToken;
	}
	//////////////////////////////////////////////////////////////////////////
	
	if (SOAP_OK == proxyImage.__timg__GetImagingSettings(timg__GetImagingSettings, timg__GetImagingSettingsResponse))
	{
		if(!timg__GetImagingSettingsResponse->ImagingSettings)
			return ONVIF_FAIL;
		if(timg__GetImagingSettingsResponse->ImagingSettings->Brightness)
			pImageSettings->fBrightness = *(timg__GetImagingSettingsResponse->ImagingSettings->Brightness);
		if(timg__GetImagingSettingsResponse->ImagingSettings->ColorSaturation)
			pImageSettings->fColorSaturation = *(timg__GetImagingSettingsResponse->ImagingSettings->ColorSaturation);
		if(timg__GetImagingSettingsResponse->ImagingSettings->Contrast)
			pImageSettings->fContrast = *(timg__GetImagingSettingsResponse->ImagingSettings->Contrast);
		if(timg__GetImagingSettingsResponse->ImagingSettings->Sharpness)
			pImageSettings->fSharpness = *(timg__GetImagingSettingsResponse->ImagingSettings->Sharpness);
		return ONVIF_OK;
	}
	else
	{
		//PrintErr(proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	return ONVIF_FAIL;
#endif
}

int COnvifClientSession::SetImageSettings(char *pszToken, ImageSettings *pImageSettings)
{
#if 1
	if(!pImageSettings) return ONVIF_FAIL;	

	ImagingBindingProxy proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -500000;
	proxyImage.soap->recv_timeout = -500000;

	_timg__SetImagingSettings *timg__SetImagingSettings = soap_new__timg__SetImagingSettings(m_pSoap, -1);
	_timg__SetImagingSettingsResponse *timg__GetImagingSettingsResponse	= soap_new__timg__SetImagingSettingsResponse(m_pSoap, -1);
	tt__ImagingSettings20 ImagingSettings;	
	ImagingSettings.soap_default(proxyImage.soap);

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBindingProxy proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -500000;
	proxyMedia.soap->recv_timeout = -500000;
	if(SOAP_OK == proxyMedia.GetVideoSources(m_szIP, NULL, trt__GetVideoSources, *trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__SetImagingSettings->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__SetImagingSettings->VideoSourceToken = pszToken;
	}
	//////////////////////////////////////////////////////////////////////////

	timg__SetImagingSettings->ForcePersistence = (bool *)SOAP_MALLOC(soap, sizeof(bool));
	*timg__SetImagingSettings->ForcePersistence = true;
	ImagingSettings.Brightness = &pImageSettings->fBrightness;
	ImagingSettings.ColorSaturation = &pImageSettings->fColorSaturation;
	ImagingSettings.Contrast = &pImageSettings->fContrast;
	ImagingSettings.Sharpness = &pImageSettings->fSharpness;

	timg__SetImagingSettings->ImagingSettings = &ImagingSettings;

	if(SOAP_OK == proxyImage.SetImagingSettings(m_szIP, NULL, timg__SetImagingSettings, *timg__GetImagingSettingsResponse)){
		return ONVIF_OK;
	}else{
		PrintErr("SetImageSettings SetImagingSettings", proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;

	}
	return ONVIF_FAIL;
#else
	if(!pImageSettings) return ONVIF_FAIL;	

	ImagingBinding proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -500000;
	proxyImage.soap->recv_timeout = -500000;
	proxyImage.endpoint = _strdup(m_szIP);

	_timg__SetImagingSettings *timg__SetImagingSettings = soap_new__timg__SetImagingSettings(m_pSoap, -1);
	_timg__SetImagingSettingsResponse *timg__GetImagingSettingsResponse	= soap_new__timg__SetImagingSettingsResponse(m_pSoap, -1);
	tt__ImagingSettings20 ImagingSettings;	
	ImagingSettings.soap_default(proxyImage.soap);

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBinding proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -500000;
	proxyMedia.soap->recv_timeout = -500000;
	proxyMedia.endpoint = _strdup(m_szIP);
	if(SOAP_OK == proxyMedia.__trt__GetVideoSources(trt__GetVideoSources, trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__SetImagingSettings->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__SetImagingSettings->VideoSourceToken = pszToken;
	}
	//////////////////////////////////////////////////////////////////////////

	timg__SetImagingSettings->ForcePersistence_x0020 = (enum xsd__boolean_ *)SOAP_MALLOC(soap, sizeof(enum xsd__boolean_));
	*timg__SetImagingSettings->ForcePersistence_x0020 = _true;
	ImagingSettings.Brightness = &pImageSettings->fBrightness;
	ImagingSettings.ColorSaturation = &pImageSettings->fColorSaturation;
	ImagingSettings.Contrast = &pImageSettings->fContrast;
	ImagingSettings.Sharpness = &pImageSettings->fSharpness;
	//ImagingSettings.BacklightCompensation = 

	timg__SetImagingSettings->ImagingSettings = &ImagingSettings;
	
	if(SOAP_OK == proxyImage.__timg__SetImagingSettings(timg__SetImagingSettings, timg__GetImagingSettingsResponse)){
		return ONVIF_OK;
	}else{
		//PrintErr(proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;

	}
	return ONVIF_FAIL;
#endif
}

int COnvifClientSession::GetFocusMoveOption(char *pszToken, FocusMoveOptions *pFocusMoveOptions)
{
#if 1
	ImagingBindingProxy proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -200000;
	proxyImage.soap->recv_timeout = -300000;

	_timg__GetMoveOptions *timg__GetMoveSettings = soap_new__timg__GetMoveOptions(m_pSoap, -1);
	_timg__GetMoveOptionsResponse *timg__GetMoveResponse	= soap_new__timg__GetMoveOptionsResponse(m_pSoap, -1);

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBindingProxy proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -200000;
	proxyMedia.soap->recv_timeout = -300000;
	if(SOAP_OK == proxyMedia.GetVideoSources(m_szIP, NULL, trt__GetVideoSources, *trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__GetMoveSettings->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__GetMoveSettings->VideoSourceToken = pszToken;
	}
	//////////////////////////////////////////////////////////////////////////
	if (SOAP_OK == proxyImage.GetMoveOptions(m_szIP, NULL, timg__GetMoveSettings, *timg__GetMoveResponse))
	{
		if(!timg__GetMoveResponse->MoveOptions)
			return ONVIF_FAIL;
		if(timg__GetMoveResponse->MoveOptions->Continuous && timg__GetMoveResponse->MoveOptions->Continuous->Speed){	
			pFocusMoveOptions->fMinSpeed = timg__GetMoveResponse->MoveOptions->Continuous->Speed->Min;
			pFocusMoveOptions->fMaxSpeed = timg__GetMoveResponse->MoveOptions->Continuous->Speed->Max;
		}
		return ONVIF_OK;
	}
	else
	{
		PrintErr("GetFocusMoveOption GetMoveOptions", proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	return ONVIF_FAIL;
#else
	ImagingBinding proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -200000;
	proxyImage.soap->recv_timeout = -300000;
	proxyImage.endpoint = _strdup(m_szIP);

	_timg__GetMoveOptions *timg__GetMoveSettings = soap_new__timg__GetMoveOptions(m_pSoap, -1);
	_timg__GetMoveOptionsResponse *timg__GetMoveResponse	= soap_new__timg__GetMoveOptionsResponse(m_pSoap, -1);

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBinding proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -200000;
	proxyMedia.soap->recv_timeout = -300000;
	proxyMedia.endpoint = _strdup(m_szIP);
	if(SOAP_OK == proxyMedia.__trt__GetVideoSources(trt__GetVideoSources, trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__GetMoveSettings->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__GetMoveSettings->VideoSourceToken = pszToken;
	}
	//////////////////////////////////////////////////////////////////////////
	if (SOAP_OK == proxyImage.__timg__GetMoveOptions(timg__GetMoveSettings, timg__GetMoveResponse))
	{
		if(!timg__GetMoveResponse->MoveOptions)
			return ONVIF_FAIL;
		if(timg__GetMoveResponse->MoveOptions->Continuous && timg__GetMoveResponse->MoveOptions->Continuous->Speed){	
			pFocusMoveOptions->fMinSpeed = timg__GetMoveResponse->MoveOptions->Continuous->Speed->Min;
			pFocusMoveOptions->fMaxSpeed = timg__GetMoveResponse->MoveOptions->Continuous->Speed->Max;
		}
		return ONVIF_OK;
	}
	else
	{
		//PrintErr(proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;
	}

	return ONVIF_FAIL;
#endif
}

int COnvifClientSession::MoveFocus(char *pszToken, FocusMoveSettings *pFocusMoveSettings)
{
#if 1
	if(!pFocusMoveSettings) return ONVIF_FAIL;	

	ImagingBindingProxy proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -500000;
	proxyImage.soap->recv_timeout = -500000;

	_timg__Move *timg__Move = soap_new__timg__Move(m_pSoap, -1);
	_timg__MoveResponse *timg__MoveResponse	= soap_new__timg__MoveResponse(m_pSoap, -1);
	tt__FocusMove FocusMove;	
	FocusMove.soap_default(proxyImage.soap);
	tt__ContinuousFocus ContinuousFocus;

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBindingProxy proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -500000;
	proxyMedia.soap->recv_timeout = -500000;
	if(SOAP_OK == proxyMedia.GetVideoSources(m_szIP, NULL, trt__GetVideoSources, *trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__Move->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__Move->VideoSourceToken = pszToken;
	}
	//////////////////////////////////////////////////////////////////////////
	ContinuousFocus.Speed = pFocusMoveSettings->speed;
	FocusMove.Continuous = &ContinuousFocus;
	timg__Move->Focus = &FocusMove;

	if(SOAP_OK == proxyImage.Move(m_szIP, NULL, timg__Move, *timg__MoveResponse)){
		return ONVIF_OK;
	}else{
		PrintErr("MoveFocus Move", proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;

	}
	return ONVIF_FAIL;
#else
	if(!pFocusMoveSettings) return ONVIF_FAIL;	

	ImagingBinding proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -500000;
	proxyImage.soap->recv_timeout = -500000;
	proxyImage.endpoint = _strdup(m_szIP);

	_timg__Move *timg__Move = soap_new__timg__Move(m_pSoap, -1);
	_timg__MoveResponse *timg__MoveResponse	= soap_new__timg__MoveResponse(m_pSoap, -1);
	tt__FocusMove FocusMove;	
	FocusMove.soap_default(proxyImage.soap);
	tt__ContinuousFocus ContinuousFocus;

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBinding proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -500000;
	proxyMedia.soap->recv_timeout = -500000;
	proxyMedia.endpoint = _strdup(m_szIP);
	if(SOAP_OK == proxyMedia.__trt__GetVideoSources(trt__GetVideoSources, trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__Move->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__Move->VideoSourceToken = pszToken;
	}
	//////////////////////////////////////////////////////////////////////////
	ContinuousFocus.Speed = pFocusMoveSettings->speed;
	FocusMove.Continuous = &ContinuousFocus;
	timg__Move->Focus = &FocusMove;

	if(SOAP_OK == proxyImage.__timg__Move(timg__Move, timg__MoveResponse)){
		return ONVIF_OK;
	}else{
		//PrintErr(proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;

	}
	return ONVIF_FAIL;
#endif
}

int COnvifClientSession::StopFocus(char *pVideoSourceToken)
{
#if 1
	if(!pVideoSourceToken) return ONVIF_FAIL;	

	ImagingBindingProxy proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -500000;
	proxyImage.soap->recv_timeout = -500000;

	_timg__Stop *timg__Stop = soap_new__timg__Stop(m_pSoap, -1);
	_timg__StopResponse *timg__StopResponse	= soap_new__timg__StopResponse(m_pSoap, -1);

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBindingProxy proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -500000;
	proxyMedia.soap->recv_timeout = -500000;
	if(SOAP_OK == proxyMedia.GetVideoSources(m_szIP, NULL, trt__GetVideoSources, *trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__Stop->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__Stop->VideoSourceToken = pVideoSourceToken;
	}
	//////////////////////////////////////////////////////////////////////////
	if(SOAP_OK == proxyImage.Stop(m_szIP, NULL, timg__Stop, *timg__StopResponse)){
		return ONVIF_OK;
	}else{
		PrintErr("StopFocus Stop", proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;

	}
	return ONVIF_FAIL;
#else
	if(!pVideoSourceToken) return ONVIF_FAIL;	

	ImagingBinding proxyImage;
	if(!Auth(proxyImage.soap) || m_szIP[0] == '\0') return ONVIF_FAIL;
	proxyImage.soap->connect_timeout = -500000;
	proxyImage.soap->recv_timeout = -500000;
	proxyImage.endpoint = _strdup(m_szIP);

	_timg__Stop *timg__Stop = soap_new__timg__Stop(m_pSoap, -1);
	_timg__StopResponse *timg__StopResponse	= soap_new__timg__StopResponse(m_pSoap, -1);

	//////////////////////////////////////////////////////////////////////////
	//Get Video Source Token
	_trt__GetVideoSources *trt__GetVideoSources = soap_new__trt__GetVideoSources(m_pSoap, -1);
	_trt__GetVideoSourcesResponse *trt__GetVideoSourcesResp = soap_new__trt__GetVideoSourcesResponse(m_pSoap, -1);
	MediaBinding proxyMedia;
	Auth(proxyMedia.soap);
	proxyMedia.soap->connect_timeout = -500000;
	proxyMedia.soap->recv_timeout = -500000;
	proxyMedia.endpoint = _strdup(m_szIP);
	if(SOAP_OK == proxyMedia.__trt__GetVideoSources(trt__GetVideoSources, trt__GetVideoSourcesResp)){
		if(trt__GetVideoSourcesResp->VideoSources.empty() == false)
			timg__Stop->VideoSourceToken = trt__GetVideoSourcesResp->VideoSources[0]->token;
	}else{
		timg__Stop->VideoSourceToken = pVideoSourceToken;
	}
	//////////////////////////////////////////////////////////////////////////
	if(SOAP_OK == proxyImage.__timg__Stop(timg__Stop, timg__StopResponse)){
		return ONVIF_OK;
	}else{
		//PrintErr(proxyImage.soap);
		char *pszError = (char*)*soap_faultstring(proxyImage.soap);
		if(pszError && strstr(pszError, "Password")) 
			return ONVIF_PWD_INVALID;
		return ONVIF_FAIL;

	}
	return ONVIF_FAIL;
#endif
}