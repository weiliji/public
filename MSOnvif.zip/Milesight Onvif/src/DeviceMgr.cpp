#include "../inc/DeviceMgr.h"
#include "OnvifClientSession.h"

CDeviceMgr::CDeviceMgr()
{
	m_pSession = new COnvifClientSession();
}

CDeviceMgr::CDeviceMgr(char *pszIp, char* pszUserName, char* pszPassword)
{
	char sOutMsg[256] = {0};
	_snprintf(sOutMsg, sizeof(sOutMsg)-1, "=====url:%s user:%s pwd:%s====\n", pszIp, pszUserName, pszPassword);
//	OutputDebugString(sOutMsg);

	m_pSession = new COnvifClientSession(pszIp, pszUserName, pszPassword);
}

CDeviceMgr::~CDeviceMgr()
{
	if(m_pSession) 
		delete (COnvifClientSession*)m_pSession;
}

void CDeviceMgr::SetIP(char *pszIp)
{
	if(!pszIp) return;
	((COnvifClientSession*)m_pSession)->SetIp(pszIp);
}

void CDeviceMgr::SetUsername(char *pszUsername)
{
	if(!pszUsername)return;
	((COnvifClientSession*)m_pSession)->SetUsername(pszUsername);
}

void CDeviceMgr::SetPassword(char *pszPassword)
{
	if(!pszPassword) return;
	((COnvifClientSession*)m_pSession)->SetPassword(pszPassword);
}
////////////////////////////////////////////////////////////////////////////////////

int CDeviceMgr::SetSystem(System *pSystem)
{
	if(!pSystem) return ONVIF_FAIL;

	return ONVIF_OK;
}

int CDeviceMgr::GetNetwork(Network *pNetwork)
{
	if(!pNetwork)return ONVIF_FAIL;
	DeviceInfo deviceInfo = {0};
	if(ONVIF_OK != ((COnvifClientSession*)m_pSession)->GetNetwork(&deviceInfo))
		return ONVIF_FAIL;

// 	OutputDebugString(deviceInfo.network.szNetmask);
// 	OutputDebugString("\n");
	_snprintf(pNetwork->szIp, sizeof(pNetwork->szIp)-1, "%s", deviceInfo.network.szIp);
	_snprintf(pNetwork->szNetmask, sizeof(pNetwork->szNetmask)-1, "%s", deviceInfo.network.szNetmask);
	_snprintf(pNetwork->szGateway, sizeof(pNetwork->szGateway)-1, "%s", deviceInfo.network.szGateway);
	_snprintf(pNetwork->szDns, sizeof(pNetwork->szDns)-1, "%s", deviceInfo.network.szPDNS);
	pNetwork->nHttpPort = deviceInfo.network.nHttpPort;
	return ONVIF_OK;
}

int CDeviceMgr::SetNetwork(Network *pNetwork)
{
	if(!pNetwork) return ONVIF_FAIL;
	return SetNetwork(pNetwork->szIp, pNetwork->szNetmask, pNetwork->szGateway, pNetwork->szDns);
}

int CDeviceMgr::SetNetwork(char *pszIp, char *pszNetmask, char *pszGateway, char *pszDNS)
{
	if(!pszIp || !pszNetmask || !pszGateway || !pszDNS) return ONVIF_FAIL;

	DeviceInfo deviceInfo = {0};
	_snprintf(deviceInfo.network.szIp, sizeof(deviceInfo.network.szIp)-1, "%s", pszIp);
	_snprintf(deviceInfo.network.szNetmask, sizeof(deviceInfo.network.szNetmask)-1, "%s", pszNetmask);
	_snprintf(deviceInfo.network.szGateway, sizeof(deviceInfo.network.szGateway)-1, "%s", pszGateway);
	_snprintf(deviceInfo.network.szPDNS, sizeof(deviceInfo.network.szPDNS)-1, "%s", pszDNS);
	return ((COnvifClientSession*)m_pSession)->SetNetwork(&deviceInfo);
}

int CDeviceMgr::GetFTP(FTP *pFtp)
{
	if(!pFtp) return ONVIF_FAIL;
	return ONVIF_OK;
}

int CDeviceMgr::SetFTP(FTP *pFtp)
{
	if(!pFtp)return ONVIF_FAIL;
	return SetFTP(pFtp->szServer, pFtp->nPort, pFtp->szUser, pFtp->szPwd);
}

int CDeviceMgr::SetFTP(char *pszServer, int nPort, char *pszFtpUser, char* pszFtpPwd)
{
	if(!pszServer || !pszFtpUser || !pszFtpPwd) return ONVIF_FAIL;
	return ONVIF_OK;
}

int CDeviceMgr::GetSMTP(SMTP *pSmtp)
{
	if(!pSmtp) return ONVIF_FAIL;
	return ONVIF_OK;
}

int CDeviceMgr::SetSMTP(SMTP *pSmtp)
{
	if(!pSmtp) return ONVIF_FAIL;
	return SetSMTP(pSmtp->szName, pSmtp->szSender, pSmtp->szPwd, pSmtp->szRecv, pSmtp->szServer, pSmtp->nPort);
}

int CDeviceMgr::SetSMTP(char *pszName, char *pszSender, char *pszPwd, char *pszReceiver, char *pszSmtpServer, int nPort)
{
	if(!pszName || !pszSender || !pszPwd || !pszReceiver || !pszSmtpServer) return ONVIF_FAIL;
	return ONVIF_OK;
}

int CDeviceMgr::GetAllCapability(Ms_Namespace *pNameSpace)
{
	if(!pNameSpace)
		return ONVIF_FAIL;
	DeviceInfo deviceInfo = {0};
	if(((COnvifClientSession*)m_pSession)->GetCapabilities(&deviceInfo) == ONVIF_OK){
		_snprintf(pNameSpace->sDevice, sizeof(pNameSpace->sDevice)-1, "%s", deviceInfo.nameSpace.sDevice);
		_snprintf(pNameSpace->sMedia, sizeof(pNameSpace->sMedia)-1, "%s", deviceInfo.nameSpace.sMedia);
		_snprintf(pNameSpace->sImaging, sizeof(pNameSpace->sImaging)-1, "%s", deviceInfo.nameSpace.sImaging);
		_snprintf(pNameSpace->sPtz, sizeof(pNameSpace->sPtz)-1, "%s", deviceInfo.nameSpace.sPtz);
		_snprintf(pNameSpace->sEvent, sizeof(pNameSpace->sEvent)-1, "%s", deviceInfo.nameSpace.sEvent);
		return ONVIF_OK;
	}else
		return ONVIF_FAIL;
}

int CDeviceMgr::GetDeviceInfo(Ms_DeviceInfo *pMsDeviceInfo)
{
	if(!pMsDeviceInfo)
		return ONVIF_FAIL;
	DeviceInfo deviceInfo = {0};
	if(((COnvifClientSession*)m_pSession)->GetDeviceInfomation(&deviceInfo) == ONVIF_OK){
		_snprintf(pMsDeviceInfo->sModel, sizeof(pMsDeviceInfo->sModel)-1, "%s", deviceInfo.deviceInfomation.sModel);
		_snprintf(pMsDeviceInfo->sManufacturer, sizeof(pMsDeviceInfo->sManufacturer)-1, "%s", deviceInfo.deviceInfomation.sManufacturer);
		_snprintf(pMsDeviceInfo->sFirmVersion, sizeof(pMsDeviceInfo->sFirmVersion)-1, "%s", deviceInfo.deviceInfomation.sFirmVersion);
		_snprintf(pMsDeviceInfo->sHardwareId, sizeof(pMsDeviceInfo->sHardwareId)-1, "%s", deviceInfo.deviceInfomation.sHardwareId);
		return ONVIF_OK;
	}
	return ONVIF_FAIL;
}