#include "../inc/Discovery.h"
#include "OnvifClientSession.h"
#include "../inc/Typedef.h"

CDeviceDiscovery::CDeviceDiscovery()
{
	m_pSession = new COnvifClientSession();
}

CDeviceDiscovery::CDeviceDiscovery(char *pszIp, char* pszUserName, char* pszPassword)
{
	m_pSession = new COnvifClientSession(pszIp, pszUserName, pszPassword);
}

CDeviceDiscovery::~CDeviceDiscovery()
{
	if(m_pSession) 
		delete (COnvifClientSession*)m_pSession;
}

void CDeviceDiscovery::SetIP(char *pszIp)
{
	if(!pszIp) return;
	((COnvifClientSession*)m_pSession)->SetIp(pszIp);
}

void CDeviceDiscovery::SetUsername(char *pszUsername)
{
	if(!pszUsername)return;
	((COnvifClientSession*)m_pSession)->SetUsername(pszUsername);
}

void CDeviceDiscovery::SetPassword(char *pszPassword)
{
	if(!pszPassword) return;
	((COnvifClientSession*)m_pSession)->SetPassword(pszPassword);
}

void GetSubstringNum(char *pszSrc, char *pszSep, int *pCnt)
{
	char *pszTemp = strstr(pszSrc, pszSep);
	if(!pszTemp) return;
	*pCnt += 1;
	GetSubstringNum(pszTemp+strlen(pszSep), pszSep, pCnt);
}

////////////////////////////////////////////////////////////////////////////////////
void CDeviceDiscovery::DeleteData(DeviceList *pDevice)
{
	delete[] pDevice;
	pDevice = NULL;
}

int CDeviceDiscovery::LoadDevice(DeviceList **ppDevice, int *pCnt)
{
	if(!ppDevice || !pCnt) return ONVIF_FAIL;

	DeviceInfo deviceInfo = {0};
	if(ONVIF_OK != ((COnvifClientSession*)m_pSession)->DeviceDiscovery(&deviceInfo))
		return ONVIF_FAIL;

	int nDeviceNum = 0;
	int nIndex = 0;
	int nIp1, nIp2, nIp3, nIp4;
	char szValue[256] = {0};
	char seps[] = ";";
	char *token;

	GetSubstringNum(deviceInfo.szServiceUri, seps, &nDeviceNum);
	if(nDeviceNum <= 0) return ONVIF_FAIL;
	DeviceList *pDeviceList = new DeviceList[nDeviceNum];
	memset(pDeviceList, 0, sizeof(DeviceList)*nDeviceNum);
	*ppDevice = pDeviceList;
	*pCnt = nDeviceNum;

	token = strtok(deviceInfo.szServiceUri, seps);
	while(token != NULL)
	{
		sscanf(token, "http://%d.%d.%d.%d", &nIp1, &nIp2, &nIp3, &nIp4);
		pDeviceList[nIndex].nPort = 80;
		_snprintf(pDeviceList[nIndex].szIp, sizeof(pDeviceList[nIndex].szIp)-1, "%d.%d.%d.%d", nIp1, nIp2, nIp3, nIp4);	
		nIndex++;
		token = strtok( NULL, seps);
	}

	nIndex = 0;
	token = strtok(deviceInfo.szUuid, seps);
	while(token != NULL && nIndex < nDeviceNum)
	{
		if(strstr(token, "urn:uuid:"))
			sscanf(token, "urn:uuid:%s", szValue);
		else
			_snprintf(szValue, sizeof(szValue)-1, "%s", token);
		_snprintf(pDeviceList[nIndex].szUuid, sizeof(pDeviceList[nIndex].szUuid)-1, "%s", szValue);	
		nIndex++;
		token = strtok( NULL, seps);
	}
	return ONVIF_OK;
}