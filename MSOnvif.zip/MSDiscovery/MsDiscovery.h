
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the MSDISCOVERY_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// MSDISCOVERY_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef MSDISCOVERY_EXPORTS
#define MSDISCOVERY_API __declspec(dllexport)
#else
#define MSDISCOVERY_API __declspec(dllimport)
#endif

typedef struct MsDeviceList
{
	char szIp[64];
	int nPort;
	char szType[128];
	char szUuid[64];
	char szMacAddr[64];
	char szName[128];
	char szModel[32];
	char szSoftwareVersion[16];
	char szHardwareVersion[16];
}MsDeviceList;


// This class is exported from the MsDiscovery.dll
class MSDISCOVERY_API CMsDiscovery {
public:
	CMsDiscovery(void);
	// TODO: add your methods here.
public:
	int LoadDevice(MsDeviceList **ppDevice, int *pCnt, int nRecvTimeout = 2, int nRetryTimes = 5);
	void DeleteData(MsDeviceList *pDevice);
};

extern MSDISCOVERY_API int nMsDiscovery;

MSDISCOVERY_API int fnMsDiscovery(void);

