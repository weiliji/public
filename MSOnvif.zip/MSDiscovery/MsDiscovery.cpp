// MsDiscovery.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "MsDiscovery.h"
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include "src/soapH.h"
#include "src/soapStub.h" 
#include "src/soapDiscoveryLookupBindingProxy.h"
#include "src/DiscoveryLookupBinding.nsmap"

#include <winsock2.h>
#include <iphlpapi.h>
#pragma comment(lib,"iphlpapi.lib")
#pragma comment(lib,"ws2_32.lib")

#define MAX_DISCOVERY_COUNT	256

static int GetMac(char* sMac, int nLen, const char* sAddr);

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


// This is an example of an exported variable
MSDISCOVERY_API int nMsDiscovery=0;

// This is an example of an exported function.
MSDISCOVERY_API int fnMsDiscovery(void)
{
	return 42;
}

// This is the constructor of a class that has been exported.
// see MsDiscovery.h for the class definition
CMsDiscovery::CMsDiscovery()
{ 
	return; 
}

//////////////////////////////////////////////////////////////////////////
void CMsDiscovery::DeleteData(MsDeviceList *pDevice)
{
	if(!pDevice)
		return;
	delete []pDevice;
	pDevice = NULL;
}

static int GetMac(char* sMac, int nLen, const char* sAddr)
{
	unsigned char macAddress[6]; 
	ULONG macAddLen = 6; 
	int   iRet = SendARP(inet_addr(sAddr), (unsigned long)NULL,(PULONG)&macAddress, &macAddLen); 
	if (NO_ERROR == iRet) {
		_snprintf(sMac, nLen-1, "%02X:%02X:%02X:%02X:%02X:%02X", macAddress[0], macAddress[1], macAddress[2], macAddress[3],\
			macAddress[4], macAddress[5]);
	}else{
#ifdef _DEBUG
		char szMsg[256] = {0};
		_snprintf(szMsg, sizeof(szMsg)-1, "Ip:%s get MAC Failed.\n", sAddr);
		OutputDebugString(szMsg);
#endif
	}
	return 0;
}

static bool IsDeviceRepeat(MsDeviceList **ppDevice, char *sIp)
{
	if(!ppDevice)
		return false;
	MsDeviceList *pDeviceList = *ppDevice;
	for(int i = 0; i < MAX_DISCOVERY_COUNT; i++){
		if(!stricmp(sIp, pDeviceList[i].szIp))
			return true;
	}

	return false;
}

int CMsDiscovery::LoadDevice(MsDeviceList **ppDevice, int *pCnt, int nRecvTimeout /* = 2 */, int nRetryTimes /* = 5 */)
{
	if (nRecvTimeout <= 0 || nRecvTimeout > 10)
	{
		nRecvTimeout = 2;
	}

	if(nRetryTimes <= 0 || nRetryTimes > 10)
	{
		nRetryTimes = 5;
	}
	MsDeviceList *pDeviceList = new MsDeviceList[MAX_DISCOVERY_COUNT];//���36��
	memset(pDeviceList, 0, sizeof(MsDeviceList)*MAX_DISCOVERY_COUNT);
	*ppDevice = pDeviceList;
	*pCnt = 0;
	int nCnt = 0;
	DiscoveryLookupBinding proxyDiscovery;
	struct SOAP_ENV__Header header = {0};
	proxyDiscovery.endpoint = "soap.udp://239.255.255.250:3702";///datagram
	//proxyDiscovery.endpoint = "soap.udp://192.168.5.172:3702";///datagram
	proxyDiscovery.soap->header = &header;
	/*sockaddr_in addr;
	addr.sin_family      = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port        = htons(3702);
	bind(proxyDiscovery.soap->socket,(sockaddr*)&addr,sizeof(addr));*/
	soap_default_SOAP_ENV__Header(proxyDiscovery.soap, &header);
	header.wsa__MessageID = "uuid:cff0d69d-5934-4723-888e-3a969ff06ed3";
	header.wsa__To = "urn:schemas-xmlsoap-org:ws:2005:04:discovery";
	header.wsa__Action = "http://schemas.xmllocal_soap.org/ws/2005/04/discovery/Probe";
	d__ProbeType d__Probe;
	std::string sTypes = "";//"dn:NetworkVideoTransmitter";
	d__Probe.Types = &sTypes;
	
	d__ScopesType Scopes;
	Scopes.__item = "";
	d__Probe.Scopes = &Scopes;
	
	//nRecvTimeout = 5;
	proxyDiscovery.soap->recv_timeout = nRecvTimeout;
	int nResult = -1;
	// begin ��ȡ����IP������ֱ�ӻ�ȡ�������ip
	WSADATA wsData = { 0 };  
    int nRet = ::WSAStartup(MAKEWORD(2, 2), &wsData);  
    char szBuf[MAX_PATH] = { 0 };  
    ::gethostname(szBuf, MAX_PATH);//��ȡ�������  
    struct hostent* pStHostent = NULL;  
    pStHostent = ::gethostbyname(szBuf);//���������������������õ�ָ��host�ṹ  
    /* 
    pStHostent->h_name; //�淶�� 
    pStHostent->h_addrtype;//��ַ����IPV4 or IPV6 
    pStHostent->h_addr_list;//ip��ַ�б�
    pStHostent->h_length; //ip��ַ���� 
    pStHostent->h_aliases;//�������� 
    */
    char** pptr = NULL;  
    struct in_addr addr;  
    switch(pStHostent->h_addrtype)  
    {  
    case AF_INET:  
    case AF_INET6:  
        pptr = pStHostent->h_addr_list;  
        for (; *pptr != NULL; pptr++)  
        {  
            //addr.S_un.S_addr = *(u_long*)*pptr;  
            addr.s_addr = *(u_long*)*pptr;  
            //��ӡ��IP��ַ�б�  
			OutputDebugStringA("\nTry to search devices from:");
            OutputDebugStringA(inet_ntoa(addr)); 
			struct in_addr if_req;  
			if_req.s_addr = inet_addr(inet_ntoa(addr));  // ��󶨵�IP��ַ 
			proxyDiscovery.soap->ipv4_multicast_if = (char*)soap_malloc(proxyDiscovery.soap, sizeof(in_addr));
			memset(proxyDiscovery.soap->ipv4_multicast_if, 0, sizeof(in_addr));
			memcpy(proxyDiscovery.soap->ipv4_multicast_if, (char*)&if_req, sizeof(if_req));
			d__ProbeMatchesType d__ProbeMatches;
			//proxyDiscovery.__dndl__Probe(&d__Probe, &d__ProbeMatches);	
			//return 0;

			int nIp1, nIp2, nIp3, nIp4, nPort;
			int nTryCount = 0;
			int nDiscovery = proxyDiscovery.__dndl_Probe_Start(&d__Probe, &d__ProbeMatches);
			if(nDiscovery != SOAP_OK) return -1;
			while (nDiscovery == SOAP_OK && nTryCount < nRetryTimes && nCnt < MAX_DISCOVERY_COUNT)//����ʧ��5��
			{
				nDiscovery = proxyDiscovery.__dndl_Probe_Receive(&d__Probe, &d__ProbeMatches);
				if(nDiscovery == SOAP_OK){
					nResult &= SOAP_OK;
					for( std::vector<class d__ProbeMatchType * >::iterator probeMatch = d__ProbeMatches.ProbeMatch.begin(); probeMatch != d__ProbeMatches.ProbeMatch.end(); probeMatch++)
					{
						OutputDebugString((*probeMatch)->XAddrs->c_str());
						OutputDebugString("\n");

						/*printf("XAddrs:%s\r\n", (*probeMatch)->XAddrs->c_str());
						printf("Types:%s\r\n", (*probeMatch)->Types->c_str());
						printf("uuid:%s\r\n", (*probeMatch)->wsa__EndpointReference.Address);
						printf("version:%d\r\n", (*probeMatch)->MetadataVersion);
						printf("scope item:%s\r\n", (*probeMatch)->Scopes->__item.c_str());*/
						bool bAxis = false;
						char *pIpAddress = (char*)(*probeMatch)->XAddrs->c_str();
						if(strstr((*probeMatch)->XAddrs->c_str(), "169.254.") && strstr((*probeMatch)->XAddrs->c_str(), " ")){//���ݰ�Ѷʿ��һ��169.254.X.X�ĵ�ַ
							OutputDebugString((*probeMatch)->XAddrs->c_str());
							pIpAddress = (char*)strstr((*probeMatch)->XAddrs->c_str(), " ");
							bAxis = true;
						}
						nIp1 = nIp2 = nIp3 = nIp4 = nPort = 0;
						if(strstr(pIpAddress, "http://") && bAxis)
							pIpAddress = &pIpAddress[strlen("http://")+1];
						else if(strstr(pIpAddress, "http://") && !bAxis)
							pIpAddress = &pIpAddress[strlen("http://")];
						char *pIpAddress2 = strstr(pIpAddress, "/");
						if(pIpAddress2)
							pIpAddress[strlen(pIpAddress)-strlen(pIpAddress2)] = '\0';
						sscanf(pIpAddress, "%d.%d.%d.%d:%d", &nIp1, &nIp2, &nIp3, &nIp4, &nPort);
						if(nPort <= 0)
							nPort = 80;
						////////////////////////////////////////////////////////////////////////////
						// mjx.milesight add start  2014.03.01
						if(nIp1 == 0 && nIp2 == 0 && nIp3 == 0 && nIp4 == 0){	
							nIp1 = (proxyDiscovery.soap->ip >> 24) & 0xff;
							nIp2 = (proxyDiscovery.soap->ip >> 16) & 0xff;
							nIp3 = (proxyDiscovery.soap->ip >> 8) & 0xff;
							nIp4 = proxyDiscovery.soap->ip & 0xff;
						}	/*���������������豸û��IP�������*/
						// end

						char sIp[64] = {0};
						_snprintf(sIp, sizeof(sIp)-1, "%d.%d.%d.%d", nIp1, nIp2, nIp3, nIp4);
						
						if(nCnt > 0 && IsDeviceRepeat(ppDevice, sIp))
							continue;
						_snprintf(pDeviceList[nCnt].szIp, sizeof(pDeviceList[nCnt].szIp)-1, "%d.%d.%d.%d", nIp1, nIp2, nIp3, nIp4);	
						pDeviceList[nCnt].nPort = nPort;
						if(strstr((*probeMatch)->wsa__EndpointReference.Address, "urn:uuid:"))
							sscanf((*probeMatch)->wsa__EndpointReference.Address, "urn:uuid:%s", pDeviceList[nCnt].szUuid);
						else
							_snprintf(pDeviceList[nCnt].szUuid, sizeof(pDeviceList[nCnt].szUuid)-1, "%s", (*probeMatch)->wsa__EndpointReference.Address);

						////////////////////////////////////////////////////////////////////////////
						// mjx.milesight add start
						if (probeMatch == d__ProbeMatches.ProbeMatch.end() || (*probeMatch)->Scopes == NULL)
						{
							continue;    /*��ֹ�����豸ʱ��һЩ��������ɵ��豸Ҳ��Ӧ���淶�����ݵ��³���*/
						}
						// end
						
						//_snprintf(pDeviceList[nCnt].szIp, sizeof(pDeviceList[nCnt].szIp)-1, "%s", (*probeMatch)->XAddrs->c_str());
						//_snprintf(pDeviceList[nCnt].szUuid, sizeof(pDeviceList[nCnt].szUuid)-1, "%s", (*probeMatch)->wsa__EndpointReference.Address);
						char *pszMAC = (char*)strstr((*probeMatch)->Scopes->__item.c_str(), "onvif://www.onvif.org/macaddress/");
						if(pszMAC){
							char macAddress[32] = {0};
							int nLen = strlen(pszMAC);
							int nSep = strlen("onvif://www.onvif.org/macaddress/");
							int i = 0;
							for(i = nSep; i < nLen; i++){
								if(pszMAC[i] == ' ')
									break;
								//pDeviceList[nCnt].szMacAddr[i-nSep] = pszMAC[i];
								macAddress[i-nSep] = pszMAC[i];
							}
							macAddress[i-nSep+1] = '\0';
							//pDeviceList[nCnt].szMacAddr[i-nSep+1] = '\0';
							if(strlen(macAddress) >= 12)
								_snprintf(pDeviceList[nCnt].szMacAddr, sizeof(pDeviceList[nCnt].szMacAddr)-1, "%c%c:%c%c:%c%c:%c%c:%c%c:%c%c", 
								toupper(macAddress[0]), toupper(macAddress[1]), toupper(macAddress[2]), toupper(macAddress[3]), 
								toupper(macAddress[4]),	toupper(macAddress[5]), toupper(macAddress[6]), toupper(macAddress[7]), 
								toupper(macAddress[8]),	toupper(macAddress[9]), toupper(macAddress[10]), toupper(macAddress[11]));
							else
								GetMac(pDeviceList[nCnt].szMacAddr, sizeof(pDeviceList[nCnt].szMacAddr), pDeviceList[nCnt].szIp);
						}else{
							GetMac(pDeviceList[nCnt].szMacAddr, sizeof(pDeviceList[nCnt].szMacAddr), pDeviceList[nCnt].szIp);
						}
						char *pszName = (char*)strstr((*probeMatch)->Scopes->__item.c_str(), "onvif://www.onvif.org/name/");
						if(pszName){
							int nLen = strlen(pszName);
							int nSep = strlen("onvif://www.onvif.org/name/");
							char *pszEnd = strstr(pszName+nSep, "onvif:");
							int nEnd = pszEnd?strlen(pszEnd):0;
							int i = 0;
							for(i = nSep; i < nLen-nEnd; i++){
								pDeviceList[nCnt].szName[i-nSep] = pszName[i];
							}
							pDeviceList[nCnt].szName[i-nSep+1] = '\0';
						}
						char *pszModel = (char*)strstr((*probeMatch)->Scopes->__item.c_str(), "onvif://www.onvif.org/model/");
						if(pszModel){
							int nLen = strlen(pszModel);
							int nSep = strlen("onvif://www.onvif.org/model/");
							char *pszEnd = strstr(pszModel+nSep, "onvif:");
							int nEnd = pszEnd?strlen(pszEnd):0;
							int i = 0;
							for(i = nSep; i < nLen - nEnd; i++){
								pDeviceList[nCnt].szModel[i-nSep] = pszModel[i];
							}
							pDeviceList[nCnt].szModel[i-nSep+1] = '\0';
						}
						char *pszSoftware = (char*)strstr((*probeMatch)->Scopes->__item.c_str(), "onvif://www.onvif.org/softwarever/");
						if(pszSoftware){
							int nLen = strlen(pszSoftware);
							int nSep = strlen("onvif://www.onvif.org/softwarever/");
							int i = 0;
							for(i = nSep; i < nLen; i++){
								if(pszSoftware[i] == ' ')
									break;
								pDeviceList[nCnt].szSoftwareVersion[i-nSep] = pszSoftware[i];
							}
							pDeviceList[nCnt].szSoftwareVersion[i-nSep+1] = '\0';
						}
						char *pszHardware = (char*)strstr((*probeMatch)->Scopes->__item.c_str(), "onvif://www.onvif.org/hardwarever/");
						if(pszHardware){
							int nLen = strlen(pszHardware);
							int nSep = strlen("onvif://www.onvif.org/hardwarever/");
							int i = 0;
							for(i = nSep; i < nLen; i++){
								if(pszHardware[i] == ' ')
									break;
								pDeviceList[nCnt].szHardwareVersion[i-nSep] = pszHardware[i];
							}
							pDeviceList[nCnt].szHardwareVersion[i-nSep+1] = '\0';
						}
						nCnt++;
					}
				}else{
					char sBuf[256]= {0};
					_snprintf(sBuf, sizeof(sBuf)-1, "=====nDiscovery=======%d========\n", nDiscovery);
					OutputDebugString(sBuf);
					nDiscovery = SOAP_OK;
					nTryCount++;
				}
			}

        }  
        break;  
    default:  
        OutputDebugStringA("UnKnow addr type!");  
    }  
//     //��ӡ���������߼��������Ӧ�ı����б�  
//     pptr = pStHostent->h_aliases;  
//     for (; *pptr != NULL; pptr++)  
//     {  
//         OutputDebugStringA(*pptr);  
//     }  
    ::WSACleanup();
	// end
	*pCnt = nCnt;
	return nResult;
}
